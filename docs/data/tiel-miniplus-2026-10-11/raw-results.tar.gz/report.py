"""Report the original 156 planned Tiel samples; select bounded cross checks."""
import itertools,json,math,statistics
from pathlib import Path

ROOT=Path.cwd()
OUT=ROOT/'build/tiel-miniplus-matrix-v1'
plan=json.loads((OUT/'plan.json').read_text())
summary=json.loads((OUT/'summary.json').read_text())
assert summary['status']=='complete' and summary['completed']==156
records=summary['records']
assert len(records)==156 and all(r['native_exit_code']==0 for r in records)
rows=summary['rows']
valid=[r for r in records if r['validation_status']=='complete' and r['facts_pass']]
assert len(valid)==150
assert all(r['validation_status']=='unsupported' and not r['ane_actual']['enabled'] for r in records if r['profile']=='ane-requested-on')
assert {r['parameters']['tail_prefill_splits'] for r in valid}==set(range(1,17))
assert {r['parameters']['kv_format'] for r in valid}=={'int8','bf16','q4_0','q4_0_unrotated','q4h'}
assert {r['parameters']['concurrency'] for r in valid}=={1,2,4}
base={r['output_tokens']:r for r in rows if r['profile']=='baseline'}
profiles={p['name']:p for p in plan['profiles']}

def score(names,metric):
    scored=[]
    for name in names:
        selected=[r for r in rows if r['profile']==name]
        assert len(selected)==2 and all(r['valid_samples']==3 for r in selected)
        # For throughput, a larger number should receive a smaller objective.
        ratio=[base[r['output_tokens']][metric]/r[metric] if metric.endswith('tok_s') else r[metric]/base[r['output_tokens']][metric] for r in selected]
        scored.append({'profile':name,'normalized_objective':math.sqrt(math.prod(ratio)),'memory_peak_gib':max(r['memory_peak_gib'] for r in selected)})
    return sorted(scored,key=lambda r:(r['normalized_objective'],r['memory_peak_gib']))

kv_scores=score(['baseline']+[n for n in profiles if n.startswith('kv-')],'total_seconds')
split_scores=score(['baseline']+[n for n in profiles if n.startswith('splits-')],'prefill_tok_s')
feature_scores=score(['baseline','lookup','compact','lookup-compact'],'decode_tok_s')
kv=profiles[kv_scores[0]['profile']]['change']
splits=profiles[split_scores[0]['profile']]['change']
features=profiles[feature_scores[0]['profile']]['features']
configs={}
for use_kv,use_splits,use_features in itertools.product((False,True),repeat=3):
    p=plan['base_parameters'] | (kv if use_kv else {}) | (splits if use_splits else {})
    f=features if use_features else profiles['baseline']['features']
    identity=json.dumps({'parameters':p,'features':f},sort_keys=True)
    if identity not in configs:
        configs[identity]={'name':f"cross-k{int(use_kv)}-s{int(use_splits)}-f{int(use_features)}",'parameters':p,'features':f}
selection={'status':'selected','kv_candidates':kv_scores,'split_candidates':split_scores,'feature_candidates':feature_scores,'combined_proposal':plan['base_parameters'] | kv | splits,'combined_features':features,'cross_configs':list(configs.values()),'cross_repeats':3,'cross_outputs':[512,2048],'selection_rule':'joint short/long normalized geometric objective; total time for KV, prefill rate for splits, decode rate for feature flags; concurrency reported separately; crossing all subsets of the three winners with original baseline'}
(OUT/'selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
trajectory=[]
for r in records:
    raw=json.loads((Path(r['attempt'])/'stdout.json').read_text())
    gold=json.loads((OUT/f"reference-performance-splits8-{r['parameters']['output_tokens']}.json").read_text())['output_token_ids']
    actual=raw['requests'][0]['output_token_ids']
    difference=next((i for i,(a,b) in enumerate(zip(gold,actual)) if a!=b),None)
    trajectory.append({'profile':r['profile'],'repeat':r['repeat'],'output_tokens':r['parameters']['output_tokens'],'concurrency':r['parameters']['concurrency'],'first_request_first_difference_from_int8_splits8':difference,'draft_acceptance_rate':r['accepted_draft_tokens']/r['drafted_tokens'] if r['drafted_tokens'] else None,'actual_batch_widths':r['actual_batch_widths'],'request_eos_counts':[request['eos_count'] for request in r['requests']],'pre_start_gpu_percent':r['pre_start_gpu_percent'],'observed_busy_pids':r['observed_busy_pids']})
(OUT/'trajectory-report.json').write_text(json.dumps(trajectory,ensure_ascii=False,indent=2)+'\n')
lines=['# Tiel MiniPlus 逐项性能扫描','',
'本轮从原版 Tiel 基准重新测量：INT8、DFlash2 block=8、splits=8、并发 1、lookup／compact／fast top-k 关闭。',
'固定实际 32,768 输入，分别输出 512／2,048 tokens，greedy、忽略 EOS、冷请求。每配置 3 次。',
'完成 156 次真实运行；150 次通过校验，6 次 ANE 请求开启后按预期回退，标记为 unsupported 并保留诊断证据。',
'已有两次短输入重复和 8 次真实 32K 特性正确性检查，后者使用 splits=1。性能扫描中的基准及特性开关另与 splits=8 的实际基准输出逐 token 核对。','',
'## 三次测量的中位数','',
'请求速度为每次批次内请求速度的中位数，再对三次批次取中位数。批吞吐来自所有输出 token／native decode 批耗时，分别报告。',
'首 token 与请求总耗时包含调度等待；模型加载和固定预热不计入。内存为 Metal 分配峰值，非整机 RSS。','',
'| 参数配置 | 实际输出 | 请求 Prefill tokens/s | 请求 Decode tokens/s | 批 Decode tokens/s | 首 token s | 请求总耗时 s | Metal 峰值 GiB |',
'| --- | --- | --- | --- | --- | --- | --- | --- |']
for r in rows:
    if r['valid_samples']:
        lines.append(f"| {r['profile']} | {r['output_tokens']} | {r['prefill_tok_s']:.1f} | {r['decode_tok_s']:.1f} | {r['batch_decode_tok_s']:.1f} | {r['ttft_seconds']:.2f} | {r['total_seconds']:.2f} | {r['memory_peak_gib']:.3f} |")
    else:
        lines.append(f"| {r['profile']} | {r['output_tokens']} | unsupported | — | — | — | — | — |")
lines+=['','## 草稿接受率与实际批宽','',
'改变 KV／splits 后允许出现由不同数值路径引起的生成差异，仍保持事实、实际长度和冷缓存检查。功能开关使用相同 KV／splits 时必须逐 token 一致。',
'首次分歧位置针对每批第一份相同输入，与 INT8／splits=8 原版参考比较。速度是这份固定输入的端到端表现，包含输出轨迹和草稿接受率的影响。','',
'| 参数配置 | 输出 | 草稿接受率中位数 | 首次分歧位置（三次） | 实际批宽范围 |','| --- | --- | --- | --- | --- |']
for row in rows:
    if not row['valid_samples']: continue
    group=[r for r in trajectory if r['profile']==row['profile'] and r['output_tokens']==row['output_tokens']]
    rates=[r['draft_acceptance_rate'] for r in group if r['draft_acceptance_rate'] is not None]
    rate=f"{statistics.median(rates)*100:.1f}%" if rates else '—'
    diffs=[r['first_request_first_difference_from_int8_splits8'] for r in group]
    widths=[v for r in group for v in (r['actual_batch_widths']['min'],r['actual_batch_widths']['max'])]
    lines.append(f"| {row['profile']} | {row['output_tokens']} | {rate} | {diffs} | {min(widths)}～{max(widths)} |")
lines+=['','## 优胜参数与交叉验证','',
'按短、长输出共同表现选择三个方向；以下排名是交叉验证候选，还不是最终推荐。','',
'| 方向 | 候选 | 相对基准的归一化目标 |','| --- | --- | --- |']
for axis,scored in (('KV，总耗时',kv_scores),('splits，prefill 耗时',split_scores),('lookup／compact，decode 耗时',feature_scores)):
    for r in scored:
        lines.append(f"| {axis} | {r['profile']} | {r['normalized_objective']:.4f} |")
lines+=['',
'分别组合最优 KV、splits 和功能开关，包含原基准、单项和所有交叉子集。每组合测试两种输出，各 3 次。',
'交叉结果决定最终候选，随后与原版基准做更长的配对复测。并发 2／4 的批吞吐和请求延迟单列，不混入并发 1 的推荐。','',
'## 原始记录与限制','',
'原 GGUF 权重固定，5 种 KV 格式不是 5 个主模型量化版本。',
'所有速度波动保留；配置三轮分别正序、反序、轮换，长短输出顺序交替。后台负载按授权接受，不停止其他服务。',
'Lookup／compact 排名只依据固定输入，未使用预期输出；强制长输出可能产生重复内容，收益依赖工作负载。',
'当前不支持关闭 Tiel drafter、DFlash2 block=2／4／16、MoE 的实际 ANE FFN，以及 4B 专用 FFN 缓存实验。Fast top-k 在本轮 greedy 中不执行。',
'[计划](plan.json)、[选择数据](selection.json)、[全样本数据](summary.json)、[执行日志](performance-controller.log)。','']
(OUT/'sweep-report.md').write_text('\n'.join(lines))
print(json.dumps({'kv_winner':kv_scores[0],'split_winner':split_scores[0],'feature_winner':feature_scores[0],'cross_configurations':len(configs),'cross_runs':len(configs)*6,'observed_busy_samples':sum(bool(r['observed_busy_pids']) for r in records)},ensure_ascii=False,indent=2))
