"""Frozen-runtime Tiel MiniPlus gates and one-variable-at-a-time measurements."""
import copy
import fcntl
import hashlib
import json
import os
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

from transformers import AutoTokenizer
from install import assembly
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.tools.compact_draft_ranking import write_ranking

ROOT=Path.cwd()
OUT=ROOT/'build/tiel-miniplus-matrix-v1'
PLAN=json.loads((OUT/'plan.json').read_text())
BUILD=ROOT/'build/ghost-merge-validation/block-8'
NATIVE=OUT/'qwen4b-matrix-native'
MODEL=Path(PLAN['model_root'])
PROMPTS=json.loads((OUT/'inputs.json').read_text())['prompts']
CODEC=AutoTokenizer.from_pretrained(PLAN['tokenizer'],local_files_only=True,trust_remote_code=False)
GATE=json.loads((ROOT/'build/ghost-merge-validation/final-verification.json').read_text())
assert GATE['status']=='passed' and GATE['code_sha256']==adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256']
for artifact in GATE['artifacts'].values():
    assert adapter.sha_file(Path(artifact['path']))==artifact['sha256']
STAMP=json.loads((BUILD/'engine/build-identity.json').read_text())
IDENTITY={'code_sha256':matrix.digest({k:PLAN[k] for k in ('runtime_code_sha256','native_harness_sha256','attention_harness_sha256')}),'weight_sha256':{k:v['sha256'] for k,v in PLAN['weights'].items()}}
ARTIFACTS={str(p):adapter.sha_file(p) for p in (NATIVE,BUILD/'splash.metallib',BUILD/'engine/libsplash.a',OUT/'TielMatrix.mm',OUT/'TielPagedAttention.cpp',OUT/'runner.py',OUT/'plan.json')}
(OUT/'prepared-identity.json').write_text(json.dumps({'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']},indent=2)+'\n')
# Hold the verified installed assembly while this controller uses it.
record_lock=(MODEL/'model.json').open('rb')
fcntl.flock(record_lock,fcntl.LOCK_SH)
assembly.verify(MODEL)
FLAGS={'lookup':'SPLASH_PROMPT_LOOKUP','compact':'SPLASH_COMPACT_DRAFT_HEAD','fast':'SPLASH_FAST_TOPK'}
RANK=OUT/'input-frequency-ranking.splash'
ORIGINAL_ENV=isolation.environment
ORIGINAL_IDLE=isolation.require_idle


def save(path,value):
    isolation.write(path,value)


def run(name,parameters,features,performance,prompts=None):
    assert adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256'],'runtime source changed'
    for path,digest in ARTIFACTS.items():
        assert adapter.sha_file(Path(path))==digest,'artifact changed: '+path
    assembly.verify(MODEL)
    attempt=OUT/name
    attempt.mkdir()
    selected=copy.deepcopy(PROMPTS[:parameters['concurrency']] if prompts is None else prompts)
    job={'group_id':matrix.digest(parameters | {'features':features}),'repeat':int(name.split('-')[1]) if name.startswith('perf-') else 0,'parameters':parameters}
    payload={'protocol':'tiel-miniplus-matrix-v1','operation':'run_batch','mode':'performance' if performance else 'correctness','optional_features_correctness':not performance,'model_root':str(MODEL),'metallib':str(BUILD/'splash.metallib'),'identity':IDENTITY,'job':job,'prompts':selected}
    for key,env in FLAGS.items(): os.environ[env]=str(int(features[key]))
    os.environ['SPLASH_COMPACT_DRAFT_RANKING']=str(RANK)
    os.environ['MTL_SHADER_VALIDATION']='0'
    os.environ['MTL_DEBUG_LAYER']='0'
    background=[]
    def environment(*args,**kwargs):
        actual=ORIGINAL_ENV(*args,**kwargs)
        background.append(copy.deepcopy(actual))
        accepted=copy.deepcopy(actual)
        accepted['authorized_diagnostic_busy_pids']=accepted['busy_pids']
        accepted['busy_pids']=[]
        return accepted
    def idle(**kwargs):
        kwargs['ignore_gpu_utilization']=True
        return ORIGINAL_IDLE(**kwargs)
    isolation.environment=environment
    isolation.require_idle=idle
    save(attempt/'payload.json',payload)
    save(OUT/'progress.json',{'status':'running','phase':'performance' if performance else 'correctness','active':name,'controller_pid':os.getpid(),'time':time.time()})
    started=time.time()
    print('START',name,flush=True)
    try:
        evidence=isolation.checked_process([str(NATIVE)],json.dumps(payload),attempt/'stdout.json',attempt/'stderr.log',correctness=not performance)
    finally:
        isolation.environment=ORIGINAL_ENV
        isolation.require_idle=ORIGINAL_IDLE
    evidence.update(background_samples=background,authorized_all_background_load=True,isolated_performance_usable=False,performance_usable=False)
    save(attempt/'evidence.json',evidence)
    if evidence['status']!='complete' or evidence['exit_code']!=0:
        save(OUT/'progress.json',{'status':'failed','phase':'performance' if performance else 'correctness','active':name,'native_status':evidence['status'],'native_exit_code':evidence['exit_code']})
        raise RuntimeError('native failed: '+name)
    raw=json.loads((attempt/'stdout.json').read_text())
    assert raw['compiled_source_sha256']==STAMP['source_sha256']
    raw['commands']=[evidence['command']]
    for response in raw['requests']:
        response['output_text']=CODEC.decode(response['output_token_ids'],skip_special_tokens=False)
    checked=matrix.validate_batch(raw,job,selected,IDENTITY,adapter.eos_ids(MODEL),performance=performance)
    save(attempt/'validated.json',checked)
    memory=raw['memory_report']
    assert sum(memory[k] for k in isolation.CATEGORIES)==memory['backend_current_bytes']
    assert memory['ffn_fp16_cache_bytes']==0 and memory['ffn_cached_matrices']==0
    assert memory['backend_peak_bytes']<=parameters['memory_budget_bytes']
    result={'name':name,'attempt':str(attempt),'parameters':parameters,'features':features,'native_exit_code':0,'validation_status':checked['status'],'facts_pass':checked['facts_pass'],'ane_actual':raw['ane_actual'],'optional_features':raw['optional_features'],'memory_report':memory,'memory_peak_gib':raw['memory_peak_bytes']/2**30,'actual_batch_widths':checked['decode_batch_width_summary'],'drafted_tokens':raw['drafted_tokens'],'accepted_draft_tokens':raw['accepted_draft_tokens'],'requests':checked['requests'],'started_at_unix':started,'completed_at_unix':time.time(),'pre_start_gpu_percent':[s['gpu_utilization_percent'] for s in background[:2]],'observed_busy_pids':sorted({p for s in background for p in s['busy_pids']}),'source_sha256':IDENTITY['code_sha256'],'target_manifest_sha256':raw['target_manifest_sha256']}
    if performance:
        result.update(prefill_tok_s=statistics.median(r['prefill_tok_s'] for r in checked['requests']),decode_tok_s=statistics.median(r['decode_tok_s'] for r in checked['requests']),ttft_seconds=statistics.median(r['timings']['ttft_seconds'] for r in checked['requests']),total_seconds=statistics.median(r['timings']['total_wall_seconds'] for r in checked['requests']),batch_seconds=raw['timings']['total_wall_seconds'],batch_prefill_tok_s=parameters['concurrency']*32768/raw['timings']['prefill_wall_seconds'],batch_decode_tok_s=parameters['concurrency']*parameters['output_tokens']/raw['timings']['decode_wall_seconds'])
    save(attempt/'result.json',result)
    print('END',name,'status='+checked['status'],'facts='+str(checked['facts_pass']),('prefill=%.1f decode=%.1f peak=%.3fGiB'%(result['prefill_tok_s'],result['decode_tok_s'],result['memory_peak_gib'])) if performance else 'correctness only',flush=True)
    time.sleep(2)
    return raw,result


import math
ARTIFACTS[str(OUT/'final-pair.py')]=adapter.sha_file(OUT/'final-pair.py')
save(OUT/'prepared-identity-pair.json',{'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256']})
cross=json.loads((OUT/'cross-summary.json').read_text())
assert cross['status']=='complete' and cross['completed']==cross['planned']==48
rows=cross['rows']
base={r['output_tokens']:r for r in rows if r['config']=='cross-k0-s0-f0'}
assert len(base)==2
ranked=[]
for name in sorted({r['config'] for r in rows}):
    selected=[r for r in rows if r['config']==name]
    assert len(selected)==2 and all(r['samples']==3 for r in selected)
    objective=math.sqrt(math.prod(r['total_seconds']/base[r['output_tokens']]['total_seconds'] for r in selected))
    ranked.append({'config':name,'normalized_total_objective':objective,'parameters':selected[0]['parameters'],'features':selected[0]['features']})
ranked.sort(key=lambda r:r['normalized_total_objective'])
# The strongest distinct challenger tests whether a change is justified,
# including when the original configuration wins the cross sweep.
challenger=next(r for r in ranked if r['config']!='cross-k0-s0-f0')
configs={'A':{'config':'cross-k0-s0-f0','parameters':PLAN['base_parameters'],'features':{'lookup':False,'compact':False,'fast':False}},'B':challenger}
references={}
for arm,config in configs.items():
    for output in (512,2048):
        accepted=next(r for r in cross['records'] if r['config']==config['config'] and r['parameters']['output_tokens']==output)
        references[(arm,output)]=json.loads((Path(accepted['attempt'])/'stdout.json').read_text())['requests'][0]['output_token_ids']
save(OUT/'final-pair-plan.json',{'ranking':ranked,'arms':configs,'pairs_per_output':8,'planned':32,'schedule':'A512 B512 A2048 B2048, repeated eight times; original versus best distinct cross challenger'})
records=[]
print('PAIR ARMS',json.dumps(configs,ensure_ascii=False),flush=True)
try:
    for pair in range(8):
        for output in (512,2048):
            for arm,config in configs.items():
                p=config['parameters'] | {'output_tokens':output}
                name=f"pair-{pair}-{len(records)+1:02d}-{output}-{arm}"
                raw,result=run(name,p,config['features'],True)
                assert result['validation_status']=='complete' and result['facts_pass']
                difference=isolation.first_divergence(references[(arm,output)],raw['requests'][0]['output_token_ids'])
                result.update(arm=arm,pair=pair,config=config['config'],token_match=difference is None,first_difference=difference)
                save(Path(result['attempt'])/'result.json',result)
                assert difference is None,('final pair token divergence',name,difference)
                records.append(result)
                with (OUT/'final-pair-results.jsonl').open('a') as stream: stream.write(json.dumps(result,ensure_ascii=False)+'\n')
                save(OUT/'final-pair-summary.json',{'status':'running','completed':len(records),'planned':32,'arms':configs,'records':records})
                save(OUT/'progress.json',{'status':'running','phase':'final_pair','completed':len(records),'planned':32,'last_completed':name,'controller_pid':os.getpid()})
    summary=json.loads((OUT/'final-pair-summary.json').read_text())
    summary['status']='complete'
    save(OUT/'final-pair-summary.json',summary)
    save(OUT/'progress.json',{'status':'all_measurements_complete','completed':32,'planned':32,'sweep_completed':156,'cross_completed':48})
    print('PAIR COMPLETE 32',flush=True)
except BaseException as error:
    save(OUT/'pair-failure.json',{'type':type(error).__name__,'error':str(error),'time':time.time()})
    raise
finally:
    record_lock.close()
