# Tiel MiniPlus 本轮测试计划

重新测量 Tiel-Coder-35B-A3B-APEX-I-MiniPlus-V2.1，性能结论不复用 4B。
固定原始 GGUF、配套 DFlash2、作者模板的 Splash 适配版、32,768 实际输入、36,864 上下文容量和 32 GiB 内存预算。
忽略 EOS，固定实际输出 512／2,048 tokens，greedy，冷请求。每次启动引擎，固定预热 2,048 行 prefill 和对应并发 decode；请求时长不含模型加载和预热。

## 原始基准和扫描值

| 参数 | 原始基准 | 本轮值 |
| --- | --- | --- |
| KV 格式 | INT8 | INT8、BF16、Q4_0、Q4_0 unrotated、Q4H |
| 输出数量 | 分别测量 | 512、2,048 |
| 历史 splits | 8 | 1～16，每个整数 |
| 并发 | 1 | 1、2、4 |
| Prompt lookup | 关闭 | 关闭、开启 |
| Compact head | 关闭 | 关闭、开启；另测与 lookup 同时开启 |
| Drafter | DFlash2 开启，block=8 | 当前只支持这一执行形态 |
| ANE | GPU | 关闭；另测请求开启后真实回退的诊断配置 |
| 主模型权重量化 | 原始 GGUF | 固定文件，KV 格式扫描不改变权重量化 |

逐项改变一个参数，每配置重复 3 次；另包含 lookup／compact 同开配置。26 个配置、2 种输出、3 次重复，共计划 156 次性能或回退诊断运行。
扫描配置顺序在三轮中分别正序、反序和轮换，长短输出顺序交替。保留全部波动和慢样本。
初始开关正确性使用 splits=1，已全部通过。正式基准的原版 splits=8，来自 32 行／8 行 query tile 和最大 32 个 splits 的规划公式。
性能阶段各开关另与 splits=8 的实际基准输出核对。
初始正确性包括短输入重复检查，以及 32K／512、2,048 下的四种 lookup／compact 组合。特性开关必须与完整 head 基准逐 token 一致。
扫描后按短、长输出共同表现选 KV 和 splits，交叉组合后再做配对复测；并发单列请求速度与批吞吐。

## 当前不能执行的设置

- `drafter off`：ModelDescriptor::valid and installed model contract require a paired draft for Qwen3.6-35B-A3B。
- `DFlash2 block 2/4/16`：DFlashDraftLayout::supportsExecutionBlock requires block8 for DFlash2。
- `actual ANE on`：aneFfnLayers does not register SparseMoe; requested-on diagnosis is measured and labeled fallback。
- `4B FFN cache modes`：ModelFactory only enables quantized/limited FFN experiment for Qwen3.5-4B。
- `fast top-k greedy benchmark`：greedy does not execute the sampled fast top-k path; it remains off in this fixed sampling sweep。

ANE 请求开启但实际回退的样本记为 unsupported，保留诊断记录，不计入“实际 ANE 开启”的成绩。
未支持的 drafter 或 FFN 设置不会伪装成完成，也不会通过放宽模型契约运行。
Compact 排名只依据当前固定输入的 token 频率，未使用预期输出；该排名仅用于本轮实验。

## 本机记录

[参数身份与权重](plan.json)、[初始正确性日志](correctness-controller.log)、[正确性报告](correctness-report.json)。
性能扫描启动后会产生 `performance-controller.log`、`summary.md`、`summary.json` 和 `results.jsonl`，编号目录保存全部原始请求、输出和退出证据。
并发 2／4 的请求各有独立输入，任意两份输入的共同前缀只有 11 tokens。
测试不停止其他服务，按既有授权接受后台负载波动，保留真实负载记录和 macOS 内存保留量。

调度参数 `EngineConfig.decodeShare` 固定为原版默认 0.5，本轮不改变；它与 ANE share 是两个独立参数。
