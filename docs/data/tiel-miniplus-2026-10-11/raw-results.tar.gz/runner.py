"""Frozen-runtime Tiel MiniPlus gates and one-variable-at-a-time measurements."""
import copy
import fcntl
import hashlib
import json
import os
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

from transformers import AutoTokenizer
from install import assembly
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.tools.compact_draft_ranking import write_ranking

ROOT=Path.cwd()
OUT=ROOT/'build/tiel-miniplus-matrix-v1'
PLAN=json.loads((OUT/'plan.json').read_text())
BUILD=ROOT/'build/ghost-merge-validation/block-8'
NATIVE=OUT/'qwen4b-matrix-native'
MODEL=Path(PLAN['model_root'])
PROMPTS=json.loads((OUT/'inputs.json').read_text())['prompts']
CODEC=AutoTokenizer.from_pretrained(PLAN['tokenizer'],local_files_only=True,trust_remote_code=False)
GATE=json.loads((ROOT/'build/ghost-merge-validation/final-verification.json').read_text())
assert GATE['status']=='passed' and GATE['code_sha256']==adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256']
for artifact in GATE['artifacts'].values():
    assert adapter.sha_file(Path(artifact['path']))==artifact['sha256']
STAMP=json.loads((BUILD/'engine/build-identity.json').read_text())
IDENTITY={'code_sha256':matrix.digest({k:PLAN[k] for k in ('runtime_code_sha256','native_harness_sha256','attention_harness_sha256')}),'weight_sha256':{k:v['sha256'] for k,v in PLAN['weights'].items()}}
ARTIFACTS={str(p):adapter.sha_file(p) for p in (NATIVE,BUILD/'splash.metallib',BUILD/'engine/libsplash.a',OUT/'TielMatrix.mm',OUT/'TielPagedAttention.cpp',OUT/'runner.py',OUT/'plan.json')}
(OUT/'prepared-identity.json').write_text(json.dumps({'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']},indent=2)+'\n')
# Hold the verified installed assembly while this controller uses it.
record_lock=(MODEL/'model.json').open('rb')
fcntl.flock(record_lock,fcntl.LOCK_SH)
assembly.verify(MODEL)
FLAGS={'lookup':'SPLASH_PROMPT_LOOKUP','compact':'SPLASH_COMPACT_DRAFT_HEAD','fast':'SPLASH_FAST_TOPK'}
RANK=OUT/'input-frequency-ranking.splash'
ORIGINAL_ENV=isolation.environment
ORIGINAL_IDLE=isolation.require_idle


def save(path,value):
    isolation.write(path,value)


def run(name,parameters,features,performance,prompts=None):
    assert adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256'],'runtime source changed'
    for path,digest in ARTIFACTS.items():
        assert adapter.sha_file(Path(path))==digest,'artifact changed: '+path
    assembly.verify(MODEL)
    attempt=OUT/name
    attempt.mkdir()
    selected=copy.deepcopy(PROMPTS[:parameters['concurrency']] if prompts is None else prompts)
    job={'group_id':matrix.digest(parameters | {'features':features}),'repeat':int(name.split('-')[1]) if name.startswith('perf-') else 0,'parameters':parameters}
    payload={'protocol':'tiel-miniplus-matrix-v1','operation':'run_batch','mode':'performance' if performance else 'correctness','optional_features_correctness':not performance,'model_root':str(MODEL),'metallib':str(BUILD/'splash.metallib'),'identity':IDENTITY,'job':job,'prompts':selected}
    for key,env in FLAGS.items(): os.environ[env]=str(int(features[key]))
    os.environ['SPLASH_COMPACT_DRAFT_RANKING']=str(RANK)
    os.environ['MTL_SHADER_VALIDATION']='0'
    os.environ['MTL_DEBUG_LAYER']='0'
    background=[]
    def environment(*args,**kwargs):
        actual=ORIGINAL_ENV(*args,**kwargs)
        background.append(copy.deepcopy(actual))
        accepted=copy.deepcopy(actual)
        accepted['authorized_diagnostic_busy_pids']=accepted['busy_pids']
        accepted['busy_pids']=[]
        return accepted
    def idle(**kwargs):
        kwargs['ignore_gpu_utilization']=True
        return ORIGINAL_IDLE(**kwargs)
    isolation.environment=environment
    isolation.require_idle=idle
    save(attempt/'payload.json',payload)
    save(OUT/'progress.json',{'status':'running','phase':'performance' if performance else 'correctness','active':name,'controller_pid':os.getpid(),'time':time.time()})
    started=time.time()
    print('START',name,flush=True)
    try:
        evidence=isolation.checked_process([str(NATIVE)],json.dumps(payload),attempt/'stdout.json',attempt/'stderr.log',correctness=not performance)
    finally:
        isolation.environment=ORIGINAL_ENV
        isolation.require_idle=ORIGINAL_IDLE
    evidence.update(background_samples=background,authorized_all_background_load=True,isolated_performance_usable=False,performance_usable=False)
    save(attempt/'evidence.json',evidence)
    if evidence['status']!='complete' or evidence['exit_code']!=0:
        save(OUT/'progress.json',{'status':'failed','phase':'performance' if performance else 'correctness','active':name,'native_status':evidence['status'],'native_exit_code':evidence['exit_code']})
        raise RuntimeError('native failed: '+name)
    raw=json.loads((attempt/'stdout.json').read_text())
    assert raw['compiled_source_sha256']==STAMP['source_sha256']
    raw['commands']=[evidence['command']]
    for response in raw['requests']:
        response['output_text']=CODEC.decode(response['output_token_ids'],skip_special_tokens=False)
    checked=matrix.validate_batch(raw,job,selected,IDENTITY,adapter.eos_ids(MODEL),performance=performance)
    save(attempt/'validated.json',checked)
    memory=raw['memory_report']
    assert sum(memory[k] for k in isolation.CATEGORIES)==memory['backend_current_bytes']
    assert memory['ffn_fp16_cache_bytes']==0 and memory['ffn_cached_matrices']==0
    assert memory['backend_peak_bytes']<=parameters['memory_budget_bytes']
    result={'name':name,'attempt':str(attempt),'parameters':parameters,'features':features,'native_exit_code':0,'validation_status':checked['status'],'facts_pass':checked['facts_pass'],'ane_actual':raw['ane_actual'],'optional_features':raw['optional_features'],'memory_report':memory,'memory_peak_gib':raw['memory_peak_bytes']/2**30,'actual_batch_widths':checked['decode_batch_width_summary'],'drafted_tokens':raw['drafted_tokens'],'accepted_draft_tokens':raw['accepted_draft_tokens'],'requests':checked['requests'],'started_at_unix':started,'completed_at_unix':time.time(),'pre_start_gpu_percent':[s['gpu_utilization_percent'] for s in background[:2]],'observed_busy_pids':sorted({p for s in background for p in s['busy_pids']}),'source_sha256':IDENTITY['code_sha256'],'target_manifest_sha256':raw['target_manifest_sha256']}
    if performance:
        result.update(prefill_tok_s=statistics.median(r['prefill_tok_s'] for r in checked['requests']),decode_tok_s=statistics.median(r['decode_tok_s'] for r in checked['requests']),ttft_seconds=statistics.median(r['timings']['ttft_seconds'] for r in checked['requests']),total_seconds=statistics.median(r['timings']['total_wall_seconds'] for r in checked['requests']),batch_seconds=raw['timings']['total_wall_seconds'],batch_prefill_tok_s=parameters['concurrency']*32768/raw['timings']['prefill_wall_seconds'],batch_decode_tok_s=parameters['concurrency']*parameters['output_tokens']/raw['timings']['decode_wall_seconds'])
    save(attempt/'result.json',result)
    print('END',name,'status='+checked['status'],'facts='+str(checked['facts_pass']),('prefill=%.1f decode=%.1f peak=%.3fGiB'%(result['prefill_tok_s'],result['decode_tok_s'],result['memory_peak_gib'])) if performance else 'correctness only',flush=True)
    time.sleep(2)
    return raw,result


def correctness():
    off={'lookup':False,'compact':False,'fast':False}
    p=PLAN['base_parameters'] | {'input_tokens':128,'output_tokens':32}
    prompt=copy.deepcopy(PROMPTS[0])
    prompt['token_ids']=prompt['token_ids'][:128]
    prompt['input_sha256']=matrix.digest(prompt['token_ids'])
    prompt['expected_facts']=[]
    first,_=run('short-1',p,off,False,[prompt])
    second,_=run('short-2',p,off,False,[prompt])
    assert first['requests'][0]['output_token_ids']==second['requests'][0]['output_token_ids'],'short repeat diverged'
    if not RANK.exists():
        counts=Counter(token for prompt in PROMPTS for token in prompt['token_ids'])
        write_ranking(RANK,first['target_manifest_sha256'],sorted(range(len(CODEC)),key=lambda token:(-counts[token],token)))
    assert RANK.read_bytes()[8:72].decode()==first['target_manifest_sha256']
    records=[]
    failures=[]
    for output in (512,2048):
        gold=None
        for profile in [p for p in PLAN['profiles'] if p['name'] in ('baseline','lookup','compact','lookup-compact')]:
            raw,result=run('correct-'+str(output)+'-'+profile['name'],PLAN['base_parameters'] | {'output_tokens':output},profile['features'],False)
            actual=raw['requests'][0]['output_token_ids']
            if gold is None:
                assert result['validation_status']=='complete' and result['facts_pass'],'Tiel baseline failed factual gate'
                gold=actual
            difference=isolation.first_divergence(gold,actual)
            result['token_match']=difference is None
            result['first_difference']=difference
            result['passed']=result['validation_status']=='complete' and result['facts_pass'] and difference is None
            save(Path(result['attempt'])/'result.json',result)
            records.append(result)
            if not result['passed']: failures.append({'output_tokens':output,'profile':profile['name'],'first_difference':difference,'validation_status':result['validation_status']})
            save(OUT/'correctness-report.json',{'status':'passed' if not failures else 'failed','completed':len(records),'planned':8,'records':records,'failures':failures,'short_repeat_passed':True,'all_native_exit_codes_zero':True,'scope':'same INT8/splits1/C1 target; feature switches must match full head and preserve all summary facts'})
    save(OUT/'progress.json',{'status':'correctness_complete','completed':len(records),'failures':failures})
    print('CORRECTNESS COMPLETE',len(records),'failures',len(failures),flush=True)


def summarize(records,planned):
    rows=[]
    for profile in PLAN['profiles']:
        for output in (512,2048):
            selected=[r for r in records if r['profile']==profile['name'] and r['parameters']['output_tokens']==output]
            if not selected: continue
            valid=[r for r in selected if r['validation_status']=='complete' and r['facts_pass']]
            rows.append({'profile':profile['name'],'output_tokens':output,'completed':len(selected),'valid_samples':len(valid),'statuses':[r['validation_status'] for r in selected],**({k:statistics.median(r[k] for r in valid) for k in ('prefill_tok_s','decode_tok_s','ttft_seconds','total_seconds','memory_peak_gib','batch_prefill_tok_s','batch_decode_tok_s')} if valid else {})})
    save(OUT/'summary.json',{'status':'running','planned':planned,'completed':len(records),'rows':rows,'records':records,'unsupported':PLAN['unsupported'],'isolated_performance_usable':False})
    text=['# Tiel MiniPlus 参数扫描','', '| 配置 | 输出 | 有效样本 | Prefill tokens/s | Decode tokens/s | 批吞吐 tokens/s | 首 token s | 请求总耗时 s | Metal 峰值 GiB |','| --- | --- | --- | --- | --- | --- | --- | --- | --- |']
    for r in rows:
        if r['valid_samples']:
            text.append(f"| {r['profile']} | {r['output_tokens']} | {r['valid_samples']}/{r['completed']} | {r['prefill_tok_s']:.1f} | {r['decode_tok_s']:.1f} | {r['batch_decode_tok_s']:.1f} | {r['ttft_seconds']:.2f} | {r['total_seconds']:.2f} | {r['memory_peak_gib']:.3f} |")
        else: text.append(f"| {r['profile']} | {r['output_tokens']} | 0/{r['completed']} | — | — | — | — | — | — |")
    (OUT/'summary.md').write_text('\n'.join(text)+'\n')


def sweep():
    correctness=json.loads((OUT/'correctness-report.json').read_text())
    assert correctness['completed']==8 and correctness['short_repeat_passed']
    blocked={r['profile'] for r in correctness['failures']}
    records=[]
    schedule=[]
    profiles=PLAN['profiles']
    for repeat in range(3):
        order=profiles if repeat==0 else list(reversed(profiles)) if repeat==1 else profiles[13:]+profiles[:13]
        for profile in order:
            for output in ((512,2048) if repeat%2==0 else (2048,512)):
                schedule.append({'repeat':repeat,'output_tokens':output,'profile':profile})
    save(OUT/'schedule.json',{'jobs':schedule,'planned':len(schedule),'ordering':'forward, reverse, then rotated profile order; output order alternates by repeat','blocked_by_correctness':sorted(blocked)})
    for index,job in enumerate(schedule,1):
        profile=job['profile']
        if profile['name'] in blocked:
            print('BLOCKED BY CORRECTNESS',profile['name'],flush=True)
            continue
        p=PLAN['base_parameters'] | profile['change'] | {'output_tokens':job['output_tokens']}
        name=f"perf-{job['repeat']}-{index:03d}-{job['output_tokens']}-{profile['name']}"
        raw,result=run(name,p,profile['features'],True)
        result.update(profile=profile['name'],repeat=job['repeat'],schedule_index=index,diagnostic_only=profile.get('diagnostic_only',False))
        if profile.get('diagnostic_only'):
            assert result['validation_status']=='unsupported' and not result['ane_actual']['enabled']
            assert profile['expected_fallback'] in result['ane_actual']['fallback_reason']
        else:
            assert result['validation_status']=='complete' and result['facts_pass'],('performance quality gate failed',name)
        # Same-format feature variants must still match the accepted long trajectory.
        if profile['name'] in ('baseline','lookup','compact','lookup-compact'):
            reference_path=OUT/f"reference-performance-splits8-{job['output_tokens']}.json"
            if not reference_path.exists():
                assert profile['name']=='baseline' and job['repeat']==0
                save(reference_path,{'identity':IDENTITY,'parameters':p,'output_token_ids':raw['requests'][0]['output_token_ids'],'source_attempt':str(Path(result['attempt']))})
            reference=json.loads(reference_path.read_text())
            assert reference['identity']==IDENTITY and reference['parameters']['tail_prefill_splits']==8
            expected=reference['output_token_ids']
            difference=isolation.first_divergence(expected,raw['requests'][0]['output_token_ids'])
            result.update(token_match=difference is None,first_difference=difference)
            assert difference is None,('performance token divergence',name,difference)
        save(Path(result['attempt'])/'result.json',result)
        records.append(result)
        with (OUT/'results.jsonl').open('a') as stream: stream.write(json.dumps(result,ensure_ascii=False)+'\n')
        summarize(records,len(schedule))
        save(OUT/'progress.json',{'status':'running','phase':'performance','completed':len(records),'planned':len(schedule),'last_completed':name,'controller_pid':os.getpid()})
    summary=json.loads((OUT/'summary.json').read_text())
    summary['status']='complete'
    save(OUT/'summary.json',summary)
    save(OUT/'progress.json',{'status':'sweep_complete','completed':len(records),'planned':len(schedule),'blocked_by_correctness':sorted(blocked)})
    print('SWEEP COMPLETE',len(records),flush=True)


try:
    {'correctness':correctness,'sweep':sweep}[sys.argv[1]]()
except BaseException as error:
    save(OUT/'controller-failure.json',{'phase':sys.argv[1],'type':type(error).__name__,'error':str(error),'time':time.time()})
    raise
finally:
    record_lock.close()
