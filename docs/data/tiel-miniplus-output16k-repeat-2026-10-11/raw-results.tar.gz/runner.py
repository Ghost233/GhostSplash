"""Frozen-runtime Tiel MiniPlus gates and one-variable-at-a-time measurements."""
import copy
import fcntl
import hashlib
import json
import os
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

from transformers import AutoTokenizer
from install import assembly
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.tools.compact_draft_ranking import write_ranking

ROOT=Path.cwd()
DATA=ROOT/'build/tiel-miniplus-matrix-v1'
OUT=ROOT/'build/tiel-miniplus-output16k-v2'
PREVIOUS=ROOT/'build/tiel-miniplus-output16k-v1'
PLAN=json.loads((DATA/'plan.json').read_text())
BUILD=ROOT/'build/ghost-merge-validation/block-8'
NATIVE=OUT/'qwen4b-matrix-native'
MODEL=Path(PLAN['model_root'])
PROMPTS=json.loads((DATA/'inputs.json').read_text())['prompts']
CODEC=AutoTokenizer.from_pretrained(PLAN['tokenizer'],local_files_only=True,trust_remote_code=False)
GATE=json.loads((ROOT/'build/ghost-merge-validation/final-verification.json').read_text())
assert GATE['status']=='passed' and GATE['code_sha256']==adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256']
for artifact in GATE['artifacts'].values():
    assert adapter.sha_file(Path(artifact['path']))==artifact['sha256']
STAMP=json.loads((BUILD/'engine/build-identity.json').read_text())
IDENTITY={'code_sha256':matrix.digest({'runtime_code_sha256':PLAN['runtime_code_sha256'],'native_harness_sha256':adapter.sha_file(OUT/'TielMatrix.mm'),'attention_harness_sha256':PLAN['attention_harness_sha256']}),'weight_sha256':{k:v['sha256'] for k,v in PLAN['weights'].items()}}
ARTIFACTS={str(p):adapter.sha_file(p) for p in (NATIVE,BUILD/'splash.metallib',BUILD/'engine/libsplash.a',OUT/'TielMatrix.mm',DATA/'TielPagedAttention.cpp',DATA/'TielPagedAttention.o',DATA/'runner.py',DATA/'plan.json')}
(OUT/'prepared-identity.json').write_text(json.dumps({'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']},indent=2)+'\n')
# Hold the verified installed assembly while this controller uses it.
record_lock=(MODEL/'model.json').open('rb')
fcntl.flock(record_lock,fcntl.LOCK_SH)
assembly.verify(MODEL)
FLAGS={'lookup':'SPLASH_PROMPT_LOOKUP','compact':'SPLASH_COMPACT_DRAFT_HEAD','fast':'SPLASH_FAST_TOPK'}
RANK=DATA/'input-frequency-ranking.splash'
ORIGINAL_ENV=isolation.environment
ORIGINAL_IDLE=isolation.require_idle


def save(path,value):
    isolation.write(path,value)


def run(name,parameters,features,performance,prompts=None):
    assert adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256'],'runtime source changed'
    for path,digest in ARTIFACTS.items():
        assert adapter.sha_file(Path(path))==digest,'artifact changed: '+path
    assembly.verify(MODEL)
    attempt=OUT/name
    attempt.mkdir()
    selected=copy.deepcopy(PROMPTS[:parameters['concurrency']] if prompts is None else prompts)
    job={'group_id':matrix.digest(parameters | {'features':features}),'repeat':int(name.split('-')[1]) if name.startswith('perf-') else 0,'parameters':parameters}
    payload={'protocol':'tiel-miniplus-matrix-v1','operation':'run_batch','mode':'performance' if performance else 'correctness','optional_features_correctness':not performance,'model_root':str(MODEL),'metallib':str(BUILD/'splash.metallib'),'identity':IDENTITY,'job':job,'prompts':selected}
    for key,env in FLAGS.items(): os.environ[env]=str(int(features[key]))
    os.environ['SPLASH_COMPACT_DRAFT_RANKING']=str(RANK)
    os.environ['MTL_SHADER_VALIDATION']='0'
    os.environ['MTL_DEBUG_LAYER']='0'
    background=[]
    def environment(*args,**kwargs):
        actual=ORIGINAL_ENV(*args,**kwargs)
        background.append(copy.deepcopy(actual))
        accepted=copy.deepcopy(actual)
        accepted['authorized_diagnostic_busy_pids']=accepted['busy_pids']
        accepted['busy_pids']=[]
        return accepted
    def idle(**kwargs):
        kwargs['ignore_gpu_utilization']=True
        return ORIGINAL_IDLE(**kwargs)
    isolation.environment=environment
    isolation.require_idle=idle
    save(attempt/'payload.json',payload)
    save(OUT/'progress.json',{'status':'running','phase':'performance' if performance else 'correctness','active':name,'controller_pid':os.getpid(),'time':time.time()})
    started=time.time()
    print('START',name,flush=True)
    try:
        evidence=isolation.checked_process([str(NATIVE)],json.dumps(payload),attempt/'stdout.json',attempt/'stderr.log',correctness=not performance)
    finally:
        isolation.environment=ORIGINAL_ENV
        isolation.require_idle=ORIGINAL_IDLE
    evidence.update(background_samples=background,authorized_all_background_load=True,isolated_performance_usable=False,performance_usable=False)
    save(attempt/'evidence.json',evidence)
    if evidence['status']!='complete' or evidence['exit_code']!=0:
        save(OUT/'progress.json',{'status':'failed','phase':'performance' if performance else 'correctness','active':name,'native_status':evidence['status'],'native_exit_code':evidence['exit_code']})
        raise RuntimeError('native failed: '+name)
    raw=json.loads((attempt/'stdout.json').read_text())
    assert raw['compiled_source_sha256']==STAMP['source_sha256']
    raw['commands']=[evidence['command']]
    for response in raw['requests']:
        response['output_text']=CODEC.decode(response['output_token_ids'],skip_special_tokens=False)
    checked=matrix.validate_batch(raw,job,selected,IDENTITY,adapter.eos_ids(MODEL),performance=performance)
    save(attempt/'validated.json',checked)
    memory=raw['memory_report']
    assert sum(memory[k] for k in isolation.CATEGORIES)==memory['backend_current_bytes']
    assert memory['ffn_fp16_cache_bytes']==0 and memory['ffn_cached_matrices']==0
    assert memory['backend_peak_bytes']<=parameters['memory_budget_bytes']
    result={'name':name,'attempt':str(attempt),'parameters':parameters,'features':features,'native_exit_code':0,'validation_status':checked['status'],'facts_pass':checked['facts_pass'],'ane_actual':raw['ane_actual'],'optional_features':raw['optional_features'],'memory_report':memory,'memory_peak_gib':raw['memory_peak_bytes']/2**30,'actual_batch_widths':checked['decode_batch_width_summary'],'drafted_tokens':raw['drafted_tokens'],'accepted_draft_tokens':raw['accepted_draft_tokens'],'requests':checked['requests'],'started_at_unix':started,'completed_at_unix':time.time(),'pre_start_gpu_percent':[s['gpu_utilization_percent'] for s in background[:2]],'observed_busy_pids':sorted({p for s in background for p in s['busy_pids']}),'source_sha256':IDENTITY['code_sha256'],'target_manifest_sha256':raw['target_manifest_sha256']}
    if performance:
        result.update(prefill_tok_s=statistics.median(r['prefill_tok_s'] for r in checked['requests']),decode_tok_s=statistics.median(r['decode_tok_s'] for r in checked['requests']),ttft_seconds=statistics.median(r['timings']['ttft_seconds'] for r in checked['requests']),total_seconds=statistics.median(r['timings']['total_wall_seconds'] for r in checked['requests']),batch_seconds=raw['timings']['total_wall_seconds'],batch_prefill_tok_s=parameters['concurrency']*32768/raw['timings']['prefill_wall_seconds'],batch_decode_tok_s=parameters['concurrency']*parameters['output_tokens']/raw['timings']['decode_wall_seconds'])
    save(attempt/'result.json',result)
    print('END',name,'status='+checked['status'],'facts='+str(checked['facts_pass']),('prefill=%.1f decode=%.1f peak=%.3fGiB'%(result['prefill_tok_s'],result['decode_tok_s'],result['memory_peak_gib'])) if performance else 'correctness only',flush=True)
    time.sleep(2)
    return raw,result


ARTIFACTS[str(OUT/'runner.py')]=adapter.sha_file(OUT/'runner.py')
for role,item in PLAN['weights'].items():
    assert adapter.sha_file(Path(item['path']))==item['sha256'],role+' original weight changed'
features={'lookup':False,'compact':False,'fast':False}
formats=['int8','bf16','q4h']
orders=[formats,[formats[i] for i in [1,2,0]],[formats[i] for i in [2,0,1]]]
base=PLAN['base_parameters'] | {'output_tokens':16384,'context_tokens':131072}
prior=json.loads((DATA/'summary.json').read_text());assert prior['status']=='complete'
prefix_references={}
for kv in formats:
    accepted=next(r for r in prior['records'] if r['parameters']['kv_format']==kv and r['parameters']['tail_prefill_splits']==8 and r['parameters']['output_tokens']==2048 and r['parameters']['concurrency']==1 and not any(r['features'].values()) and not r['parameters']['ane_requested'])
    assert accepted['native_exit_code']==0 and accepted['facts_pass']
    prefix_references[kv]=json.loads((Path(accepted['attempt'])/'stdout.json').read_text())['requests'][0]['output_token_ids']
schedule=[{'repeat':repeat,'kv_format':kv,'format_position':position+1} for repeat,order in enumerate(orders) for position,kv in enumerate(order)]
save(OUT/'plan.json',{'model_id':PLAN['model_id'],'model_root':PLAN['model_root'],'base_parameters':base,'features':features,'formats':formats,'repeats':3,'planned':9,'format_orders':orders,'schedule':schedule,'weights':PLAN['weights'],'runtime_code_sha256':PLAN['runtime_code_sha256'],'source_results':str(DATA),'background_policy':PLAN['background_policy'],'identity':IDENTITY,'scope':'real32768 input and real16384 output; context capacity131072; only KV differs; each round rotates format order; strict facts/length/memory; first2048 prefix matches prior golden; all9 runs match each KV frozen full16384 trajectory from output16k-v1','previous_measurement':str(PREVIOUS),'progress_logging':'native stderr emits prefill completion and output count every2048 tokens; identical for all KV formats'})
save(OUT/'prepared-identity.json',{'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']})
previous=json.loads((PREVIOUS/'summary.json').read_text())
assert previous['status']=='complete' and previous['completed']==9
references={}
for kv in formats:
    earlier=next(r for r in previous['records'] if r['parameters']['kv_format']==kv)
    assert earlier['parameters']==base | {'kv_format':kv}
    references[kv]=json.loads((Path(earlier['attempt'])/'stdout.json').read_text())['requests'][0]['output_token_ids']
records=[]
print('OUTPUT16K START9; input32768 output16384 context131072; splits8 block8 C1 optional features off',flush=True)
try:
    for item in schedule:
        kv=item['kv_format']; repeat=item['repeat']; p=base | {'kv_format':kv}
        name=f"long-{repeat}-{len(records)+1:02d}-{kv}"
        raw,result=run(name,p,features,True)
        assert result['validation_status']=='complete' and result['facts_pass']
        tokens=raw['requests'][0]['output_token_ids']
        prefix_difference=isolation.first_divergence(prefix_references[kv],tokens[:2048])
        difference=isolation.first_divergence(references[kv],tokens)
        result.update(repeat=repeat,format_position=item['format_position'],token_match_same_kv=difference is None,first_difference_same_kv=difference,prefix2048_match=prefix_difference is None,first_difference_prefix2048=prefix_difference,draft_acceptance=result['accepted_draft_tokens']/result['drafted_tokens'] if result['drafted_tokens'] else 0,reference_source='frozen full16384 result from output16k-v1, plus prior2048 golden',startup_timings=raw['startup_timings'])
        save(Path(result['attempt'])/'result.json',result)
        assert prefix_difference is None,('old2048 prefix divergence',name,prefix_difference)
        assert difference is None,('same KV full16384 divergence',name,difference)
        records.append(result)
        with (OUT/'results.jsonl').open('a') as stream: stream.write(json.dumps(result,ensure_ascii=False)+'\n')
        save(OUT/'summary.json',{'status':'running','completed':len(records),'planned':9,'formats':formats,'repeats':3,'records':records})
        save(OUT/'progress.json',{'status':'running','completed':len(records),'planned':9,'repeat':repeat,'last_completed':name,'controller_pid':os.getpid()})
        if len(records)%3==0: print('ROUND COMPLETE',repeat+1,'/3',flush=True)
    save(OUT/'summary.json',{'status':'complete','completed':len(records),'planned':9,'formats':formats,'repeats':3,'records':records})
    save(OUT/'progress.json',{'status':'all_measurements_complete','completed':9,'planned':9})
    print('OUTPUT16K COMPLETE9',flush=True)
except BaseException as error:
    save(OUT/'failure.json',{'type':type(error).__name__,'error':str(error),'time':time.time()})
    raise
finally:
    record_lock.close()
