"""Summarize all five KV formats from the completed three-round measurement."""
from pathlib import Path
import datetime, hashlib, json, shutil, statistics as st, subprocess, tarfile
from dev.benchmarks import qwen4b_matrix_adapter as adapter
root=Path.cwd();out=root/'build/tiel-miniplus-kv5-three-rounds-v1';data=root/'docs/data/tiel-miniplus-kv5-2026-10-11'
def load(name):return json.loads((out/name).read_text())
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
summary=load('summary.json');plan=load('plan.json');identity=load('prepared-identity.json');records=summary['records']
assert summary['status']=='complete' and summary['completed']==summary['planned']==30
assert all(r['native_exit_code']==0 and r['facts_pass'] and r['token_match_same_kv'] for r in records)
assert adapter.code_sha256(root)==plan['runtime_code_sha256']
verification={'status':'checking','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'controller_exit_code':0,'runtime_code_sha256':plan['runtime_code_sha256'],'compiled_source_sha256':identity['compiled_source_sha256'],'artifacts':{},'weights':{}}
for path,wanted in identity['artifacts'].items():
 actual=adapter.sha_file(Path(path));assert actual==wanted,path;verification['artifacts'][path]=actual
for role,item in plan['weights'].items():
 actual=adapter.sha_file(Path(item['path']));assert actual==item['sha256'],role;verification['weights'][role]={**item,'actual_sha256':actual,'match':True}
remaining=[]
for line in subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()[1:]:
 fields=line.strip().split(None,1)
 if len(fields)==2 and (str(out/'runner.py') in fields[1] or str(root/'build/tiel-miniplus-matrix-v1/qwen4b-matrix-native') in fields[1]):remaining.append(int(fields[0]))
assert not remaining,remaining
for r in records:
 evidence=json.loads((Path(r['attempt'])/'evidence.json').read_text());assert evidence['status']=='complete' and evidence['exit_code']==0 and not evidence['error'];assert r['memory_report']['unclassified_bytes']==0
verification.update(status='passed',owned_test_processes_remaining=remaining,native_runs=30,all_native_exit_codes_zero=True,all_facts_pass=True,all_same_kv_token_checks_pass=True,observed_busy_samples=sum(bool(r['observed_busy_pids']) for r in records))
metrics=['prefill_tok_s','decode_tok_s','ttft_seconds','total_seconds','memory_peak_gib'];rows=[]
for output in [512,2048]:
 for kv in plan['formats']:
  rr=[r for r in records if r['parameters']['kv_format']==kv and r['parameters']['output_tokens']==output];assert len(rr)==3 and {r['repeat'] for r in rr}=={0,1,2}
  compared=[]
  for r in rr:
   b=next(x for x in records if x['parameters']['kv_format']=='int8' and x['parameters']['output_tokens']==output and x['repeat']==r['repeat'])
   compared.append({'repeat':r['repeat'],'prefill_gain_percent':100*(r['prefill_tok_s']/b['prefill_tok_s']-1),'decode_gain_percent':100*(r['decode_tok_s']/b['decode_tok_s']-1),'total_reduction_percent':100*(1-r['total_seconds']/b['total_seconds'])})
  rows.append({'kv_format':kv,'output_tokens':output,'samples':3,'median':{k:st.median(r[k] for r in rr) for k in metrics},'range':{k:[min(r[k] for r in rr),max(r[k] for r in rr)] for k in metrics},'device_peak_gib':st.median(r['memory_report']['device_peak_bytes']/2**30 for r in rr),'draft_acceptance':st.median(r['draft_acceptance'] for r in rr),'drafted_tokens':sorted({r['drafted_tokens'] for r in rr}),'accepted_tokens':sorted({r['accepted_draft_tokens'] for r in rr}),'output_sha256':sorted({r['requests'][0]['output_sha256'] for r in rr}),'cross_kv_first_differences':[json.loads(x) for x in sorted({json.dumps(r['first_difference_vs_int8'],sort_keys=True) for r in rr})],'relative_to_same_round_int8':compared,'relative_median':{k:st.median(r[k] for r in compared) for k in ['prefill_gain_percent','decode_gain_percent','total_reduction_percent']}})
report={'status':'complete','rows':rows,'elapsed_seconds':max(r['completed_at_unix'] for r in records)-min(r['started_at_unix'] for r in records),'planned':30,'completed':30,'metric_definition':{'median':'median of all three native runs; no slow sample removed','relative_median':'median of each round ratio against the INT8 run of the same output length; not adjacent paired trials','memory_peak_gib':'backend peak; device ledger shown separately','throughput_gain_percent':'100*(candidate/INT8-1)','total_reduction_percent':'100*(1-candidate/INT8)'}}
save(out/'comparison-report.json',report);save(out/'final-verification.json',verification)
labels={'int8':'INT8','bf16':'BF16','q4_0':'Q4_0','q4_0_unrotated':'Q4_0 unrotated','q4h':'Q4H'}
lines=['# Tiel MiniPlus：五种 KV 格式三轮对照','','## 固定条件','','主模型、drafter、源码、输入和采样均与上一轮一致。只改变 KV，测 INT8、BF16、Q4_0、Q4_0 unrotated 和 Q4H。','','固定 32,768 实际输入、实际输出 512／2,048 tokens、splits=8、DFlash2 block=8、并发 1。ANE、lookup、compact 和 fast top-k 均关闭。greedy、ignore_eos=true、冷请求，上下文容量 36,864 tokens，内存预算 32 GiB。每次启动使用固定预热，模型加载和预热不计入请求耗时。','','每格式、每输出重复 3 轮，共 30 次，执行 %.1f 分钟。三轮中的平均格式出场位置均为第 3 位；长短输出顺序交替。全部样本保留，没有按速度重跑或剔除。'%(report['elapsed_seconds']/60),'','| 轮次 | 格式顺序 |','| --- | --- |']
for i,order in enumerate(plan['format_orders']):lines.append('| '+str(i+1)+' | '+' → '.join(labels[x] for x in order)+' |')
lines+=['','## 三轮中位数','','| 输出 | KV | Prefill tokens/s | Decode tokens/s | 首 token s | 总耗时 s | Backend Metal 峰值 GiB | Device 峰值 GiB | 草稿接受率 |','| --- | --- | --- | --- | --- | --- | --- | --- | --- |']
for r in rows:
 m=r['median'];lines.append(f"| {r['output_tokens']:,} | {labels[r['kv_format']]} | {m['prefill_tok_s']:.1f} | {m['decode_tok_s']:.1f} | {m['ttft_seconds']:.2f} | {m['total_seconds']:.2f} | {m['memory_peak_gib']:.3f} | {r['device_peak_gib']:.3f} | {r['draft_acceptance']:.2%} |")
lines+=['','Backend 和 device 使用两个独立分配口径，都不是进程 RSS 或整机内存。Device 账本包含设备侧额外分配。速度的完整范围见机器可读统计。','','## 同轮相对 INT8 的结果','','先将每轮的候选格式与该轮同输出长度的 INT8 相比，再取三轮中位数。各格式并非相邻配对，表中差异仍会包含时间和负载波动。正数表示候选吞吐更高或总耗时更短。','','| 输出 | KV | Prefill 收益 | Decode 收益 | 总耗时降低 |','| --- | --- | --- | --- | --- |']
for r in rows:
 m=r['relative_median'];lines.append(f"| {r['output_tokens']:,} | {labels[r['kv_format']]} | {m['prefill_gain_percent']:+.2f}% | {m['decode_gain_percent']:+.2f}% | {m['total_reduction_percent']:+.2f}% |")
lines+=['','## 全部逐次记录','','| 轮次 | 输出 | KV | Prefill tokens/s | Decode tokens/s | 首 token s | 总耗时 s | Device 峰值 GiB |','| --- | --- | --- | --- | --- | --- | --- | --- |']
for r in records:
 lines.append(f"| {r['repeat']+1} | {r['parameters']['output_tokens']:,} | {labels[r['parameters']['kv_format']]} | {r['prefill_tok_s']:.1f} | {r['decode_tok_s']:.1f} | {r['ttft_seconds']:.2f} | {r['total_seconds']:.2f} | {r['memory_report']['device_peak_bytes']/2**30:.3f} |")
lines+=['','## 校验与结果范围','','全部 30 次原生运行退出码为 0，输入／输出长度、事实、同 KV 冻结输出和内存账本校验通过。各格式的首次分歧、输出哈希和草稿接受数量均保留。不同 KV 的输出轨迹可以不同，因此 decode 差异同时包含生成内容和草稿接受率的影响，不能等同于单个算子的耗时差。','','本轮未改生产算子。沿用已冻结的原生入口及之前的构建与正确性门禁。主模型 GGUF 权重量化固定；本轮的三种 Q4、INT8、BF16 均指 KV 存储格式。','','按用户授权接受后台波动，检测到后台服务忙的样本数为 '+str(verification['observed_busy_samples'])+'。原始负载采样保留，结果不能视为隔离环境下的稳定上限。','','结束时重新核对源码、构建产物与原始权重 SHA-256，均一致。测试引擎和驱动已退出，没有停止其他服务。','','[三轮统计](data/tiel-miniplus-kv5-2026-10-11/comparison-report.json)、[原始样本](data/tiel-miniplus-kv5-2026-10-11/summary.json)、[结束校验](data/tiel-miniplus-kv5-2026-10-11/final-verification.json)、[原始归档](data/tiel-miniplus-kv5-2026-10-11/raw-results.tar.gz)与[归档清单](data/tiel-miniplus-kv5-2026-10-11/archive-manifest.json)。','','原始运行目录：`'+str(out)+'`。归档不复制原始权重；原生二进制、模板和测试入口保留在上一轮 Tiel 原始归档中。']
if (out/'diagnostics/sampling-note.json').exists():
 lines+=['','## 预热等待与诊断记录','','第一轮 Q4H 短输出的固定预热耗时约 165 秒，正式请求耗时 22.06 秒。该样本做过 1 秒栈采样，可能影响时序；样本按约定保留，没有重跑或剔除。栈采样与诊断说明保存在原始归档的 diagnostics/ 目录中。']
(root/'docs/tiel-miniplus-kv5-2026-10-11.md').write_text('\n'.join(lines)+'\n');data.mkdir(parents=True,exist_ok=True)
for name in ['plan.json','summary.json','comparison-report.json','final-verification.json','controller.log']:shutil.copy2(out/name,data/name)
files=sorted(f for f in out.rglob('*') if f.is_file());manifest=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':adapter.sha_file(f)} for f in files];archive=data/'raw-results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for entry,wanted in zip(tar.getmembers(),manifest,strict=True):
  assert entry.name==wanted['path'];h=hashlib.sha256();stream=tar.extractfile(entry)
  while chunk:=stream.read(1024*1024):h.update(chunk)
  assert h.hexdigest()==wanted['sha256'],entry.name
save(data/'archive-manifest.json',{'archive':archive.name,'sha256':adapter.sha_file(archive),'bytes':archive.stat().st_size,'files':manifest,'roundtrip_verified':True})
print(json.dumps({'status':'saved','elapsed_minutes':report['elapsed_seconds']/60,'rows':rows,'verification':verification['status'],'owned_processes':remaining,'archive_bytes':archive.stat().st_size},ensure_ascii=False))
