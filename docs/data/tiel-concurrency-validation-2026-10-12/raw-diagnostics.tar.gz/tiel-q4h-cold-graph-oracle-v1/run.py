from pathlib import Path
import fcntl,json,time
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from install import assembly

root=Path.cwd();out=root/'build/diagnostics/tiel-q4h-cold-graph-oracle-v1'
assert json.loads((out/'build-result.json').read_text())['exit_code']==0
plan=json.loads((root/'build/tiel-miniplus-matrix-v1/plan.json').read_text());model=Path(plan['model_root']);build=root/'build/ghost-merge-validation/block-8'
assert adapter.code_sha256(root)==plan['runtime_code_sha256']
artifacts={str(p):adapter.sha_file(p) for p in [out/'model-runtime-oracle',out/'ColdGraphOracle.mm',build/'engine/libsplash.a',build/'splash.metallib',build/'engine/metal/MetalBackendInstrumented.o',build/'engine/ane/ProgramInstrumented.o']}
for role,item in plan['weights'].items():assert adapter.sha_file(Path(item['path']))==item['sha256']
lock=(model/'model.json').open('rb');fcntl.flock(lock,fcntl.LOCK_SH);assembly.verify(model)
command=[str(out/'model-runtime-oracle'),str(build/'splash.metallib'),str(model),'--kv-format','q4h','--ane-ffn-share','0','--cold-graph-only']
(out/'identity.json').write_text(json.dumps({'runtime_code_sha256':plan['runtime_code_sha256'],'artifacts':artifacts,'weights':plan['weights'],'command':command,'numerical_thresholds_changed':False,'entrypoint_delta':'test-only CLI supports q4h and selects unchanged cold graph cases; sampled cached-restore failure remains separately recorded'},indent=2)+'\n')
print('Q4H NUMERICAL ORACLE START; original thresholds; real Tiel MoE weights',flush=True)
try:
 evidence=isolation.checked_process(command,None,out/'stdout.log',out/'stderr.log',correctness=True)
 (out/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
 text=(out/'stdout.log').read_text();passed=evidence['status']=='complete' and evidence['exit_code']==0 and 'model_runtime_oracle_test: PASS scope=cold-graph-only' in text
 for path,wanted in artifacts.items():assert adapter.sha_file(Path(path))==wanted,path
 (out/'report.json').write_text(json.dumps({'status':'passed' if passed else 'failed','native_exit_code':evidence['exit_code'],'oracle_status':evidence['status'],'numerical_thresholds_changed':False,'business_pass_marker':'model_runtime_oracle_test: PASS scope=cold-graph-only' in text,'identity':json.loads((out/'identity.json').read_text()),'time':time.time()},indent=2)+'\n')
 print('Q4H NUMERICAL ORACLE END',json.dumps({'passed':passed,'native_exit_code':evidence['exit_code'],'error':evidence['error']}),flush=True)
 if not passed:raise SystemExit(1)
finally:lock.close()
