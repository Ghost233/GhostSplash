from pathlib import Path
import copy,json,subprocess,time
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.benchmarks import qwen4b_matrix_adapter as adapter

root=Path.cwd();out=root/'build/diagnostics/tiel-concurrency-prefix-v1'
assert json.loads((out/'build-result.json').read_text())['exit_code']==0
failed=root/'build/tiel-miniplus-q4h-output16k-sweep-v3/perf-0-017-isolated-retest-concurrency-2'
payload=json.loads((failed/'payload.json').read_text())
payload.update(mode='correctness',optional_features_correctness=False,concurrency_prefix_probe=True)
identity=json.loads((root/'build/tiel-miniplus-q4h-output16k-sweep-v3/prepared-identity.json').read_text())
assert adapter.code_sha256(root)==identity['runtime_source_sha256']
for path,wanted in identity['artifacts'].items():assert adapter.sha_file(Path(path))==wanted,path
artifacts={str(p):adapter.sha_file(p) for p in [out/'qwen4b-matrix-native',out/'TielPrefixProbe.mm',root/'build/ghost-merge-validation/block-8/engine/libsplash.a',root/'build/ghost-merge-validation/block-8/splash.metallib']}
(out/'probe-identity.json').write_text(json.dumps({'production_code_sha256':identity['runtime_source_sha256'],'compiled_source_sha256':identity['compiled_source_sha256'],'artifacts':artifacts,'diagnostic_only':True,'performance_results_usable':False},indent=2)+'\n')
import os
for key in ['SPLASH_PROMPT_LOOKUP','SPLASH_COMPACT_DRAFT_HEAD','SPLASH_FAST_TOPK']:os.environ[key]='0'
os.environ['MTL_SHADER_VALIDATION']='0';os.environ['MTL_DEBUG_LAYER']='0'
records=[]
for index in [1,2]:
    case=out/f'pair-{index}';case.mkdir()
    (case/'payload.json').write_text(json.dumps(payload)+'\n')
    print('PREFIX PROBE START',index,flush=True)
    evidence=isolation.checked_process([str(out/'qwen4b-matrix-native')],json.dumps(payload),case/'stdout.json',case/'stderr.log',correctness=True)
    (case/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
    assert evidence['status']=='complete' and evidence['exit_code']==0,evidence
    raw=json.loads((case/'stdout.json').read_text());assert raw['status']=='diagnostic_prefix_complete' and raw['diagnostic_only']
    assert raw['compiled_source_sha256']==identity['compiled_source_sha256']
    assert all(len(r['output_token_ids'])>=32 and r['cached_input_tokens']==0 for r in raw['requests'])
    checked=subprocess.run([str(root/'.venv/bin/python'),'/private/tmp/tiel-concurrency-prefix-check.py',str(case/'stdout.json')],capture_output=True,text=True)
    record={'probe':index,'native_exit':evidence['exit_code'],'prefix_check_exit':checked.returncode,'prefix_check':json.loads(checked.stdout),'batch_widths':raw['actual_batch_widths'],'prefix_events':raw['prefix_events'],'prefixes':[r['output_token_ids'][:32] for r in raw['requests']]}
    (case/'check.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
    (out/'summary.json').write_text(json.dumps({'status':'running','records':records},indent=2)+'\n')
    print('PREFIX PROBE END',index,checked.stdout.strip(),flush=True)
    time.sleep(2)
(out/'summary.json').write_text(json.dumps({'status':'complete','records':records},indent=2)+'\n')
print('PREFIX DIAGNOSTICS COMPLETE',flush=True)
