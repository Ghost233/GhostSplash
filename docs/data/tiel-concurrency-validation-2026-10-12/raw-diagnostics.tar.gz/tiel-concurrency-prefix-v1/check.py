"""Replay the exact concurrency consistency failure, or check a fresh prefix probe."""
from pathlib import Path
import json
import sys

root=Path('/Users/ghost233/.codex/worktrees/qwen4b-quantized-ffn/GhostSplash')
summary=json.loads((root/'build/tiel-miniplus-q4h-output16k-sweep-v1/summary.json').read_text())
reference=next(r for r in summary['records'] if r['profile']=='concurrency-2')
expected=json.loads((Path(reference['attempt'])/'stdout.json').read_text())
path=Path(sys.argv[1]) if len(sys.argv)>1 else root/'build/tiel-miniplus-q4h-output16k-sweep-v3/perf-0-017-isolated-retest-concurrency-2/stdout.json'
actual=json.loads(path.read_text())
assert actual['identity']==expected['identity'],'semantic source or weights changed'
assert actual['parameters']==expected['parameters'],'requested configuration changed'
assert len(actual['requests'])==len(expected['requests'])==2
failures=[]
for lane,(a,b) in enumerate(zip(actual['requests'],expected['requests'])):
    assert a['prompt_id']==b['prompt_id'] and a['input_sha256']==b['input_sha256']
    tokens=a['output_token_ids'];assert len(tokens)>=32
    for i,(x,y) in enumerate(zip(tokens[:32],b['output_token_ids'][:32])):
        if x!=y:
            failures.append({'request_index':lane,'first_divergence_index':i,'reference_token':y,'actual_token':x})
            break
print(json.dumps({'status':'failed' if failures else 'passed','actual_source':str(path),'prefix_tokens':32,'failures':failures},ensure_ascii=False))
raise SystemExit(bool(failures))
