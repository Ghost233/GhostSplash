import json
import os
import statistics
import subprocess
import sys
from pathlib import Path

root = Path('/Users/ghost233/.codex/worktrees/qwen4b-quantized-ffn/GhostSplash')
out = root / 'build/swift27b-kv16k-v1'

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

env = os.environ.copy()
env['PYTHONPATH'] = str(root)
command = [sys.executable, '-u', '-m', 'dev.benchmarks.swift27b_kv', 'run']
with (out / 'controller.log').open('a') as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL,
                               stdout=log, stderr=subprocess.STDOUT)
    save(out / 'launch.json', {'controller_pid': process.pid, 'observer_pid': os.getpid(),
         'command': command, 'planned_performance_batches': 15})
    exit_code = process.wait()
save(out / 'controller-exit.json', {'exit_code': exit_code, 'pid': process.pid,
     'source': 'subprocess.Popen.wait real exit result'})
if exit_code != 0:
    print('SWIFT KV TEST FAILED; original logs preserved; exit', exit_code, flush=True)
    raise SystemExit(exit_code)
summary = json.loads((out / 'summary.json').read_text())
assert summary['status'] == 'complete' and summary['completed'] == 15
rows = []
for kv in ('bf16', 'int8', 'q4_0', 'q4_0_unrotated', 'q4h'):
    group = [r for r in summary['records'] if r['kv_format'] == kv]
    assert len(group) == 3 and all(r['native_exit_code'] == 0 and r['facts_pass'] for r in group)
    rows.append({'kv_format': kv, 'samples': 3,
        'prefill_tok_s': statistics.median(r['prefill_tok_s'] for r in group),
        'decode_tok_s': statistics.median(r['decode_tok_s'] for r in group),
        'ttft_seconds': statistics.median(r['timings']['ttft_seconds'] for r in group),
        'total_seconds': statistics.median(r['timings']['total_wall_seconds'] for r in group),
        'device_peak_gib': max(r['memory_report']['device_peak_bytes'] for r in group) / 2**30,
        'draft_acceptance': statistics.median(r['draft_acceptance'] for r in group),
        'actual_ane': [r['ane_actual'] for r in group]})
save(out / 'comparison-report.json', {'status': 'complete', 'weight_file_fixed': True,
     'weights_are_mixed_quantization': True, 'rows': rows, 'standard_automatically_changed': False})
lines = ['# Swift 27B：混合 GGUF 权重与五种 KV 格式对照', '',
    '固定同一份用户指定 GGUF 和配套 DFlash2，仅改变 KV 格式。每种格式三轮，32,768 实际输入、16,384 实际输出、131,072 上下文容量。', '',
    'Dense 计算条件：尾段 splits=16，DFlash2 block=8，并发 1，ANE 请求开启（share=0.5、阈值 512 行），lookup 和 compact 开启，fast top-k 关闭。40 GiB 内存预算为统一测试上限。', '',
    '| KV | Prefill tokens/s | Decode tokens/s | 首 token s | 总耗时 s | Device 峰值 GiB |',
    '| --- | --- | --- | --- | --- | --- |']
for row in rows:
    lines.append(f"| {row['kv_format']} | {row['prefill_tok_s']:.1f} | {row['decode_tok_s']:.1f} | {row['ttft_seconds']:.2f} | {row['total_seconds']:.2f} | {row['device_peak_gib']:.3f} |")
lines += ['', '三轮完整输出按同 KV 逐 token 检查，跨 KV 轨迹可以不同。事实、长度、实际参数和内存账本保持原校验要求。真实 ANE 执行及回退原因见 comparison-report.json。', '',
    '记录接受的全部样本；外部活动触发取消并重试。设备启动门禁为连续 30 秒 GPU 不超过 50%，运行中的全局 GPU 利用率包含本模型自身。', '',
    'GGUF 包含多种权重量化格式，文件名中的 IQ3_S 不表示所有张量采用同一格式。MTP 层未参与本轮，drafter 为匹配的 DFlash2。', '',
    '原始数值门禁保留 state cosine > 0.999、同执行图 token 一致和同形状 head 分数相对误差不超过 1e-3。范围为冷请求，本轮未宣称验收所有采样或缓存恢复行为。']
(out / 'comparison-report.md').write_text('\n'.join(lines) + '\n')
print('SWIFT KV15 COMPLETE; reports saved; standard unchanged', flush=True)
