"""Swift 27B: fixed mixed GGUF weights, five KV formats, 32K/16K cold requests."""

import argparse
import fcntl
import json
import os
import time
from pathlib import Path

from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "build/swift27b-kv16k-recheck-v1"
BUILD = ROOT / "build/ghost-merge-validation/block-8"
MODEL_ID = "ukisai/Swift-1.5-Qwen3.8-27B-GSQ-RCO-GGUF:IQ3_S-mtp"
KV = ("bf16", "int8", "q4_0", "q4_0_unrotated", "q4h")
BASE = {
    "ane_requested": True,
    "ane_share": 0.5,
    "ane_minimum_rows": 512,
    "auto_calibration": False,
    "drafter_enabled": True,
    "drafter_block_size": 8,
    "tail_prefill_splits": 16,
    "concurrency": 1,
    "input_tokens": 32768,
    "output_tokens": 16384,
    "context_tokens": 131072,
    "memory_budget_bytes": 40 << 30,
    "temperature": 0,
    "ignore_eos": True,
    "cold_requests": True,
}


def save(path, value):
    isolation.write(path, value)


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def await_idle(completed):
    streak = 0
    while streak < 3:
        environment = isolation.environment()
        idle = (
            not environment["busy_pids"]
            and environment["gpu_utilization_percent"] is not None
            and environment["gpu_utilization_percent"] <= 50
        )
        save(
            OUT / "progress.json",
            {
                "status": "checking_idle" if idle else "waiting_for_idle",
                "completed": completed,
                "planned": 1,
                "environment": environment,
                "controller_pid": os.getpid(),
            },
        )
        print(
            "IDLE",
            environment["gpu_utilization_percent"],
            environment["busy_pids"],
            flush=True,
        )
        streak = streak + 1 if idle else 0
        if streak < 3:
            time.sleep(1)


def run():
    plan = matrix.read_json(OUT / "plan.json")
    codec = adapter.tokenizer(Path(plan["model_root"]))
    prompts = matrix.read_json(OUT / "inputs.json")["prompts"]
    identity = {
        "code_sha256": plan["runtime_code_sha256"],
        "weight_sha256": {k: v["sha256"] for k, v in plan["weights"].items()},
    }
    matrix.validate_identity(identity)
    for path, digest in plan["artifacts"].items():
        assert adapter.sha_file(Path(path)) == digest, path
    for weight in plan["weights"].values():
        assert adapter.sha_file(Path(weight["path"])) == weight["sha256"]
    record_lock = (Path(plan["model_root"]) / "model.json").open("rb")
    fcntl.flock(record_lock, fcntl.LOCK_SH)
    records, goldens = [], {}
    gate = matrix.read_json(OUT / "correctness-gate.json")
    for path, digest in gate["files"].items():
        assert adapter.sha_file(path) == digest, path
    correctness = matrix.read_json(Path(gate["report"]))
    assert correctness["status"] == "passed" and len(correctness["requests"]) == 11
    assert (
        correctness["identity"] == identity and correctness["base_parameters"] == BASE
    )
    assert all(row["first_difference"] is None for row in correctness["comparisons"])
    for row in correctness["requests"]:
        evidence = matrix.read_json(Path(row["directory"]) / "evidence.json")
        assert evidence["status"] == "complete" and evidence["exit_code"] == 0
        assert not evidence["performance_usable"]
        if row["arm"] == "on":
            raw = matrix.read_json(Path(row["directory"]) / "result.json")
            goldens[row["kv_format"]] = raw["requests"][0]["output_token_ids"]
    assert set(goldens) == set(KV)
    print(
        "VERIFIED C1 CORRECTNESS; five complete 16K golden outputs; no correctness reruns",
        flush=True,
    )
    environment = isolation.environment
    os.environ.update(
        SPLASH_PROMPT_LOOKUP="0", SPLASH_COMPACT_DRAFT_HEAD="0", SPLASH_FAST_TOPK="0"
    )
    try:
        rank = OUT / "input-frequency-ranking.splash"
        os.environ.update(
            SPLASH_PROMPT_LOOKUP="1",
            SPLASH_COMPACT_DRAFT_HEAD="1",
            SPLASH_FAST_TOPK="0",
            SPLASH_COMPACT_DRAFT_RANKING=str(rank),
            MTL_SHADER_VALIDATION="0",
            MTL_DEBUG_LAYER="0",
        )
        orders = [("q4_0_unrotated",)]
        for repeat, order in enumerate(orders):
            for kv in order:
                attempt = 0
                while True:
                    assert adapter.code_sha256(ROOT) == plan["runtime_code_sha256"]
                    for path, digest in plan["artifacts"].items():
                        assert adapter.sha_file(Path(path)) == digest, path
                    await_idle(len(records))
                    attempt += 1
                    name = f"perf-{repeat}-{kv}-attempt{attempt}"
                    directory = OUT / name
                    directory.mkdir()
                    parameters = BASE | {"kv_format": kv}
                    job = {
                        "parameters": parameters,
                        "repeat": repeat,
                        "group_id": matrix.digest(parameters),
                    }
                    payload = {
                        "protocol": "qwen4b-matrix-v1",
                        "operation": "run_batch",
                        "mode": "performance",
                        "model_root": plan["model_root"],
                        "metallib": str(BUILD / "splash.metallib"),
                        "identity": identity,
                        "job": job,
                        "prompts": [prompts[0]],
                    }
                    save(directory / "payload.json", payload)
                    save(
                        OUT / "progress.json",
                        {
                            "status": "running",
                            "active": name,
                            "completed": len(records),
                            "planned": 1,
                            "controller_pid": os.getpid(),
                        },
                    )
                    background = []

                    def checked_environment(*args, _background=background, **kwargs):
                        current = environment(*args, **kwargs)
                        _background.append(current)
                        if args and args[0] and current["busy_pids"]:
                            raise RuntimeError(
                                "background-interference: " + str(current["busy_pids"])
                            )
                        return current

                    isolation.environment = checked_environment
                    print("START", name, flush=True)
                    try:
                        evidence = isolation.checked_process(
                            [str(OUT / "swift27b-kv-native")],
                            json.dumps(payload),
                            directory / "stdout.json",
                            directory / "stderr.log",
                            correctness=False,
                        )
                    finally:
                        isolation.environment = environment
                    evidence["background_samples"] = background
                    save(directory / "evidence.json", evidence)
                    if (
                        evidence["status"] != "complete"
                        or evidence["exit_code"] != 0
                        or not evidence["performance_usable"]
                    ):
                        error = evidence.get("error") or ""
                        if error.startswith(
                            (
                                "background-interference:",
                                "external inference active:",
                                "GPU not idle enough",
                                "experiment device lock is held",
                            )
                        ):
                            print("RETRY EXTERNAL LOAD", name, error, flush=True)
                            continue
                        raise RuntimeError(("native failed", name, evidence))
                    raw = matrix.read_json(directory / "stdout.json")
                    raw["commands"] = [evidence["command"]]
                    raw["requests"][0]["output_text"] = codec.decode(
                        raw["requests"][0]["output_token_ids"],
                        skip_special_tokens=False,
                    )
                    checked = matrix.validate_batch(
                        raw,
                        job,
                        [prompts[0]],
                        identity,
                        adapter.eos_ids(Path(plan["model_root"])),
                        performance=True,
                    )
                    assert (
                        checked["status"] == "complete"
                        and checked["facts_pass"]
                        and raw["compiled_source_sha256"]
                        == plan["compiled_source_sha256"]
                    )
                    assert raw["tail_plan_calls"] > 0
                    assert raw["memory_report"]["ffn_fp16_cache_bytes"] == 0
                    assert (
                        sum(raw["memory_report"][k] for k in isolation.CATEGORIES)
                        == raw["memory_report"]["backend_current_bytes"]
                    )
                    assert raw["optional_features"]["configured"] == {
                        "prompt_lookup": True,
                        "compact_draft_head": True,
                        "fast_topk": False,
                    }
                    assert raw["optional_features"]["compact_cycles"] > 0
                    assert raw["optional_features"]["lookup_hits"] > 0
                    assert (
                        raw["ane_actual"]["enabled"]
                        and raw["ane_actual"]["evaluations"] == 1024
                    )
                    tokens = raw["requests"][0]["output_token_ids"]
                    if kv in goldens:
                        assert tokens == goldens[kv], (
                            "same-KV full-token divergence",
                            kv,
                        )
                    else:
                        goldens[kv] = tokens
                    save(directory / "validated.json", checked)
                    request = checked["requests"][0]
                    result = {
                        "name": name,
                        "kv_format": kv,
                        "repeat": repeat,
                        "native_exit_code": 0,
                        "facts_pass": True,
                        "prefill_tok_s": request["prefill_tok_s"],
                        "decode_tok_s": request["decode_tok_s"],
                        "timings": request["timings"],
                        "memory_report": raw["memory_report"],
                        "ane_actual": raw["ane_actual"],
                        "optional_features": raw["optional_features"],
                        "draft_acceptance": raw["accepted_draft_tokens"]
                        / raw["drafted_tokens"],
                        "observed_busy_pids": sorted(
                            {pid for s in background for pid in s["busy_pids"]}
                        ),
                        "full_token_repeatability": True,
                    }
                    save(directory / "result.json", result)
                    records.append(result)
                    save(
                        OUT / "summary.json",
                        {
                            "status": "running",
                            "completed": len(records),
                            "planned": 1,
                            "records": records,
                        },
                    )
                    print(
                        "END",
                        name,
                        result["prefill_tok_s"],
                        result["decode_tok_s"],
                        flush=True,
                    )
                    break
        for weight in plan["weights"].values():
            assert adapter.sha_file(Path(weight["path"])) == weight["sha256"]
        save(
            OUT / "summary.json",
            {"status": "complete", "completed": 1, "planned": 1, "records": records},
        )
        save(
            OUT / "progress.json",
            {"status": "complete", "completed": 1, "planned": 1},
        )
        print(
            "COMPLETE 1; mixed GGUF unchanged; original numerical thresholds retained",
            flush=True,
        )
    except BaseException as error:
        save(
            OUT / "failure.json",
            {
                "type": type(error).__name__,
                "error": str(error),
                "completed": len(records),
                "planned": 1,
            },
        )
        save(
            OUT / "progress.json",
            {
                "status": "failed",
                "completed": len(records),
                "planned": 1,
                "error": str(error),
            },
        )
        raise
    finally:
        isolation.environment = environment
        record_lock.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("run",))
    arguments = parser.parse_args()
    os.chdir(ROOT)
    run()
