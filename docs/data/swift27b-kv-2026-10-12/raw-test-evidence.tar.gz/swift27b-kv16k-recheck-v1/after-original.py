import json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2]
original=root/'build/swift27b-kv16k-perf-v3'
out=pathlib.Path(__file__).resolve().parent
exit_file=original/'controller-exit.json'
while not exit_file.exists():
 time.sleep(10)
prior=json.loads(exit_file.read_text())
if prior['exit_code']!=0:
 (out/'queue-status.json').write_text(json.dumps({'status':'blocked_by_original_failure','original_exit':prior}))
 sys.exit(1)
with (out/'controller.log').open('x') as log:
 env=os.environ.copy();env['PYTHONPATH']=str(root)
 command=[sys.executable,'-u',str(out/'controller.py'),'run']
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/'launch.json').write_text(json.dumps({'controller_pid':process.pid,'command':command},indent=2)+'\n')
 code=process.wait()
(out/'controller-exit.json').write_text(json.dumps({'exit_code':code,'source':'subprocess.wait real exit'},indent=2)+'\n')
sys.exit(code)
