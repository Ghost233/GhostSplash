import json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).resolve().parent
env=os.environ.copy();env['PYTHONPATH']=str(root)
command=[sys.executable,'-u',str(out/'controller.py'),'run']
with (out/'controller.log').open('x') as log:
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/'launch.json').write_text(json.dumps({'controller_pid':process.pid,'command':command},indent=2)+'\n')
 code=process.wait()
(out/'controller-exit.json').write_text(json.dumps({'exit_code':code,'source':'subprocess.wait real exit'},indent=2)+'\n')
sys.exit(code)
