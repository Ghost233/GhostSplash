import json,math,os,statistics,subprocess,sys,time,traceback,uuid
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
from dev.benchmarks import qwen4b_ffn_cache as isolation,qwen4b_matrix as matrix,qwen4b_matrix_adapter as adapter
ORIGINAL_ENV=isolation.environment
BG=[]
READY=[]
records=[]
progress={'controller_pid':os.getpid(),'mode':'native_auto','completed':0,'planned':10}
def save(name,value): isolation.write(OUT/name,value)
def log(*args): print(datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds'),*args,flush=True)
def env(exclude=(),**kwargs):
 current=ORIGINAL_ENV(exclude,**kwargs); extra=[]
 rows=subprocess.check_output(['ps','-Ao','pid=,pcpu=,comm='],text=True)
 for row in rows.splitlines():
  fields=row.strip().split(None,2)
  if len(fields)!=3: continue
  pid,cpu,name=int(fields[0]),float(fields[1]),Path(fields[2]).name
  if pid in exclude or pid==os.getpid(): continue
  native=name.endswith(('-native','-oracle','-benchmark','-profile','-sweep')) and any(s in name for s in ('saluki','swift','tiel','qwen','splash'))
  lm=name=='node' and cpu>=5
  if lm:
   args=subprocess.run(['ps','-p',str(pid),'-o','args='],capture_output=True,text=True).stdout
   lm='.lmstudio/' in args and any(s in args for s in ('llmworker','modelworker','inferenceworker','embeddingworker','liblmstudio'))
  if native or lm: extra.append({'pid':pid,'name':name,'cpu_percent':cpu})
 current['additional_native_or_lm_workloads']=extra
 current['busy_pids']=sorted(set(current['busy_pids'])|{r['pid'] for r in extra}); BG.append(current|{'monotonic':time.monotonic()}); return current
def frozen(plan):
 matrix.require(adapter.code_sha256(ROOT)==plan['runtime_code_sha256'],'runtime changed')
 for rec in list(plan['artifacts'].values())+list(plan['weights'].values()): adapter.verify_record(rec)
def idle():
 global READY
 first=None; last_log=0; history=[]
 while True:
  current=env(); now=time.monotonic(); ready=not current['busy_pids'] and current['gpu_utilization_percent'] is not None and current['gpu_utilization_percent']<=50
  first=first if ready and first is not None else now if ready else None
  history=history+[current|{'monotonic':now}] if ready else []
  save('progress.json',progress|{'status':'checking_idle' if ready else 'waiting_for_idle','environment':current,'updated_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()})
  if now-last_log>=30: log('IDLE gpu=',current['gpu_utilization_percent'],'busy=',current['busy_pids']); last_log=now
  if first is not None and now-first>=30:
   READY=history; return
  time.sleep(5)
def verified_idle(**kwargs):
 matrix.require(READY and time.monotonic()-READY[-1]['monotonic']<2,'GPU idle preflight expired')
 matrix.require(READY[-1]['monotonic']-READY[0]['monotonic']>=30,'GPU idle preflight too short')
 matrix.require(all(not s['busy_pids'] and s['gpu_utilization_percent']<=50 for s in READY),'GPU idle preflight not passed')
 return READY
def difference(a,b): return next(({'index':i,'reference':x,'actual':y} for i,(x,y) in enumerate(zip(a,b)) if x!=y),None)
def main():
 plan=matrix.read_json(OUT/'plan.json'); frozen(plan); gate=matrix.read_json(plan['prior_numeric_report']); matrix.require(gate['status']=='passed','prior C1 numeric checks did not pass')
 identity={'code_sha256':plan['runtime_code_sha256'],'weight_sha256':{k:v['sha256'] for k,v in plan['weights'].items()}}
 codec=adapter.tokenizer(Path(plan['model_root'])); eos=adapter.eos_ids(Path(plan['model_root'])); prompt=matrix.read_json(Path(plan['inputs']))['prompts'][0]; p=plan['base_parameters']; goldens={}; first=None; attempts=[]
 isolation.environment=env
 isolation.require_idle=verified_idle
 for repeat in range(10):
  prefix=f'auto-{repeat+1:02d}-attempt'
  attempt=max([int(p.name.removeprefix(prefix)) for p in OUT.glob(prefix+'*') if p.is_dir()]+[0])
  while True:
   frozen(plan); progress['round']=repeat+1; idle(); attempt+=1
   label=f'auto-{repeat+1:02d}-attempt{attempt}'; directory=OUT/label; directory.mkdir(); nonce=f'{repeat}-{attempt}-{uuid.uuid4().hex}'
   job={'parameters':p,'repeat':repeat,'group_id':matrix.digest(p)}
   payload={'protocol':matrix.PROTOCOL,'operation':'run_batch','mode':'performance','model_root':plan['model_root'],'metallib':plan['metallib'],'identity':identity,'job':job,'prompts':[prompt],'calibration_cache_nonce':nonce,'optional_features':{'prompt_lookup':True,'compact_draft_head':True,'fast_topk':False,'compact_draft_ranking':plan['ranking']}}
   save(f'{label}/payload.json',payload); progress.update(status='running',active=label); save('progress.json',progress); log('AUTO START',repeat+1,'/10; original native chooser, no manual share/minimum rows')
   BG.clear(); evidence=isolation.checked_process([plan['native']],json.dumps(payload),directory/'stdout.log',directory/'stderr.log',timeout_seconds=1800)
   save(f'{label}/evidence.json',evidence); save(f'{label}/environment.json',BG); attempts.append({'label':label,'evidence':evidence}); save('attempts.json',attempts)
   if evidence['exit_code'] is None and evidence['error'] and any(x in evidence['error'] for x in ('idle','workload','device lock')):
    log('STARTUP IDLE GATE; RETRY',label,evidence['error']); continue
   if evidence['external_workload_observed']: log('EXTERNAL INTERFERENCE; RETRY',label); continue
   matrix.require(evidence['status']=='complete' and evidence['exit_code']==0,'auto process failed: '+label)
   raw=json.loads((directory/'stdout.log').read_text()); matrix.require(raw['status']=='complete' and raw['identity']==identity and raw['parameters']==p,'identity/parameters differ')
   matrix.require(raw['compiled_source_sha256']==plan['compiled_source_sha256'],'compiled runtime differs')
   matrix.require(raw['actual_kv_format']=='q4h' and raw['actual_context_tokens']==262144 and raw['actual_drafter_block_size']==8 and raw['compiled_block_size']==8 and raw['actual_tail_prefill_splits']==16 and raw['tail_plan_calls']>0,'actual fixed parameters differ')
   matrix.require(raw['actual_batch_widths'] and set(raw['actual_batch_widths'])=={1},'concurrency is not C1')
   isolation.validate_memory(raw['memory_report'],'quantized'); matrix.require(0<raw['memory_peak_bytes']<=p['memory_budget_bytes'],'memory budget exceeded')
   matrix.require(raw['optional_features']['configured']=={'prompt_lookup':True,'compact_draft_head':True,'fast_topk':False},'features differ')
   ane=raw['ane_actual']; matrix.require(ane['auto_calibration'] is True and 0<=ane['prepared_share']<1 and 0<=ane['share']<1,'original auto mode not recorded')
   stderr=(directory/'stderr.log').read_text(); matrix.require('calibrated before' not in stderr and 'calibrated' in stderr,'fresh calibration evidence absent')
   matrix.require(len(raw['requests'])==1,'request count differs'); response=raw['requests'][0]; tokens=response['output_token_ids']
   matrix.require(response['input_sha256']==prompt['input_sha256'] and response['input_tokens']==8192 and response['cached_input_tokens']==0,'input/cold prefix changed')
   matrix.require(len(tokens)==4096 and all(type(t)is int and 0<=t<len(codec) for t in tokens),'fixed actual output invalid')
   matrix.require(response['eos_positions']==[i for i,t in enumerate(tokens) if t in eos],'EOS report differs')
   text=codec.decode(tokens,skip_special_tokens=True); matrix.require(not matrix.missing_facts(text,prompt['expected_facts']),'summary facts failed'); response['output_text']=text
   timings=response['timings']; prefill=matrix.positive_seconds(timings['prefill_wall_seconds'],'prefill'); decode=matrix.positive_seconds(timings['decode_wall_seconds'],'decode'); total=matrix.positive_seconds(timings['total_wall_seconds'],'total'); matrix.positive_seconds(timings['ttft_seconds'],'ttft')
   matrix.require(total+1e-9>=prefill+decode,'total shorter than phases')
   signature=(ane['prepared_share'],ane['prepared_minimum_rows'],ane['end_state'],ane['evaluations'])
   repeat_check={'effective_execution_signature':signature,'compared':signature in goldens}
   if signature in goldens:
    diff=difference(goldens[signature],tokens); repeat_check|={'passed':diff is None,'first_difference':diff}; matrix.require(diff is None,'same automatic execution signature changed complete output')
   else: goldens[signature]=tokens
   save(f'{label}/repeat-token-check.json',repeat_check)
   if first is None: first=tokens
   save(f'{label}/cross-run-token-check.json',{'first_difference_vs_first_auto_run':difference(first,tokens),'automatic_settings_can_differ':True})
   row={'run':repeat+1,'directory':str(directory),'ane_actual':ane,'prefill_tok_s':8192/prefill,'decode_tok_s':4096/decode,'timings':timings,'startup_timings':raw['startup_timings'],'memory_report':raw['memory_report'],'optional_features':raw['optional_features'],'facts_pass':True,'output_sha256':matrix.digest(tokens),'repeat_token_check':repeat_check,'calibration_cache_nonce':nonce}
   save(f'{label}/raw-result.json',raw); save(f'{label}/result.json',row); records.append(row); progress['completed']=len(records); save('summary.json',{'status':'running','completed':len(records),'planned':10,'mode':'native_auto','base_parameters':p,'records':records}); save('progress.json',progress)
   log('AUTO PASS',len(records),'/10; selected share=',ane['prepared_share'],'minimum rows=',ane['prepared_minimum_rows'],'actual used=',ane['enabled'],'prefill=',round(row['prefill_tok_s'],2),'decode=',round(row['decode_tok_s'],2),'total=',round(total,2)); break
 selected={}
 for r in records:
  key=f"{r['ane_actual']['prepared_share']:.9f}/{r['ane_actual']['prepared_minimum_rows']}"; selected[key]=selected.get(key,0)+1
 report={'status':'complete','completed':10,'planned':10,'mode':'native_auto','base_parameters':p,'selection_counts':selected,'records':records,'medians':{k:statistics.median(r[k] for r in records) for k in ('prefill_tok_s','decode_tok_s')},'median_total_seconds':statistics.median(r['timings']['total_wall_seconds'] for r in records),'actual_ane_used_runs':sum(r['ane_actual']['enabled'] for r in records),'peak_gib':max(r['memory_report']['backend_peak_bytes'] for r in records)/(1<<30)}
 save('summary.json',report); progress['status']='complete'; save('progress.json',progress); log('COMPLETE original auto calibration 10/10')
if __name__=='__main__':
 code=0
 try: main()
 except BaseException as e:
  code=130 if isinstance(e,KeyboardInterrupt) else 1; traceback.print_exc(); save('progress.json',progress|{'status':'cancelled' if code==130 else 'failed','error':str(e)}); log('STOP',code,str(e))
 finally: save('controller-exit.json',{'exit_code':code,'completed':len(records),'ended_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()})
 raise SystemExit(code)
