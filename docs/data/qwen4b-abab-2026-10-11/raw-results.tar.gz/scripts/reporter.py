"""Summarize every sample and adjacent pair from the frozen ABAB experiment."""
import hashlib
import json
import math
import statistics as st
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from dev.benchmarks import qwen4b_matrix_adapter as adapter

ROOT = Path.cwd()
OUT = ROOT / 'build/performance-abab-5ea170c-v1'
plan = json.loads((OUT / 'plan.json').read_text())
summary = json.loads((OUT / 'summary.json').read_text())
records = summary['records']
assert summary['status'] == 'complete' and len(records) == 32
assert adapter.code_sha256(ROOT) == plan['source_sha256']
gate = json.loads((ROOT / 'build/ghost-merge-validation/final-verification.json').read_text())
for artifact in gate['artifacts'].values():
    assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest() == artifact['sha256']
assert all(r['token_match'] and r['facts_pass'] and r['ane_actual']['enabled'] for r in records)
assert all(r['source_sha256'] == plan['source_sha256'] for r in records)
assert all(r['actual']['fast_topk_selections'] == 0 for r in records)
for r in records:
    evidence = json.loads((Path(r['attempt']) / 'evidence.json').read_text())
    assert evidence['status'] == 'complete' and evidence['exit_code'] == 0
    assert (r['actual']['compact_cycles'] > 0) == (r['arm'] == 'A')

keys = ('prefill_tok_s', 'decode_tok_s', 'ttft_seconds', 'total_seconds', 'memory_peak_gib')
pairs = []
aggregates = []
for output in (512, 2048):
    group = [r for r in records if r['output_tokens'] == output]
    assert [r['arm'] for r in group] == list('AB' * 8)
    for repeat in range(8):
        a, b = [r for r in group if r['pair_index'] == repeat]
        assert a['arm'] == 'A' and b['arm'] == 'B'
        pairs.append({
            'output_tokens': output, 'pair': repeat + 1,
            'a_attempt': a['attempt'], 'b_attempt': b['attempt'],
            'A': {k: a[k] for k in keys}, 'B': {k: b[k] for k in keys},
            'compact_prefill_gain_pct': 100 * (a['prefill_tok_s'] / b['prefill_tok_s'] - 1),
            'compact_decode_gain_pct': 100 * (a['decode_tok_s'] / b['decode_tok_s'] - 1),
            'compact_total_reduction_pct': 100 * (1 - a['total_seconds'] / b['total_seconds']),
            'memory_increment_mib': (a['memory_peak_gib'] - b['memory_peak_gib']) * 1024,
            'pre_start_gpu': {'A': a['pre_start_gpu_percent'], 'B': b['pre_start_gpu_percent']},
            'observed_busy_pids': sorted(set(a['observed_busy_pids'] + b['observed_busy_pids'])),
        })
    for arm in ('A', 'B'):
        selected = [r for r in group if r['arm'] == arm]
        aggregates.append({
            'output_tokens': output, 'arm': arm, 'n': len(selected),
            'median': {k: st.median(r[k] for r in selected) for k in keys},
            'range': {k: [min(r[k] for r in selected), max(r[k] for r in selected)] for k in keys},
            'first_half_median': {k: st.median(r[k] for r in selected[:4]) for k in keys},
            'second_half_median': {k: st.median(r[k] for r in selected[4:]) for k in keys},
            'busy_samples': sum(bool(r['observed_busy_pids']) for r in selected),
        })
paired = []
for output in (512, 2048):
    group = [p for p in pairs if p['output_tokens'] == output]
    paired.append({
        'output_tokens': output, 'pairs': len(group),
        'median_compact_prefill_gain_pct': st.median(p['compact_prefill_gain_pct'] for p in group),
        'median_compact_decode_gain_pct': st.median(p['compact_decode_gain_pct'] for p in group),
        'geometric_compact_decode_gain_pct': 100 * (math.exp(st.mean(math.log(p['A']['decode_tok_s'] / p['B']['decode_tok_s']) for p in group)) - 1),
        'median_compact_total_reduction_pct': st.median(p['compact_total_reduction_pct'] for p in group),
        'compact_decode_wins': sum(p['compact_decode_gain_pct'] > 0 for p in group),
        'compact_total_wins': sum(p['compact_total_reduction_pct'] > 0 for p in group),
        'first_half_decode_gain_pct': st.median(p['compact_decode_gain_pct'] for p in group[:4]),
        'second_half_decode_gain_pct': st.median(p['compact_decode_gain_pct'] for p in group[4:]),
        'memory_increment_mib': st.median(p['memory_increment_mib'] for p in group),
    })
report = {
    'status': 'complete', 'samples': len(records), 'source_unchanged': True,
    'artifacts_unchanged': True, 'all_native_exit_codes_zero': True,
    'all_tokens_match': True, 'all_facts_pass': True,
    'source_sha256': plan['source_sha256'], 'commit': plan['commit'],
    'ranking_sha256': hashlib.sha256(Path(plan['ranking']['path']).read_bytes()).hexdigest(),
    'ranking_basis': plan['ranking']['basis'],
    'isolated_performance_usable': False,
    'observed_busy_samples': sum(bool(r['observed_busy_pids']) for r in records),
    'pre_start_gpu_values': sorted({v for r in records for v in r['pre_start_gpu_percent'] if v is not None}),
    'elapsed_seconds': max(r['completed_at_unix'] for r in records) - min(r['started_at_unix'] for r in records),
    'aggregates': aggregates, 'paired_summary': paired, 'pairs': pairs,
}
(OUT / 'paired-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
tz = ZoneInfo('Asia/Shanghai')
start = datetime.fromtimestamp(min(r['started_at_unix'] for r in records), tz).isoformat(timespec='seconds')
end = datetime.fromtimestamp(max(r['completed_at_unix'] for r in records), tz).isoformat(timespec='seconds')
lines = [
    '# 延长 ABAB 性能对照', '',
    f'执行时间：{start} ～ {end}，共 {report["elapsed_seconds"] / 60:.1f} 分钟。', '',
    'A：lookup 开启、compact 开启。B：lookup 开启、compact 关闭。每个输出长度按 ABAB 顺序运行 8 对；短、长输出在整段测试中交错，共 32 个样本。', '',
    '固定参数：量化 FFN、Q4H KV、ANE share=0.5／minimum_rows=512、DFlash block=8、splits=16、并发 1、32,768 实际输入、512／2,048 实际输出、greedy、忽略 EOS、fast top-k 关闭。固定预热不计入请求时长，每次重新启动引擎。', '',
    '全部样本退出码为 0，token 与已验收准确性结果逐个一致，事实、实际 ANE 和内存校验通过。A 确认命中 compact，B 确认关闭；源码和构建产物保持一致。', '',
    '## 各配置中位数', '',
    '| 输出 | 配置 | 样本数 | Prefill tokens/s | Decode tokens/s | 首 token s | 总耗时 s | Metal 峰值 GiB |',
    '| --- | --- | --- | --- | --- | --- | --- | --- |',
]
for r in aggregates:
    m = r['median']
    lines.append(f'| {r["output_tokens"]} | {r["arm"]} | {r["n"]} | {m["prefill_tok_s"]:.1f} | {m["decode_tok_s"]:.1f} | {m["ttft_seconds"]:.2f} | {m["total_seconds"]:.2f} | {m["memory_peak_gib"]:.3f} |')
lines += ['', '## 相邻配对的收益', '',
    '以下先计算每对 A 相对 B 的差值，再取 8 对中位数。正数代表 compact 更快；总耗时列表示减少比例。它与两个配置中位数直接相除的结果可能不同。', '',
    '| 输出 | Prefill 增幅 | Decode 增幅 | 总耗时减少 | Decode 更快对数 | 总耗时更短对数 | 额外峰值 MiB |',
    '| --- | --- | --- | --- | --- | --- | --- |']
for r in paired:
    lines.append(f'| {r["output_tokens"]} | {r["median_compact_prefill_gain_pct"]:+.2f}% | {r["median_compact_decode_gain_pct"]:+.2f}% | {r["median_compact_total_reduction_pct"]:+.2f}% | {r["compact_decode_wins"]}/8 | {r["compact_total_wins"]}/8 | {r["memory_increment_mib"]:.3f} |')
lines += ['', '## 前后半段', '',
    '| 输出 | 配置 | 前 4 次 Prefill | 后 4 次 Prefill | 前 4 次 Decode | 后 4 次 Decode |',
    '| --- | --- | --- | --- | --- | --- |']
for r in aggregates:
    a, b = r['first_half_median'], r['second_half_median']
    lines.append(f'| {r["output_tokens"]} | {r["arm"]} | {a["prefill_tok_s"]:.1f} | {b["prefill_tok_s"]:.1f} | {a["decode_tok_s"]:.1f} | {b["decode_tok_s"]:.1f} |')
lines += ['', '## 全部相邻样本', '',
    '| 输出 | 对 | A Prefill | B Prefill | A Decode | B Decode | Decode 增幅 | A 总耗时 | B 总耗时 | 启动前 GPU A／B | 其他活动 PID |',
    '| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |']
for p in pairs:
    a, b = p['A'], p['B']
    lines.append(f'| {p["output_tokens"]} | {p["pair"]} | {a["prefill_tok_s"]:.1f} | {b["prefill_tok_s"]:.1f} | {a["decode_tok_s"]:.1f} | {b["decode_tok_s"]:.1f} | {p["compact_decode_gain_pct"]:+.2f}% | {a["total_seconds"]:.2f} | {b["total_seconds"]:.2f} | {p["pre_start_gpu"]["A"]}／{p["pre_start_gpu"]["B"]} | {p["observed_busy_pids"]} |')
lines += ['', '## 解释边界与原始证据', '',
    f'记录到其他活动推理的样本：{report["observed_busy_samples"]}／32。启动前 GPU 采样值：{report["pre_start_gpu_values"]}。运行中 GPU 采样包含本测试自身负载。', '',
    '按授权保留所有波动和慢样本，没有重跑或剔除。固定 AB 顺序仍可能受到时间漂移影响；相邻配对和前后半段数据用于观察这种影响，不能仅凭 GPU 百分比归因。', '',
    '排名仅依据固定输入的 token 频率，其他 ID 升序补齐，未使用预期输出。这是实验排名，尚不能代表通用生产请求。', '',
    f'源码提交：`{plan["commit"]}`。',
    f'源码 SHA256：`{plan["source_sha256"]}`。', '',
    '[机器可读配对报告](paired-report.json)、[全样本汇总](summary.json)、[执行日志](controller.log)、[参数计划](plan.json)。每个编号目录保存原始 payload、stdout、stderr、退出证据和校验结果。',
]
(OUT / 'paired-report.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({k: report[k] for k in ('status', 'samples', 'elapsed_seconds', 'observed_busy_samples', 'paired_summary', 'aggregates')}, ensure_ascii=False, indent=2))
