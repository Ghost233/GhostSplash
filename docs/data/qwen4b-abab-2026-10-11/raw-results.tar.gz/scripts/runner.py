"""Frozen-code diagnostic performance under explicitly authorized background load; quantized FFN baseline."""
import copy
import hashlib
import json
import os
import statistics
import time
from collections import Counter
from pathlib import Path

from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from dev.tools.compact_draft_ranking import write_ranking

ROOT = Path.cwd()
OUT = ROOT / "build/performance-abab-5ea170c-v1"
BUILD = ROOT / "build/ghost-merge-validation/block-8"
GATE = ROOT / "build/ghost-merge-validation"
CORRECT = ROOT / "build/accuracy-5ea170c-v1"
MODEL = Path("/Users/ghost233/.codex/worktrees/qwen35-4b-optimization/GhostSplash/install/models-local/.resolved/dae35a717bda8642d409dbb0ce8655296cd37aaa2288c2bd2893ca02244c4f43")
FLAGS = {"lookup": "SPLASH_PROMPT_LOOKUP", "compact": "SPLASH_COMPACT_DRAFT_HEAD", "fast": "SPLASH_FAST_TOPK"}
MODES = {
    "quantized": ("quantized", ()),
    "lookup": ("quantized", ("lookup",)),
    "lookup_compact": ("quantized", ("lookup", "compact")),
    "full_fp16_lookup": ("full_fp16", ("lookup",)),
}
OUT.mkdir(exist_ok=True)
accuracy = json.loads((CORRECT / "report.json").read_text())
assert accuracy["status"] == "passed" and accuracy["commit"] == "5ea170cb3304bc1898270e56be3ad19e50c7da81"
assert accuracy["code_sha256"] == adapter.code_sha256(ROOT)
assert all(c["passed"] for c in accuracy["comparisons"])
gate = json.loads((GATE / "final-verification.json").read_text())
stamp = json.loads((BUILD / "engine/build-identity.json").read_text())
for artifact in gate["artifacts"].values():
    assert hashlib.sha256(Path(artifact["path"]).read_bytes()).hexdigest() == artifact["sha256"]
assert gate["status"] == "passed" and gate["code_sha256"] == adapter.code_sha256(ROOT)
assert gate["compiled_source_sha256"] == stamp["source_sha256"]
long_gate = json.loads((CORRECT / "long/report.json").read_text())
assert long_gate["status"] == "passed"
template = json.loads(next((CORRECT / "long").glob("32k-512-off-*/payload.json")).read_text())
correct = {
    n: json.loads(next((CORRECT / "long").glob(f"32k-{n}-off-*/result.json")).read_text())
    for n in (512, 2048)
}
codec = adapter.tokenizer(MODEL)
counts = Counter(template["prompts"][0]["token_ids"])
ranking = sorted(range(len(codec)), key=lambda token: (-counts[token], token))
RANK = OUT / "input-frequency-ranking.splash"
previous_rank = ROOT / "build/optional-features-performance-round2/input-frequency-ranking.splash"
RANK.write_bytes(previous_rank.read_bytes())
assert hashlib.sha256(RANK.read_bytes()).digest() == hashlib.sha256(previous_rank.read_bytes()).digest()
assert RANK.read_bytes()[8:72].decode() == correct[512]["target_manifest_sha256"]
identity = {"code_sha256": adapter.code_sha256(ROOT), "weight_sha256": {k: v["sha256"] for k, v in json.loads((GATE / "weight-integrity.json").read_text()).items()}}
schema = {
    "mode": "diagnostic_performance",
    "authorization": "explicitly accept all current desktop and inference background load for diagnostic performance",
    "isolated_performance_usable": False,
    "background_load": "Low load reported and verified at initial probe; actual startup and during-run workloads recorded; fluctuations accepted without reruns",
    "parameters": template["job"]["parameters"],
    "baseline": {"ffn_weight_mode": "quantized", "prompt_lookup": True, "compact_draft_head": True, "fast_topk": False},
    "commit": accuracy["commit"],
    "source_sha256": accuracy["code_sha256"],
    "accuracy_report": str(CORRECT / "report.json"),
    "ranking": {"path": str(RANK), "basis": "only input token frequency, remaining IDs ascending; no expected-output tokens used", "production_recommendation": False},
    "schedule": [],
}
for repeat in range(8):
    for output in (512, 2048):
        for arm, mode in (("A", "lookup_compact"), ("B", "lookup")):
            schema["schedule"].append({"output_tokens": output, "baseline": "lookup_compact", "variant": "lookup", "mode": mode, "arm": arm, "repeat": repeat, "pair_index": repeat})
schema["schedule_basis"] = "eight adjacent A/B pairs per output length; A=compact on, B=compact off; lengths interleaved across the whole test; 32 samples total"
(OUT / "plan.json").write_text(json.dumps(schema, indent=2) + "\n")
records = []
original_environment = isolation.environment
original_require_idle = isolation.require_idle

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")

def summarize():
    rows = []
    for output in (512, 2048):
        for mode in MODES:
            selected = [r for r in records if r["output_tokens"] == output and r["mode"] == mode]
            if not selected:
                continue
            rows.append({
                "output_tokens": output, "mode": mode, "samples": len(selected),
                **{key: statistics.median(r[key] for r in selected) for key in ("prefill_tok_s", "decode_tok_s", "prefill_seconds", "decode_seconds", "ttft_seconds", "total_seconds", "memory_peak_gib")},
                "gpu_utilization_percent_median": statistics.median(v for r in selected for v in r["background_gpu_percent"] if v is not None),
                "lookup_hits": sum(r["actual"]["lookup_hits"] for r in selected),
                "compact_cycles": sum(r["actual"]["compact_cycles"] for r in selected),
                "fast_topk_selections": sum(r["actual"]["fast_topk_selections"] for r in selected),
            })
    save("summary.json", {"status": "running", "mode": "diagnostic_performance", "isolated_performance_usable": False, "completed": len(records), "planned": len(schema["schedule"]), "rows": rows, "records": records})
    text = ["# Longer ABAB compact comparison", "", "Authorized diagnostic measurement; not an isolated performance baseline.", "", "| Output | Mode | n | Prefill tok/s | Decode tok/s | TTFT s | Total s | Metal peak GiB |", "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for row in rows:
        text.append(f"| {row['output_tokens']} | {row['mode']} | {row['samples']} | {row['prefill_tok_s']:.2f} | {row['decode_tok_s']:.2f} | {row['ttft_seconds']:.3f} | {row['total_seconds']:.3f} | {row['memory_peak_gib']:.3f} |")
    text += ["", "Fixed: Q4H, ANE share0.5/minimum512, block8, splits16, C1, actual input32768/output512 or2048, cold prefix, greedy.", "Fast top-k is off in every configuration; greedy decoding is used.", "Compact uses a model-bound experimental ranking based only on the input, not expected output. It is not a production popularity ranking.", "Eight adjacent A/B pairs per output length; A compact on, B compact off; 32 samples total. GPU readings include this benchmark during execution. All original payload/output/evidence files are preserved."]
    (OUT / "summary.md").write_text("\n".join(text) + "\n")

for index, job in enumerate(schema["schedule"], 1):
    assert adapter.code_sha256(ROOT) == identity["code_sha256"], "source changed"
    mode, output = job["mode"], job["output_tokens"]
    attempt = OUT / f"{index:02d}-{output}-{mode}"
    attempt.mkdir()
    payload = copy.deepcopy(template)
    payload["mode"] = "performance"
    payload.pop("optional_features_correctness", None)
    payload.pop("ffn_long_correctness", None)
    payload["identity"] = identity
    payload["metallib"] = str(BUILD / "splash.metallib")
    payload["model_root"] = str(MODEL)
    p = payload["job"]["parameters"]
    p.update(output_tokens=output, ffn_weight_mode=MODES[mode][0], ffn_prefill_variant="baseline", ffn_stage_profile=False)
    payload["job"]["group_id"] = matrix.digest(p)
    payload["job"]["repeat"] = job["repeat"]
    for feature, key in FLAGS.items():
        os.environ[key] = str(int(feature in MODES[mode][1]))
    os.environ["SPLASH_COMPACT_DRAFT_RANKING"] = str(RANK)
    os.environ["MTL_SHADER_VALIDATION"] = "0"
    os.environ["MTL_DEBUG_LAYER"] = "0"
    background = []
    def environment(*args, **kwargs):
        snapshot = original_environment(*args, **kwargs)
        background.append(copy.deepcopy(snapshot))
        # Explicit human authorization: all current background computation is
        # accepted for diagnostic timing, never for an isolated baseline.
        accepted = copy.deepcopy(snapshot)
        accepted["authorized_diagnostic_busy_pids"] = accepted["busy_pids"]
        accepted["busy_pids"] = []
        return accepted
    def require_idle(**kwargs):
        # Explicit human authorization accepts all background load.
        # Keep device locking, true process exits, and correctness checks.
        kwargs["ignore_gpu_utilization"] = True
        return original_require_idle(**kwargs)
    isolation.environment = environment
    isolation.require_idle = require_idle
    (attempt / "payload.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    save("progress.json", {"status": "running", "completed": len(records), "planned": len(schema["schedule"]), "active": str(attempt), "pid": os.getpid()})
    started_at = time.time()
    print(f"START {index}/{len(schema['schedule'])} output={output} mode={mode}", flush=True)
    evidence = isolation.checked_process(
        [str(BUILD / "engine-tests/qwen4b-matrix-native")], json.dumps(payload),
        attempt / "stdout.json", attempt / "stderr.log", correctness=False,
    )
    isolation.environment, isolation.require_idle = original_environment, original_require_idle
    evidence.update(authorized_desktop_gpu_load=True, authorized_all_background_load=True, isolated_performance_usable=False, performance_usable=False, diagnostic_performance_usable=evidence["status"] == "complete", background_samples=background)
    (attempt / "evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    if evidence["status"] != "complete" or evidence["exit_code"] != 0:
        save("progress.json", {"status": "stopped", "active": str(attempt), "evidence": evidence, "completed": len(records)})
        raise RuntimeError("process failed: " + str(attempt))
    raw = json.loads((attempt / "stdout.json").read_text())
    assert raw["compiled_source_sha256"] == stamp["source_sha256"]
    raw["commands"] = [evidence["command"]]
    for response in raw["requests"]:
        response["output_text"] = codec.decode(response["output_token_ids"], skip_special_tokens=False)
    checked = matrix.validate_batch(raw, payload["job"], payload["prompts"], identity, adapter.eos_ids(MODEL), performance=True)
    assert checked["status"] == "complete" and checked["facts_pass"], checked
    assert raw["ane_actual"]["enabled"] and raw["ane_actual"]["share"] == 0.5 and raw["ane_actual"]["minimum_rows"] == 512
    isolation.validate_memory(raw["memory_report"], MODES[mode][0])
    expected = correct[output]["requests"][0]["output_token_ids"]
    actual = raw["requests"][0]["output_token_ids"]
    assert actual == expected, {"reason": "token divergence from accepted correctness result", "first_difference": next((i for i, pair in enumerate(zip(actual, expected)) if pair[0] != pair[1]), None), "attempt": str(attempt)}
    (attempt / "validated.json").write_text(json.dumps(checked, ensure_ascii=False, indent=2) + "\n")
    timing = raw["requests"][0]["timings"]
    record = {
        **job, "started_at_unix": started_at, "completed_at_unix": time.time(), "attempt": str(attempt), "prefill_tok_s": 32768 / timing["prefill_wall_seconds"],
        "decode_tok_s": output / timing["decode_wall_seconds"],
        "prefill_seconds": timing["prefill_wall_seconds"], "decode_seconds": timing["decode_wall_seconds"],
        "ttft_seconds": timing["ttft_seconds"], "total_seconds": timing["total_wall_seconds"],
        "memory_peak_gib": raw["memory_peak_bytes"] / 2**30, "memory_report": raw["memory_report"], "actual": raw["optional_features"],
        "background_gpu_percent": [s["gpu_utilization_percent"] for s in background],
        "pre_start_gpu_percent": [s["gpu_utilization_percent"] for s in background[:2]],
        "observed_busy_pids": sorted({pid for s in background for pid in s["busy_pids"]}),
        "observed_low_start_load": all(not s["busy_pids"] and s["gpu_utilization_percent"] is not None and s["gpu_utilization_percent"] <= 50 for s in background[:2]),
        "token_match": True, "facts_pass": True, "ane_actual": raw["ane_actual"],
        "source_sha256": identity["code_sha256"], "compiled_source_sha256": raw["compiled_source_sha256"],
        "startup_timings": raw["startup_timings"], "ranking_basis": schema["ranking"]["basis"],
    }
    records.append(record)
    with (OUT / "results.jsonl").open("a") as stream:
        stream.write(json.dumps(record, ensure_ascii=False) + "\n")
    summarize()
    print(f"END {index}/{len(schema['schedule'])} prefill={record['prefill_tok_s']:.2f}tok/s decode={record['decode_tok_s']:.2f}tok/s peak={record['memory_peak_gib']:.3f}GiB", flush=True)
    time.sleep(2)  # Let the completed benchmark settle before the next startup probe.
save("progress.json", {"status": "complete", "completed": len(records), "planned": len(schema["schedule"])})
summary = json.loads((OUT / "summary.json").read_text())
summary["status"] = "complete"
save("summary.json", summary)
print("COMPLETE", flush=True)
