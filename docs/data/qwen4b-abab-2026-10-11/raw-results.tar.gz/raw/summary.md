# Longer ABAB compact comparison

Authorized diagnostic measurement; not an isolated performance baseline.

| Output | Mode | n | Prefill tok/s | Decode tok/s | TTFT s | Total s | Metal peak GiB |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 512 | lookup | 8 | 2289.12 | 139.66 | 14.323 | 17.932 | 5.477 |
| 512 | lookup_compact | 8 | 2239.78 | 139.27 | 14.657 | 18.321 | 5.672 |
| 2048 | lookup | 8 | 2314.45 | 261.69 | 14.160 | 21.987 | 5.477 |
| 2048 | lookup_compact | 8 | 2257.98 | 265.07 | 14.513 | 22.241 | 5.672 |

Fixed: Q4H, ANE share0.5/minimum512, block8, splits16, C1, actual input32768/output512 or2048, cold prefix, greedy.
Fast top-k is off in every configuration; greedy decoding is used.
Compact uses a model-bound experimental ranking based only on the input, not expected output. It is not a production popularity ranking.
Eight adjacent A/B pairs per output length; A compact on, B compact off; 32 samples total. GPU readings include this benchmark during execution. All original payload/output/evidence files are preserved.
