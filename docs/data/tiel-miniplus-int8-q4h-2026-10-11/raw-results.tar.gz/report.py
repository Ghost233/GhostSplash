"""Summarize the completed, balanced INT8/Q4H measurement without rerunning it."""
import datetime
import hashlib
import json
import shutil
import statistics as st
import subprocess
import tarfile
from pathlib import Path
from dev.benchmarks import qwen4b_matrix_adapter as adapter

root=Path.cwd(); out=root/'build/tiel-miniplus-int8-q4h-paired-v1'; data=root/'docs/data/tiel-miniplus-int8-q4h-2026-10-11'
def load(n): return json.loads((out/n).read_text())
def save(p,d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
summary=load('summary.json'); plan=load('plan.json'); identity=load('prepared-identity.json')
assert summary['status']=='complete' and summary['completed']==summary['planned']==32
records=summary['records']; assert all(r['native_exit_code']==0 and r['facts_pass'] and r['token_match_same_kv'] for r in records)
assert adapter.code_sha256(root)==plan['runtime_code_sha256']
verification={'status':'checking','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'controller_exit_code':0,'runtime_code_sha256':plan['runtime_code_sha256'],'artifacts':{},'weights':{}}
for path,wanted in identity['artifacts'].items():
 actual=adapter.sha_file(Path(path)); assert actual==wanted,path; verification['artifacts'][path]=actual
for role,item in plan['weights'].items():
 actual=adapter.sha_file(Path(item['path'])); assert actual==item['sha256'],role; verification['weights'][role]={**item,'actual_sha256':actual,'match':True}
remaining=[]
for line in subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()[1:]:
 fields=line.strip().split(None,1)
 if len(fields)==2 and (str(out/'runner.py') in fields[1] or str(root/'build/tiel-miniplus-matrix-v1/qwen4b-matrix-native') in fields[1]): remaining.append(int(fields[0]))
assert not remaining,remaining
for r in records:
 evidence=json.loads((Path(r['attempt'])/'evidence.json').read_text()); assert evidence['status']=='complete' and evidence['exit_code']==0 and not evidence['error']; assert r['memory_report']['unclassified_bytes']==0
verification.update(status='passed',owned_test_processes_remaining=remaining,native_runs=32,all_native_exit_codes_zero=True,all_facts_pass=True,all_same_kv_token_checks_pass=True,observed_busy_samples=sum(bool(r['observed_busy_pids']) for r in records))
report={'outputs':{},'elapsed_seconds':max(r['completed_at_unix'] for r in records)-min(r['started_at_unix'] for r in records),'labels':{'A':'INT8','B':'Q4H'},'pairs_per_output':8,'metric_definition':{'throughput_gain_percent':'100*(Q4H/INT8-1)','total_reduction_percent':'100*(1-Q4H/INT8)','acceptance':'accepted draft tokens / drafted tokens','metal_peak':'native backend peak; device ledger listed separately'}}
metrics=['prefill_tok_s','decode_tok_s','ttft_seconds','total_seconds','memory_peak_gib']
for output in [512,2048]:
 stats={}
 for arm in ['A','B']:
  rr=[r for r in records if r['arm']==arm and r['parameters']['output_tokens']==output]
  stats[arm]={'samples':len(rr),'median':{k:st.median(r[k] for r in rr) for k in metrics},'range':{k:[min(r[k] for r in rr),max(r[k] for r in rr)] for k in metrics},'device_peak_gib':st.median(r['memory_report']['device_peak_bytes']/2**30 for r in rr),'draft_acceptance':st.median(r['draft_acceptance'] for r in rr),'drafted_tokens':sorted({r['drafted_tokens'] for r in rr}),'accepted_tokens':sorted({r['accepted_draft_tokens'] for r in rr}),'output_sha256':sorted({r['requests'][0]['output_sha256'] for r in rr})}
 pairs=[]
 for index in range(8):
  a=next(r for r in records if r['arm']=='A' and r['pair']==index and r['parameters']['output_tokens']==output); b=next(r for r in records if r['arm']=='B' and r['pair']==index and r['parameters']['output_tokens']==output)
  pairs.append({'pair':index,'order':'AB' if index%2==0 else 'BA','A':a['name'],'B':b['name'],'prefill_gain_percent':100*(b['prefill_tok_s']/a['prefill_tok_s']-1),'decode_gain_percent':100*(b['decode_tok_s']/a['decode_tok_s']-1),'total_reduction_percent':100*(1-b['total_seconds']/a['total_seconds']),'memory_saved_mib':(a['memory_peak_gib']-b['memory_peak_gib'])*1024})
 keys=['prefill_gain_percent','decode_gain_percent','total_reduction_percent']; report['outputs'][str(output)]={'arms':stats,'pairs':pairs,'paired_median':{k:st.median(p[k] for p in pairs) for k in keys},'Q4H_wins':{k:sum(p[k]>0 for p in pairs) for k in keys},'same_kv_outputs_repeat_exactly':all(len(s['output_sha256'])==1 for s in stats.values()),'cross_kv_first_differences':[json.loads(x) for x in sorted({json.dumps(r['first_difference_vs_int8'],sort_keys=True) for r in records if r['arm']=='B' and r['parameters']['output_tokens']==output})], 'order_group_medians':{order:{k:st.median(p[k] for p in pairs if p['order']==order) for k in keys} for order in ['AB','BA']}}
save(out/'paired-report.json',report);save(out/'final-verification.json',verification)
lines=['# Tiel MiniPlus：INT8 与 Q4H 独立配对对照','','## 测量范围','','只改变 KV 格式。固定 splits=8、DFlash2 block=8、并发 1、ANE 关闭，lookup／compact／fast top-k 关闭。32,768 实际输入，分别生成实际 512 和 2,048 tokens，greedy、忽略 EOS、冷请求。上下文容量 36,864 tokens，内存预算 32 GiB。','','每种输出测 8 对，共 32 次。相邻配对交替使用 INT8→Q4H 和 Q4H→INT8，两种输出的先后顺序也交替。模型加载和固定预热不计入请求时间。保留全部波动，没有因速度重跑。','','## 各组中位数','','| 输出 | KV | Prefill tokens/s | Decode tokens/s | 首 token s | 总耗时 s | Backend Metal 峰值 GiB | Device 峰值 GiB | 草稿接受率 |','| --- | --- | --- | --- | --- | --- | --- | --- | --- |']
for output in [512,2048]:
 for arm,label in [('A','INT8'),('B','Q4H')]:
  r=report['outputs'][str(output)]['arms'][arm];m=r['median'];lines.append(f"| {output:,} | {label} | {m['prefill_tok_s']:.1f} | {m['decode_tok_s']:.1f} | {m['ttft_seconds']:.2f} | {m['total_seconds']:.2f} | {m['memory_peak_gib']:.3f} | {r['device_peak_gib']:.3f} | {r['draft_acceptance']:.2%} |")
lines+=['','## 相邻配对收益','','收益均以 Q4H 相对 INT8 计算。先计算每一对，再取中位数。吞吐收益与总耗时降低均以正值表示 Q4H 更好。','','| 输出 | Prefill 收益 | Decode 收益 | 总耗时降低 | Prefill 更快 | Decode 更快 | 总耗时更短 |','| --- | --- | --- | --- | --- | --- | --- |']
for output in [512,2048]:
 r=report['outputs'][str(output)];m=r['paired_median'];w=r['Q4H_wins'];lines.append(f"| {output:,} | {m['prefill_gain_percent']:+.2f}% | {m['decode_gain_percent']:+.2f}% | {m['total_reduction_percent']:+.2f}% | {w['prefill_gain_percent']}／8 | {w['decode_gain_percent']}／8 | {w['total_reduction_percent']}／8 |")
lines+=['','## 逐对记录','','| 输出 | 对数 | 顺序 | Prefill 收益 | Decode 收益 | 总耗时降低 | 节省 MiB |','| --- | --- | --- | --- | --- | --- | --- |']
for output in [512,2048]:
 for p in report['outputs'][str(output)]['pairs']:
  lines.append(f"| {output:,} | {p['pair']+1} | {p['order']} | {p['prefill_gain_percent']:+.2f}% | {p['decode_gain_percent']:+.2f}% | {p['total_reduction_percent']:+.2f}% | {p['memory_saved_mib']:.2f} |")
lines+=['','## 校验和解释范围','','32 次原生运行退出码均为 0，输入／输出数量、事实、内存账本和每种 KV 对自己的冻结输出检查全部通过。不同 KV 的输出轨迹允许不同，并记录相对 INT8 的首次 token 分歧。主模型权重量化始终固定；本轮只比较 KV。','','Decode 结果包含草稿接受率和输出轨迹的影响，不能单独归因于 attention kernel 性能。事实检查不替代算子数值校验。当前生产源码与算子未修改，复用之前的原生正确性与构建门禁。','','按用户授权接受后台负载波动。原始负载记录保留，检测到其他活动推理的样本数为 '+str(verification['observed_busy_samples'])+'。不能将样本中位数视为隔离环境下的稳定上限。','','运行结束后重新校验源码、构建产物和原始权重 SHA-256，均一致。测试引擎和配对驱动已经退出，没有停止其他服务。','','完整样本范围、顺序分组统计和输出哈希见 [配对统计](data/tiel-miniplus-int8-q4h-2026-10-11/paired-report.json)。[原始样本](data/tiel-miniplus-int8-q4h-2026-10-11/summary.json)、[结束校验](data/tiel-miniplus-int8-q4h-2026-10-11/final-verification.json)、[原始归档](data/tiel-miniplus-int8-q4h-2026-10-11/raw-results.tar.gz)与[归档清单](data/tiel-miniplus-int8-q4h-2026-10-11/archive-manifest.json)。','','原始运行目录：`'+str(out)+'`。归档不复制权重；原生二进制、模板和测试入口身份来自上一轮 Tiel 原始归档。']
(root/'docs/tiel-miniplus-int8-q4h-2026-10-11.md').write_text('\n'.join(lines)+'\n')
data.mkdir(parents=True,exist_ok=True)
for name in ['plan.json','summary.json','paired-report.json','final-verification.json','controller.log']: shutil.copy2(out/name,data/name)
files=sorted(f for f in out.rglob('*') if f.is_file());manifest=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':adapter.sha_file(f)} for f in files]; archive=data/'raw-results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for f in files: tar.add(f,arcname=str(f.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for entry,wanted in zip(tar.getmembers(),manifest,strict=True):
  assert entry.name==wanted['path'];h=hashlib.sha256();stream=tar.extractfile(entry)
  while chunk:=stream.read(1024*1024): h.update(chunk)
  assert h.hexdigest()==wanted['sha256'],entry.name
save(data/'archive-manifest.json',{'archive':archive.name,'sha256':adapter.sha_file(archive),'bytes':archive.stat().st_size,'files':manifest,'roundtrip_verified':True})
print(json.dumps({'status':'saved','report':str(root/'docs/tiel-miniplus-int8-q4h-2026-10-11.md'),'archive_bytes':archive.stat().st_size,'elapsed_minutes':report['elapsed_seconds']/60,'outputs':{o:{'arms':d['arms'],'paired_median':d['paired_median'],'Q4H_wins':d['Q4H_wins']} for o,d in report['outputs'].items()}},ensure_ascii=False))
