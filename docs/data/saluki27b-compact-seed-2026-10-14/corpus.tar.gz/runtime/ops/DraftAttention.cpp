#include "ops/DraftAttention.hpp"

#include "metal/abi/DraftAttention.h"
#include "metal/abi/RoPE.h"
#include "ops/BufferExtent.hpp"
#include "ops/LaneBindings.hpp"

#include <algorithm>
#include <stdexcept>
#include <utility>
#include <vector>

namespace splash::ops {
// Standard checkpoints round each projection to BF16 before residual addition.
void DraftAttention::addStandardResidual(metal::CommandGraph &graph, const metal::MetalBuffer &projected,
                         const metal::MetalBuffer &residual, const metal::MetalBuffer &output,
                         uint32_t rows, uint32_t width) {
  const uint32_t count = rows * width;
  for (const auto *buffer : {&projected, &residual, &output})
    requireBytes(*buffer, uint64_t{count} * sizeof(uint16_t), "standard draft residual");
  graph.add("draft_standard_residual_add", {projected, residual, output}, count,
            {(uint64_t{count} + 255) / 256, 1, 1});
}

namespace {

constexpr uint32_t kMaximumLanes = SPLASH_MAXIMUM_BATCH_WIDTH;
constexpr uint32_t kRows = SPLASH_DRAFT_QUERY_ROWS;
constexpr uint32_t kThreads = metal::CommandGraph::kDefaultThreads;
constexpr uint32_t kWindowThreads = SPLASH_DRAFT_CONTEXT_SIMDGROUPS * 32;
// Each split leaves a partial of its attention rows x (head dimensions + max
// + sum) fp32 values behind the grouped queries.
constexpr uint32_t kSplits = SPLASH_DRAFT_ATTENTION_SPLITS;
constexpr uint64_t kPartialBytes = uint64_t{SPLASH_DRAFT_ATTENTION_ROWS} *
                                   (SPLASH_DRAFT_HEAD_DIMENSION + 2) * sizeof(float);

// Dispatch width of one surrounding phase per lane: one 256-thread group per
// 256 elements and at least one group per whole-group task.
uint32_t phaseGroups(uint64_t elements, uint32_t tasks = 0) {
  return static_cast<uint32_t>(
      std::max<uint64_t>((elements + kThreads - 1) / kThreads, tasks));
}

// The grouped query rows alone, without the split partials behind them.
uint64_t queryRowsBytes(const DraftAttentionPlan &plan) {
  return uint64_t{plan.lanes()} * kRows * plan.shape().attentionSize * 2;
}

// One lane's keys, or values, of one layer: the kernels place a position in
// slot position % capacity of each KV head's ring.
uint64_t ringBytes(DraftAttentionShape shape, DraftAttentionGeometry geometry) {
  return uint64_t{shape.kvHeads} * geometry.capacity * shape.headDimension * 2;
}

void requireGeometry(DraftAttentionGeometry geometry) {
  if (!geometry.valid())
    throw std::invalid_argument("invalid draft cache geometry");
}

// What the context writers read for `rows` rows: the key and value rows,
// the key norm and the rows' RoPE tables (kernels/common/draft_context_kv.h).
void requireContextInputs(const metal::MetalBuffer &contextKv,
                          const metal::MetalBuffer &keyNorm,
                          const metal::MetalBuffer &ropeCos,
                          const metal::MetalBuffer &ropeSin, uint64_t rows,
                          DraftAttentionShape shape) {
  requireBytes(contextKv, rows * (shape.qkvSize - shape.attentionSize) * 2, "draft context K/V");
  requireBytes(keyNorm, uint64_t{shape.headDimension} * 2, "draft key norm");
  const uint64_t ropeBytes = rows * SPLASH_DRAFT_ROPE_PAIRS * 4;
  requireBytes(ropeCos, ropeBytes, "draft RoPE cosine");
  requireBytes(ropeSin, ropeBytes, "draft RoPE sine");
}

// The threadgroups of a context window transfer, one simdgroup per row and
// 64-value group, after checking its buffers.
metal::DispatchSize windowGroups(const metal::MetalBuffer &context, const metal::MetalBuffer &window,
                                 uint32_t rows, uint32_t width) {
  const uint64_t windowBytes = DraftAttention::contextWindowBytes(width);
  if (!rows || rows > SPLASH_DRAFT_SLIDING_WINDOW)
    throw std::invalid_argument("a context window holds one ring's rows");
  requireBytes(context, uint64_t{rows} * width * 2, "draft context rows");
  requireBytes(window, windowBytes, "draft context window");
  const uint64_t tasks = uint64_t{rows} * (width / SPLASH_DRAFT_CONTEXT_GROUP);
  return {(tasks + SPLASH_DRAFT_CONTEXT_SIMDGROUPS - 1) / SPLASH_DRAFT_CONTEXT_SIMDGROUPS, 1, 1};
}

void requireLanes(uint32_t lanes) {
  if (!lanes || lanes > kMaximumLanes)
    throw std::invalid_argument("invalid draft batch width");
}

enum class KernelLayout : uint8_t { Hidden5120, Hidden2048, Standard2560 };

// The compiled draft (metal/abi/DraftAttention.h) of each hidden size the
// convolution kernels take.
[[nodiscard]] KernelLayout kernelShape(DraftAttentionShape shape) {
  const auto compiled = [](uint32_t hidden) {
    return DraftAttentionShape{hidden,
                               draft_dynamic_width(hidden),
                               SPLASH_DRAFT_QKV_WIDTH,
                               SPLASH_DRAFT_ATTENTION_WIDTH,
                               SPLASH_DRAFT_QUERY_HEADS,
                               SPLASH_DRAFT_KV_HEADS,
                               SPLASH_DRAFT_HEAD_DIMENSION};
  };
  if (shape == compiled(5120))
    return KernelLayout::Hidden5120;
  if (shape == compiled(2048))
    return KernelLayout::Hidden2048;
  if (shape == DraftAttentionShape{2560, 0, SPLASH_DRAFT_QKV_WIDTH,
                                  SPLASH_DRAFT_ATTENTION_WIDTH,
                                  SPLASH_DRAFT_QUERY_HEADS, SPLASH_DRAFT_KV_HEADS,
                                  SPLASH_DRAFT_HEAD_DIMENSION})
    return KernelLayout::Standard2560;
  throw std::invalid_argument("unsupported compiled draft attention shape");
}

} // namespace

DraftAttentionWorkspace DraftAttentionPlan::workspace() const noexcept {
  const uint64_t rows = uint64_t{lanes_} * kRows;
  const uint64_t kvBytes = rows * shape_.kvHeads * shape_.headDimension * 2;
  const uint64_t partialBytes =
      uint64_t{lanes_} * shape_.kvHeads * kSplits * kPartialBytes;
  return {shape_.dynamicSize ? rows * shape_.hiddenSize * 2 : 0, rows * shape_.qkvSize * 2,
          rows * shape_.attentionSize * 2 + partialBytes, kvBytes, kvBytes};
}

DraftAttentionPlan DraftAttention::plan(DraftAttentionShape shape,
                                        uint32_t lanes) {
  requireLanes(lanes);
  static_cast<void>(kernelShape(shape));
  return {shape, lanes};
}

void DraftAttention::addConvolution(metal::CommandGraph &graph,
                                    DraftConvolutionBuffers buffers,
                                    const DraftAttentionPlan &plan,
                                    DraftConvolutionStage stage) {
  // Every stage has a case, so a new one fails -Wswitch here.
  uint32_t finish = 0;
  switch (stage) {
  case DraftConvolutionStage::Prepare:
    break;
  case DraftConvolutionStage::Residual:
    finish = 1;
    break;
  }
  const auto shape = plan.shape();
  const KernelLayout kernel = kernelShape(shape);
  if (kernel == KernelLayout::Standard2560)
    throw std::invalid_argument("standard DFlash has no convolution");
  const auto workspace = plan.workspace();
  const uint32_t groups = phaseGroups(uint64_t{kRows} * shape.hiddenSize);
  const uint32_t lanes = plan.lanes();
  requireBytes(buffers.input, workspace.convolutionBytes, "draft convolution input");
  requireBytes(buffers.output, workspace.convolutionBytes, "draft convolution output");
  requireBytes(buffers.residual, workspace.convolutionBytes, "draft convolution residual");
  requireBytes(buffers.dynamic, uint64_t{lanes} * kRows * shape.dynamicSize * 2, "draft dynamic convolution");
  requireBytes(buffers.weights,
               uint64_t{SPLASH_DRAFT_CONVOLUTION_STAGES} * SPLASH_DRAFT_CONVOLUTION_TAPS * shape.hiddenSize * 2,
               "draft convolution weight");
  const DraftConvBatchParams params{finish};
  graph.add(kernel == KernelLayout::Hidden5120 ? "draft_conv"
                                               : "draft_conv_h2048",
            {std::move(buffers.input), std::move(buffers.dynamic),
             std::move(buffers.weights), std::move(buffers.residual),
             std::move(buffers.output)},
            params, {groups, lanes, 1});
}

void DraftAttention::addPrepare(metal::CommandGraph &graph,
                                DraftPrepareBuffers buffers,
                                const DraftAttentionPlan &plan) {
  const auto shape = plan.shape();
  const auto workspace = plan.workspace();
  // The prepare kernel copies one element of the value rows per thread and
  // normalizes one (row, head) per group.
  const uint32_t groups = phaseGroups(
      uint64_t{kRows} * shape.kvHeads * shape.headDimension,
      kRows * (shape.queryHeads + shape.kvHeads));
  const uint32_t lanes = plan.lanes();
  requireBytes(buffers.qkv, workspace.qkvBytes, "draft q/k/v");
  requireBytes(buffers.groupedQueries, queryRowsBytes(plan), "draft grouped queries");
  requireBytes(buffers.queryKeys, workspace.queryKeysBytes, "draft query keys");
  requireBytes(buffers.queryValues, workspace.queryValuesBytes, "draft query values");
  requireBytes(buffers.queryNorm, uint64_t{shape.headDimension} * 2, "draft query norm");
  requireBytes(buffers.keyNorm, uint64_t{shape.headDimension} * 2, "draft key norm");
  const uint64_t ropeBytes = uint64_t{lanes} * kRows * SPLASH_DRAFT_ROPE_PAIRS * 4;
  requireBytes(buffers.ropeCos, ropeBytes, "draft RoPE cosine");
  requireBytes(buffers.ropeSin, ropeBytes, "draft RoPE sine");
  graph.add("draft_attention_qkv",
            {std::move(buffers.qkv), std::move(buffers.groupedQueries),
             std::move(buffers.queryNorm), std::move(buffers.keyNorm),
             std::move(buffers.ropeCos), std::move(buffers.ropeSin),
             std::move(buffers.queryKeys), std::move(buffers.queryValues)},
            {groups, lanes, 1});
}

void DraftAttention::addDecode(
    metal::CommandGraph &graph, DraftDecodeAttentionBuffers buffers,
    std::span<const uint32_t> cacheLengths, const DraftAttentionPlan &plan,
    DraftAttentionGeometry geometry) {
  const auto shape = plan.shape();
  const auto workspace = plan.workspace();
  const uint32_t lanes = plan.lanes();
  requireGeometry(geometry);
  if (cacheLengths.size() != lanes ||
      buffers.persistentKeys.size() != kMaximumLanes ||
      buffers.persistentValues.size() != kMaximumLanes)
    throw std::invalid_argument("invalid draft attention geometry");
  requireBytes(buffers.groupedQueries, workspace.groupedQueriesBytes, "draft grouped queries");
  requireBytes(buffers.queryKeys, workspace.queryKeysBytes, "draft query keys");
  requireBytes(buffers.queryValues, workspace.queryValuesBytes, "draft query values");
  for (uint32_t lane = 0; lane < lanes; ++lane) {
    if (cacheLengths[lane] > SPLASH_MAXIMUM_CONTEXT_TOKENS)
      throw std::invalid_argument("draft attention cache length exceeds limit");
    if (!geometry.slidingWindow && cacheLengths[lane] > geometry.capacity)
      throw std::invalid_argument("draft full attention history exceeds capacity");
    requireBytes(buffers.persistentKeys[lane], ringBytes(shape, geometry), "draft key ring");
    requireBytes(buffers.persistentValues[lane], ringBytes(shape, geometry), "draft value ring");
  }
  DraftAttentionBatchParams params{geometry.capacity, lanes, {}, geometry.capacity,
                                  geometry.slidingWindow, uint32_t(geometry.causal)};
  std::copy(cacheLengths.begin(), cacheLengths.end(),
            std::begin(params.cache_length));
  std::vector<metal::MetalBuffer> bindings{buffers.groupedQueries};
  bindings.reserve(2 * kMaximumLanes + 3);
  appendLaneBindings(bindings, buffers.persistentKeys,
                     buffers.persistentValues);
  bindings.push_back(buffers.queryKeys);
  bindings.push_back(buffers.queryValues);
  graph.add("draft_attention_bf16_split", std::move(bindings), params,
            {shape.kvHeads, lanes, kSplits});
  graph.add("draft_attention_bf16_reduce", {buffers.groupedQueries}, params,
            {shape.kvHeads, lanes, 1}, {SPLASH_DRAFT_ATTENTION_ROWS * 8, 1, 1});
}

void DraftAttention::addReorder(metal::CommandGraph &graph,
                                metal::MetalBuffer grouped,
                                metal::MetalBuffer rowMajor,
                                const DraftAttentionPlan &plan) {
  const auto shape = plan.shape();
  const uint32_t groups =
      phaseGroups(uint64_t{kRows} * shape.queryHeads * shape.headDimension);
  const uint32_t lanes = plan.lanes();
  requireBytes(grouped, queryRowsBytes(plan), "draft grouped attention");
  requireBytes(rowMajor, queryRowsBytes(plan), "draft attention");
  graph.add("draft_attention_reorder", {std::move(grouped), std::move(rowMajor)},
            {groups, lanes, 1});
}

void DraftAttention::addContextPrefill(
    metal::CommandGraph &graph, metal::MetalBuffer contextKv,
    metal::MetalBuffer keyNorm, metal::MetalBuffer ropeCos,
    metal::MetalBuffer ropeSin, metal::MetalBuffer keys,
    metal::MetalBuffer values, uint32_t tokens, uint32_t startPosition,
    DraftAttentionShape shape, DraftAttentionGeometry geometry) {
  static_cast<void>(kernelShape(shape));
  requireGeometry(geometry);
  if (!tokens)
    throw std::invalid_argument("invalid draft context prefill geometry");
  if (tokens > geometry.capacity)
    throw std::invalid_argument("draft context prefill exceeds cache capacity");
  if (!geometry.slidingWindow && uint64_t{startPosition} + tokens > geometry.capacity)
    throw std::invalid_argument("draft full context prefill exceeds capacity");
  requireContextInputs(contextKv, keyNorm, ropeCos, ropeSin, tokens, shape);
  requireBytes(keys, ringBytes(shape, geometry), "draft key ring");
  requireBytes(values, ringBytes(shape, geometry), "draft value ring");
  const DraftContextParams params{tokens, startPosition, geometry.capacity,
                                  geometry.slidingWindow};
  graph.add("prefill_draft_context_kv",
            {std::move(contextKv), std::move(keyNorm), std::move(ropeCos),
             std::move(ropeSin), std::move(keys), std::move(values)},
            params, {uint64_t{tokens} * shape.kvHeads, 1, 1});
}

void DraftAttention::addContextCommit(
    metal::CommandGraph &graph, metal::MetalBuffer contextKv,
    metal::MetalBuffer keyNorm, metal::MetalBuffer ropeCos,
    metal::MetalBuffer ropeSin,
    std::span<const metal::MetalBuffer> persistentKeys,
    std::span<const metal::MetalBuffer> persistentValues,
    metal::MetalBuffer retainedCounts,
    std::span<const uint32_t> startPositions, DraftAttentionShape shape,
    DraftAttentionGeometry geometry) {
  const auto lanes = static_cast<uint32_t>(startPositions.size());
  requireLanes(lanes);
  requireGeometry(geometry);
  static_cast<void>(kernelShape(shape));
  if (persistentKeys.size() != kMaximumLanes ||
      persistentValues.size() != kMaximumLanes)
    throw std::invalid_argument("invalid draft context commit geometry");
  // Each lane commits up to its eight verify rows.
  requireContextInputs(contextKv, keyNorm, ropeCos, ropeSin,
                       uint64_t{lanes} * SPLASH_TARGET_VERIFY_ROWS, shape);
  requireBytes(retainedCounts, uint64_t{lanes} * sizeof(uint32_t), "draft retained counts");
  for (uint32_t lane = 0; lane < lanes; ++lane) {
    if (!geometry.slidingWindow && startPositions[lane] > geometry.capacity)
      throw std::invalid_argument("draft full context commit exceeds capacity");
    requireBytes(persistentKeys[lane], ringBytes(shape, geometry), "draft key ring");
    requireBytes(persistentValues[lane], ringBytes(shape, geometry), "draft value ring");
  }
  DraftContextBatchParams params{{}, geometry.capacity, geometry.slidingWindow};
  std::copy(startPositions.begin(), startPositions.end(),
            std::begin(params.start_position));
  std::vector<metal::MetalBuffer> bindings{
      std::move(contextKv), std::move(keyNorm), std::move(ropeCos),
      std::move(ropeSin)};
  bindings.reserve(2 * kMaximumLanes + 5);
  appendLaneBindings(bindings, persistentKeys, persistentValues);
  bindings.push_back(std::move(retainedCounts));
  graph.add("draft_context_kv_commit", std::move(bindings), params,
            {uint64_t{lanes} * SPLASH_TARGET_VERIFY_ROWS * shape.kvHeads, 1,
             1});
}

uint64_t DraftAttention::contextWindowBytes(uint32_t width) {
  if (!width || width % SPLASH_DRAFT_CONTEXT_GROUP)
    throw std::invalid_argument("draft context rows are whole 64-value groups");
  return draft_context_window_bytes(width);
}

void DraftAttention::addWindowStore(metal::CommandGraph &graph,
                                    metal::MetalBuffer context,
                                    metal::MetalBuffer window, uint32_t rows,
                                    uint32_t startPosition, uint32_t width) {
  const metal::DispatchSize groups = windowGroups(context, window, rows, width);
  graph.add("prefill_draft_context_store", {std::move(context), std::move(window)},
            DraftContextWindowParams{rows, startPosition, width}, groups, {kWindowThreads, 1, 1});
}

void DraftAttention::addWindowLoad(metal::CommandGraph &graph,
                                   metal::MetalBuffer window,
                                   metal::MetalBuffer context, uint32_t rows,
                                   uint32_t startPosition, uint32_t width) {
  const metal::DispatchSize groups = windowGroups(context, window, rows, width);
  graph.add("prefill_draft_context_load", {std::move(window), std::move(context)},
            DraftContextWindowParams{rows, startPosition, width}, groups, {kWindowThreads, 1, 1});
}

} // namespace splash::ops
