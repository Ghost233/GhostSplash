#include "metal/abi/KernelABI.h"
#include "metal/kernels/common/attention_gate.h"
#include "metal/kernels/common/attention_qkv_prepare.h"

// W: the q/k norm weights' stored type (float: a GGUF's F32 norms, _f32).
#define PREFILL_ATTENTION_QKV(Name, QHeads, KHeads, W, Rotate)                        \
  kernel void Name(                                                           \
      device const bfloat *qkv [[buffer(0)]],                                 \
      device const W *q_norm [[buffer(1)]],                                   \
      device const W *k_norm [[buffer(2)]],                                   \
      device const float *rope_cos [[buffer(3)]],                             \
      device const float *rope_sin [[buffer(4)]],                             \
      device bfloat *queries [[buffer(5)]],                                   \
      device bfloat *chunk_keys [[buffer(6)]],                                \
      device bfloat *chunk_values [[buffer(7)]],                              \
      constant FullPrefillParams &params [[buffer(8)]],                       \
      uint task [[threadgroup_position_in_grid]],                             \
      uint thread_index [[thread_index_in_threadgroup]],                      \
      uint lane [[thread_index_in_simdgroup]],                                \
      uint simd_group [[simdgroup_index_in_threadgroup]]) {                   \
    threadgroup float reductions[8];                                          \
    threadgroup bfloat normalized[256];                                       \
    threadgroup float rotation[Rotate ? 256 : 1];                                       \
    full_qkv_storage_phase<QHeads, KHeads, W, Rotate>(                                   \
        qkv, q_norm, k_norm, rope_cos, rope_sin, queries, chunk_keys,         \
        chunk_values, params, reductions, normalized, task, thread_index,     \
        lane, simd_group, rotation);                                                    \
  }
PREFILL_ATTENTION_QKV(prefill_attention_qkv, 24, 4, bfloat, false)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_kv2_g8, 16, 2, bfloat, false)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_kv4_g4, 16, 4, bfloat, false)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_f32, 24, 4, float, false)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_kv2_g8_f32, 16, 2, float, false)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_kv4_g4_f32, 16, 4, float, false)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_q4h, 24, 4, bfloat, true)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_q4h_f32, 24, 4, float, true)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_q4h_kv2_g8, 16, 2, bfloat, true)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_q4h_kv2_g8_f32, 16, 2, float, true)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_q4h_kv4_g4, 16, 4, bfloat, true)
PREFILL_ATTENTION_QKV(prefill_attention_qkv_q4h_kv4_g4_f32, 16, 4, float, true)
#undef PREFILL_ATTENTION_QKV

template <uint QHeads, uint KHeads>
inline void full_attention_gate_prefill_phase(
    device const bfloat *packed_qkv, device const bfloat *attention,
    device bfloat *hidden, constant FullPrefillParams &params, uint index,
    uint grid_size) {
  uint count = params.tokens * QHeads * 256;
  for (uint element = index; element < count; element += grid_size)
    hidden[element] = full_attention_gate_value<QHeads, KHeads>(
        packed_qkv, attention, 0, 0, params.stride, element);
}

#define PREFILL_ATTENTION_GATE(Name, QHeads, KHeads)                           \
  kernel void Name(device const bfloat *packed_qkv [[buffer(0)]],              \
                   device const bfloat *attention [[buffer(1)]],               \
                   device bfloat *hidden [[buffer(2)]],                        \
                   constant FullPrefillParams &params [[buffer(3)]],           \
                   uint index [[thread_position_in_grid]],                     \
                   uint grid_size [[threads_per_grid]]) {                      \
    full_attention_gate_prefill_phase<QHeads, KHeads>(                         \
        packed_qkv, attention, hidden, params, index, grid_size);              \
  }
PREFILL_ATTENTION_GATE(prefill_attention_gate, 24, 4)
PREFILL_ATTENTION_GATE(prefill_attention_gate_kv2_g8, 16, 2)
PREFILL_ATTENTION_GATE(prefill_attention_gate_kv4_g4, 16, 4)
#undef PREFILL_ATTENTION_GATE
