#pragma once

#include "metal/DeviceCapabilities.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace splash::metal {

enum class AllocationFailure : uint8_t {
  None,
  EngineBudget,
  HostPressure,
  DriverRejected,
};

struct AllocationResult final {
  AllocationFailure failure = AllocationFailure::None;
  // Granted.
  AllocationResult() noexcept = default;
  AllocationResult(AllocationFailure reason) noexcept : failure(reason) {}
  [[nodiscard]] explicit operator bool() const noexcept {
    return failure == AllocationFailure::None;
  }
};

[[nodiscard]] constexpr const char *allocationFailureName(
    AllocationFailure failure) noexcept {
  switch (failure) {
  case AllocationFailure::None: return "none";
  case AllocationFailure::EngineBudget: return "engine memory budget exceeded";
  case AllocationFailure::HostPressure: return "host memory reserve protected";
  case AllocationFailure::DriverRejected:
    return "Metal driver rejected allocation";
  }
  return "unknown allocation failure";
}

// Allocators use this callback to obtain engine-governed headroom
// without depending on the engine policy type. The operation runs while the
// caller's reservation is held; the callback returns the refusal's cause,
// with no side effects, when admission is denied.
using AllocationAdmission =
    std::function<AllocationResult(uint64_t, const std::function<void()> &)>;

enum class BufferStorage {
  Shared,
  Private,
};

class MetalBackend;
class CommandTicket;

// A cheap, copyable reference to a backend-owned Metal allocation. Views keep
// the base allocation alive and do not increase the tracked allocation count.
class MetalBuffer final {
public:
  MetalBuffer();
  ~MetalBuffer();
  MetalBuffer(const MetalBuffer &);
  MetalBuffer &operator=(const MetalBuffer &);
  MetalBuffer(MetalBuffer &&) noexcept;
  MetalBuffer &operator=(MetalBuffer &&) noexcept;

  [[nodiscard]] explicit operator bool() const noexcept;
  [[nodiscard]] uint64_t sizeBytes() const noexcept;
  // The base allocation's MTLResource.allocatedSize, as memoryStats() counts
  // it; views of one allocation all report it.
  [[nodiscard]] uint64_t allocatedBytes() const noexcept;
  [[nodiscard]] BufferStorage storage() const noexcept;
  // Returns nullptr for private buffers and released memory
  // (MetalBackend::releaseMemory). The pointer covers this view only.
  [[nodiscard]] void *contents() const noexcept;
  // GPU address of the view's first byte, for kernels that reach a buffer
  // through an address another buffer holds.
  [[nodiscard]] uint64_t gpuAddress() const noexcept;
  // Allocation identity and exact view range, including Private storage.
  // This compares metadata only; it never maps or reads device contents.
  [[nodiscard]] bool sameView(const MetalBuffer &other) const noexcept;

private:
  struct Impl;
  explicit MetalBuffer(std::shared_ptr<Impl> impl);

  std::shared_ptr<Impl> impl_;

  friend class MetalBackend;
};

// A shared event another agent, such as the Neural Engine, waits on or
// signals. Copies name the same event. nativeHandle() is its
// id<MTLSharedEvent> for Objective-C++ callers. Its value never decreases:
// Metal ignores a signal below it, from the CPU as from the GPU.
class SharedEvent final {
public:
  SharedEvent();
  ~SharedEvent();
  SharedEvent(const SharedEvent &);
  SharedEvent &operator=(const SharedEvent &);
  SharedEvent(SharedEvent &&) noexcept;
  SharedEvent &operator=(SharedEvent &&) noexcept;

  [[nodiscard]] explicit operator bool() const noexcept;
  [[nodiscard]] void *nativeHandle() const noexcept;
  // Raises the event to `value` from the CPU.
  void signal(uint64_t value) const noexcept;
  // Calls `callback` once, when the event reaches `value`, promptly if it
  // already has. Callbacks run on a serial dispatch queue of the backend
  // that created the event, one at a time and never within notify(); they
  // must not throw.
  void notify(uint64_t value, std::function<void()> callback) const;

private:
  struct Impl;
  explicit SharedEvent(std::shared_ptr<Impl> impl);

  std::shared_ptr<Impl> impl_;

  friend class MetalBackend;
};

struct DispatchSize {
  uint64_t x = 1;
  uint64_t y = 1;
  uint64_t z = 1;
};

struct BufferBinding {
  uint32_t index = 0;
  MetalBuffer buffer;
};

// The pointed-to data only needs to remain valid until submit() returns.
struct BytesBinding {
  uint32_t index = 0;
  const void *data = nullptr;
  uint64_t sizeBytes = 0;
};

// A grid the GPU reads as the dispatch starts, so an earlier dispatch of the
// same command may write it: three uint32 threadgroup counts, x, y and z
// (MTLDispatchThreadgroupsIndirectArguments), at offsetBytes into buffer and
// at a multiple of 4 bytes into its allocation.
struct IndirectGrid {
  MetalBuffer buffer;
  uint64_t offsetBytes = 0;
};

struct ComputeDispatch {
  std::string pipelineName;
  std::vector<BufferBinding> buffers;
  std::vector<BytesBinding> bytes;
  // With a buffer in indirectThreadgroups the dispatch runs the grid it
  // holds, which its writer keeps within threadgroups.
  DispatchSize threadgroups;
  DispatchSize threadsPerThreadgroup;
  IndirectGrid indirectThreadgroups = {};
  // Host-only metadata, appended to preserve existing aggregate initializers.
  std::string attribution{};
  uint32_t logicalRows = 0;
  bool commandBufferBoundaryAfter = false;
};

// Orders a command against another agent, such as the Neural Engine, after
// the first `before` of its dispatches. A Signal raises the event to `value`
// once all earlier work has completed; a Wait holds all later work until the
// event reaches `value`. A command is split into Metal command buffers at its
// signals, so a signal is never held back behind the dispatches that follow
// it, and a signal is delivered even when the work before it fails.
struct EventStep {
  enum class Kind : uint8_t { Signal, Wait };

  size_t before = 0;
  SharedEvent event;
  uint64_t value = 0;
  Kind kind = Kind::Signal;
};

// What one submission encodes: its dispatches in order, and the event steps
// between them in the order of their `before`.
struct Command {
  std::span<const ComputeDispatch> dispatches;
  std::span<const EventStep> events;
};

struct DispatchTimestamp final {
  std::string pipelineName, attribution;
  uint32_t logicalRows = 0;
  uint64_t beginTicks = 0, endTicks = 0;
  bool followsEventWait = false;
};
struct CommandTimestampProfile final {
  std::vector<DispatchTimestamp> dispatches;
  double gpuSpanSeconds = 0;
  bool encoderBoundarySamples = false;
  bool valid = false;
  std::string error;
};

struct CommandTiming {
  // From the GPU start of a command's first Metal command buffer to the end
  // of its last: a command split at event signals (EventStep) also counts the
  // time its later buffers wait for the other agent.
  double gpuSeconds = 0.0;
  double wallSeconds = 0.0;
};

// Move-only ownership of one submitted Metal command. Completion is signalled
// without blocking the submitting thread; wait() is normally called only
// after the host event loop receives the completion notification.
// Destroying or replacing an unfinished ticket waits for GPU completion and
// retains its allocations throughout that wait. Each of these waits runs the
// command watchdog every second: once the watchdog gives up on the command,
// wait() throws MetalBackendError and destruction or replacement returns,
// leaving the allocations to the command's completion handler.
class CommandTicket final {
public:
  CommandTicket();
  ~CommandTicket();
  CommandTicket(const CommandTicket &) = delete;
  CommandTicket &operator=(const CommandTicket &) = delete;
  CommandTicket(CommandTicket &&) noexcept;
  CommandTicket &operator=(CommandTicket &&) noexcept;

  [[nodiscard]] bool ready() const noexcept;
  [[nodiscard]] CommandTiming wait();

private:
  struct State;
  explicit CommandTicket(std::shared_ptr<State> state);

  std::shared_ptr<State> state_;

  friend class MetalBackend;
};

using CommandCompletion = std::function<void()>;

// Bytes one allocation added between two memoryStats() readings.
[[nodiscard]] inline uint64_t allocationDelta(uint64_t before, uint64_t after) {
  if (after < before)
    throw std::logic_error("Metal allocation accounting moved backwards");
  return after - before;
}

struct MetalMemoryStats {
  // Sum of MTLResource.allocatedSize for live base buffers created through
  // this backend. Views share their base allocation and add no bytes.
  uint64_t allocatedBytes = 0;
  uint64_t peakAllocatedBytes = 0;

  // Most recently sampled Metal device-wide process counter. Allocation and
  // command lifecycle boundaries refresh it; status reads never synchronize
  // with an in-flight GPU command.
  uint64_t deviceCurrentAllocatedBytes = 0;
  // Highest sampled device.currentAllocatedSize. Sampled after allocations
  // and pipeline creation, on host-side retirement and whenever admission
  // refreshes the stats.
  uint64_t devicePeakAllocatedBytes = 0;
};

class MetalBackendError : public std::runtime_error {
public:
  using std::runtime_error::runtime_error;
};

// A normal capacity failure. Callers may evict cache or return a retryable
// admission error; the Metal backend remains healthy. MemoryGovernor's
// allocationAdmission is the one place it becomes a value (AllocationResult).
class MetalAllocationError final : public MetalBackendError {
public:
  explicit MetalAllocationError(
      std::string message,
      AllocationFailure failure = AllocationFailure::DriverRejected)
      : MetalBackendError(std::move(message)), failure_(failure) {}
  [[nodiscard]] AllocationFailure failure() const noexcept { return failure_; }
private:
  AllocationFailure failure_;
};

// The capabilities a backend reads, without loading kernels or allocating:
// enough to refuse an unsupported Mac before a model is downloaded.
[[nodiscard]] DeviceCapabilities probeDeviceCapabilities();

// How long a command may run before the backend gives up on it by default,
// in time the Mac is awake (AwakeClock).
inline constexpr double kCommandTimeoutSeconds = 120.0;
// How long every buffer stays wired after the last command by default (see
// allocateBuffer), also the default of the engine's idle release
// (RuntimeResourcesConfig::idleReleaseSeconds).
inline constexpr double kResidencyKeepAliveSeconds = 600.0;
static_assert(kCommandTimeoutSeconds > 0.0 && kResidencyKeepAliveSeconds > 0.0);

// Permits exactly one submitted-but-not-applied command on its command queue.
// One thread submits, allocates and looks up pipelines; checkHealth(),
// healthy(), unhealthyReason(), memoryStats() and commandInFlight() may be
// called from any thread.
class MetalBackend final {
public:
  // Buffers stay wired for residencyKeepAliveSeconds after the last command;
  // an infinite keep-alive holds them while the backend lives. The watchdog
  // gives up on a command that runs longer than commandTimeoutSeconds.
  explicit MetalBackend(std::string metallibPath,
                        double residencyKeepAliveSeconds = kResidencyKeepAliveSeconds,
                        double commandTimeoutSeconds = kCommandTimeoutSeconds);
  ~MetalBackend();
  // Invoked before allocations and submissions; may throw to stop bootstrap.
  void setOperationGuard(std::function<void()> guard);
  // Asked between the slices of a ticket's wait(); true gives up the wait as
  // the watchdog does and marks the backend unhealthy: the process is
  // shutting down. Destroying or replacing a ticket still waits for its
  // command.
  void setWaitInterrupt(std::function<bool()> shuttingDown);
  void checkOperation() const;
  // Stop new submissions before teardown. Commands already committed to the
  // GPU retain their normal lifetime.
  void stop() noexcept;

  MetalBackend(const MetalBackend &) = delete;
  MetalBackend &operator=(const MetalBackend &) = delete;
  MetalBackend(MetalBackend &&) = delete;
  MetalBackend &operator=(MetalBackend &&) = delete;

  [[nodiscard]] const DeviceCapabilities &capabilities() const noexcept;

  // Every buffer the backend allocates belongs to one residency set, attached
  // to the command queue, until its memory is released or its last view is
  // gone. Metal by itself wires a buffer only while a command uses it and a
  // few seconds after, so memory pressure could compress idle state and the
  // next request would wait to get it back. A member is wired from
  // its allocation on until the keep-alive passes without a command, and
  // again from the next command: memory goes back to macOS when the engine
  // releases it, not when macOS chooses. Kernels may also reach a Shared
  // buffer only through its GPU address held in another buffer, as they
  // reach KV extents: residency makes it resident for every command, so no
  // command names it.
  [[nodiscard]] MetalBuffer
  allocateBuffer(uint64_t bytes, BufferStorage storage,
                 std::string_view label);
  // A Shared buffer over whole pages of memory another agent also reads or
  // writes, such as an IOSurface of the Neural Engine, without a copy. Metal
  // keeps `owner` until it lets the buffer go; the memory is the owner's, so
  // releaseMemory refuses it.
  [[nodiscard]] MetalBuffer wrapSharedMemory(void *address, uint64_t bytes,
                                             std::shared_ptr<void> owner,
                                             std::string_view label);

  [[nodiscard]] MetalBuffer view(const MetalBuffer &base, uint64_t offsetBytes,
                                 uint64_t lengthBytes) const;
  // An event at value 0, whose notify() callbacks run on this backend's
  // event queue.
  [[nodiscard]] SharedEvent newSharedEvent();

  // Frees the memory of a buffer from allocateBuffer while no command is in
  // flight: it leaves the residency set and the accounting. Its views stay
  // valid handles of no memory: a command that binds one fails, and their
  // contents are null and GPU addresses 0, until restoreMemory allocates the
  // buffer's memory again, at another GPU address, its contents undefined
  // until written.
  void releaseMemory(const MetalBuffer &buffer);
  void restoreMemory(const MetalBuffer &buffer);

  // Encodes exactly one compute dispatch, commits it, waits for completion,
  // and reports both GPU and end-to-end wall time.
  [[nodiscard]] CommandTiming submit(const ComputeDispatch &dispatch);

  // Encodes a command into Metal command buffers, one more than it has event
  // signals (EventStep), and commits them without waiting. The completion
  // callback only notifies host control flow; command results and errors are
  // consumed from the returned ticket, which reports the error of the first
  // of its buffers that failed. A second command is rejected until wait()
  // consumes the first ticket, preserving the one-in-flight runtime
  // invariant.
  [[nodiscard]] CommandTicket
  submitCommandAsync(const Command &command, CommandCompletion completion = {});
  // A command of these dispatches without event steps: one command buffer.
  [[nodiscard]] CommandTicket
  submitCommandAsync(std::span<const ComputeDispatch> dispatches,
                     CommandCompletion completion = {});

  // Startup: compiles now the pipelines a later submission of these
  // dispatches would compile. Validates them as submission does and throws
  // as it would, but encodes and commits nothing.
  void preparePipelines(std::span<const ComputeDispatch> dispatches);
  // Called on the submitting thread after a successful commit, without a GPU wait.
  // The observer must not throw, submit work or retain the borrowed command.
  void setSubmissionObserver(std::function<void(const Command &)> observer);
  // Diagnostic only: barriers around samples perturb execution. Resolved at the
  // existing ticket wait, not by adding host waits. Returns why unavailable.
  [[nodiscard]] std::string setTimestampObserver(std::function<void(const CommandTimestampProfile &)> observer);

  [[nodiscard]] MetalMemoryStats memoryStats() const noexcept;
  // Explicit safe-point refresh for memory admission/reclamation code. A
  // control-plane status query must use memoryStats() so it can never wait
  // behind an active Metal command.
  [[nodiscard]] MetalMemoryStats refreshMemoryStats() const noexcept;
  // True from a submission until its ticket has been consumed: while memory
  // the command reaches through addresses must stay allocated.
  [[nodiscard]] bool commandInFlight() const noexcept;
  [[nodiscard]] bool healthy() const noexcept;
  // Serving-loop check of the command in flight. Terminal results may invoke
  // completion here if the driver callback is delayed.
  // Timeout marks the backend unhealthy without releasing in-flight resources.
  // A synchronous ticket wait runs the same command watchdog.
  void checkHealth();
  [[nodiscard]] std::string unhealthyReason() const;

private:
  struct Impl;
  std::unique_ptr<Impl> impl_;

  friend class BackendInstrumentation;
};

} // namespace splash::metal
