#include "engine/KvCache.hpp"

#include <algorithm>
#include <limits>
#include <stdexcept>
#include <unordered_set>
#include <utility>

namespace splash::engine {
namespace {

uint64_t mix(uint64_t hash, uint64_t value) noexcept {
  hash ^= value + 0x9e3779b97f4a7c15ULL + (hash << 6) + (hash >> 2);
  return hash;
}

uint64_t indexHash(uint64_t parentHash, std::span<const uint32_t> tokens,
                   ImageIdentity images) noexcept {
  uint64_t hash = mix(0x6a09e667f3bcc909ULL, parentHash);
  for (uint32_t token : tokens)
    hash = mix(hash, token);
  hash = mix(hash, images.lo);
  hash = mix(hash, images.hi);
  return hash;
}

} // namespace

ImageIdentity blockImageIdentity(uint64_t blockBegin, uint32_t blockTokens,
                                 std::span<const ImageSpan> spans) noexcept {
  ImageIdentity identity;
  const uint64_t blockEnd = blockBegin + blockTokens;
  for (const ImageSpan &span : spans) {
    if (span.offset >= blockEnd)
      break;
    if (span.end() <= blockBegin)
      continue;
    // Two independently seeded chains fold the content digest, the grid, and
    // the block's alignment inside the span into 128 bits.
    uint64_t lo = identity.lo ? identity.lo : 0x243f6a8885a308d3ULL;
    uint64_t hi = identity.hi ? identity.hi : 0x13198a2e03707344ULL;
    for (uint64_t value :
         {span.digestLo, span.digestHi,
          (uint64_t{span.gridHeight} << 32) | span.gridWidth,
          (uint64_t{span.offset} << 32) | span.tokens, blockBegin}) {
      lo = mix(lo, value);
      hi = mix(hi, ~value);
    }
    identity = {lo, hi};
  }
  return identity;
}

KvCache::~KvCache() noexcept {
  for (const auto &[_, entry] : blocks_) {
    if (entry.page == noPage)
      continue;
    try {
      pool_.releasePage(entry.page, true);
    } catch (...) {
      std::terminate();
    }
  }
}

std::optional<KvCache::BlockMatch>
KvCache::find(uint64_t parentBlock, std::span<const uint32_t> tokens,
              ImageIdentity images) const {
  if (tokens.size() != pageTokens) {
    return std::nullopt;
  }
  if (parentBlock && !blocks_.contains(parentBlock))
    return std::nullopt;
  const uint64_t hash = indexHash(parentBlock ? block(parentBlock).indexHash : 0, tokens, images);
  const auto [first, last] = index_.equal_range(hash);
  for (auto candidate = first; candidate != last; ++candidate) {
    const Block &entry = block(candidate->second);
    // Hashes filter candidates; equality requires the complete key.
    if (!entry.poisoned && entry.parent == parentBlock && entry.images == images &&
        std::equal(entry.tokens.begin(), entry.tokens.end(), tokens.begin())) {
      return BlockMatch{entry.id, entry.page};
    }
  }
  return std::nullopt;
}

KvCache::BlockMatch KvCache::insert(uint64_t parentBlock,
                                    std::span<const uint32_t> tokens,
                                    uint32_t physicalPage,
                                    ImageIdentity images) {
  if (tokens.size() != pageTokens) {
    throw std::invalid_argument("KV cache block must contain one full page");
  }
  if (physicalPage >= pool_.pageCount()) {
    throw std::out_of_range("KV cache physical page is out of range");
  }
  if (auto existing = find(parentBlock, tokens, images)) {
    BlockMatch result{existing->id, existing->physicalPage};
    if (existing->physicalPage == noPage) {
      adoptPage(existing->id, physicalPage);
      result.physicalPage = physicalPage;
    } else if (block(existing->id).transferring) {
      // Its page is still being filled; the writer keeps its own copy.
      result.physicalPage = physicalPage;
    }
    return result;
  }
  if (parentBlock && !blocks_.contains(parentBlock)) {
    throw std::invalid_argument("KV cache parent block is unknown");
  }
  if (parentBlock && block(parentBlock).page == noPage) {
    throw std::logic_error("KV cache parent block has no page");
  }
  if (parentBlock &&
      block(parentBlock).children == std::numeric_limits<uint32_t>::max()) {
    throw std::overflow_error("KV cache child count overflowed");
  }
  if (!nextBlockId_ || nextBlockId_ == std::numeric_limits<uint64_t>::max()) {
    throw std::overflow_error("KV cache block ids exhausted");
  }
  if (blockOnPage_[physicalPage])
    throw std::logic_error("KV cache page already holds a block");

  Block entry;
  entry.id = nextBlockId_;
  entry.parent = parentBlock;
  entry.indexHash = indexHash(parentBlock ? block(parentBlock).indexHash : 0, tokens, images);
  std::copy(tokens.begin(), tokens.end(), entry.tokens.begin());
  entry.images = images;
  entry.page = physicalPage;
  entry.depth = parentBlock ? block(parentBlock).depth + 1 : 1;
  entry.ramNode = RecencyOrder::allocate();
  entry.diskNode = RecencyOrder::allocate();
  entry.unneededNode = RecencyOrder::allocate();

  pool_.retainPage(physicalPage, true);
  auto [position, unique] = blocks_.emplace(entry.id, std::move(entry));
  if (!unique)
    throw std::logic_error("duplicate KV cache block id");
  index_.emplace(position->second.indexHash, position->first);
  const uint64_t id = nextBlockId_++;
  blockOnPage_[physicalPage] = id;
  Block &placed = block(id);
  if (parentBlock) {
    Block &parent = block(parentBlock);
    ++parent.children;
    ++parent.residentChildren;
    if (parent.firstChild)
      block(parent.firstChild).previousSibling = id;
    placed.nextSibling = parent.firstChild;
    parent.firstChild = id;
    reindex(parent);
  }
  placed.lastUsed = recency_.next();
  reindex(placed);
  ++generation_;
  return {id, physicalPage};
}

bool KvCache::adoptDiskBlock(uint64_t blockId, uint64_t parentBlock,
                             std::span<const uint32_t> tokens, ImageIdentity images,
                             std::shared_ptr<KvDiskSlot> slot, uint64_t lastUsed) {
  if (!blockId || blockId == std::numeric_limits<uint64_t>::max() || blocks_.contains(blockId) ||
      tokens.size() != pageTokens || !slot)
    throw std::invalid_argument("invalid adopted KV cache block");
  if (parentBlock && !blocks_.contains(parentBlock))
    throw std::invalid_argument("adopted KV cache block's parent is unknown");
  if (find(parentBlock, tokens, images))
    return false;
  if (parentBlock && block(parentBlock).children == std::numeric_limits<uint32_t>::max())
    throw std::overflow_error("KV cache child count overflowed");
  Block entry;
  entry.id = blockId;
  entry.parent = parentBlock;
  entry.indexHash = indexHash(parentBlock ? block(parentBlock).indexHash : 0, tokens, images);
  std::copy(tokens.begin(), tokens.end(), entry.tokens.begin());
  entry.images = images;
  entry.depth = parentBlock ? block(parentBlock).depth + 1 : 1;
  entry.lastUsed = lastUsed;
  entry.ramNode = RecencyOrder::allocate();
  entry.diskNode = RecencyOrder::allocate();
  entry.unneededNode = RecencyOrder::allocate();
  Block &placed = blocks_.emplace(blockId, std::move(entry)).first->second;
  index_.emplace(placed.indexHash, blockId);
  giveDiskCopy(placed, std::move(slot));
  if (parentBlock) {
    Block &parent = block(parentBlock);
    ++parent.children;
    if (parent.firstChild)
      block(parent.firstChild).previousSibling = blockId;
    placed.nextSibling = parent.firstChild;
    parent.firstChild = blockId;
    reindex(parent);
  }
  nextBlockId_ = std::max(nextBlockId_, blockId + 1);
  reindex(placed);
  ++generation_;
  return true;
}

void KvCache::continueIdsAfter(uint64_t blockId) noexcept {
  if (blockId != std::numeric_limits<uint64_t>::max())
    nextBlockId_ = std::max(nextBlockId_, blockId + 1);
}

KvCache::Key KvCache::key(uint64_t blockId) const {
  const Block &entry = block(blockId);
  return {entry.parent, entry.tokens, entry.images};
}

uint64_t KvCache::lastUsed(uint64_t blockId) const { return block(blockId).lastUsed; }

bool KvCache::transferring(uint64_t blockId) const { return block(blockId).transferring; }

std::vector<uint64_t> KvCache::children(uint64_t blockId) const {
  std::vector<uint64_t> result;
  for (uint64_t child = block(blockId).firstChild; child; child = block(child).nextSibling)
    result.push_back(child);
  return result;
}

void KvCache::retainActive(uint64_t blockId) {
  Block &entry = block(blockId);
  if (entry.activeUsers == std::numeric_limits<uint32_t>::max()) {
    throw std::overflow_error("KV cache active user count overflowed");
  }
  ++entry.activeUsers;
  entry.lastUsed = recency_.next();
  reindex(entry);
}

void KvCache::releaseActive(uint64_t blockId) noexcept {
  auto found = blocks_.find(blockId);
  if (found == blocks_.end() || !found->second.activeUsers)
    std::terminate();
  Block &entry = found->second;
  --entry.activeUsers;
  // A released leaf is the newest; a parent keeps the recency its children
  // pass on.
  if (!entry.activeUsers && !entry.children)
    entry.lastUsed = recency_.next();
  reindex(entry);
  erasePoisonedLeaf(blockId);
}

void KvCache::touch(uint64_t blockId) noexcept {
  auto found = blocks_.find(blockId);
  if (found == blocks_.end())
    std::terminate();
  found->second.lastUsed = recency_.next();
  reindex(found->second);
}

KvCache::Chain KvCache::chain(uint64_t blockId) const {
  const uint32_t depth = chainLength(blockId);
  Chain result;
  result.blocks.resize(depth);
  result.pages.resize(depth);
  for (uint32_t index = depth; index > 0; --index) {
    const Block &entry = block(blockId);
    result.blocks[index - 1] = entry.id;
    result.pages[index - 1] = entry.page;
    blockId = entry.parent;
  }
  if (blockId)
    throw std::logic_error("KV cache chain exceeds its depth");
  return result;
}

bool KvCache::contains(uint64_t blockId) const noexcept {
  return blocks_.contains(blockId);
}

bool KvCache::matchable(uint64_t blockId) const noexcept {
  const auto found = blocks_.find(blockId);
  return found != blocks_.end() && !found->second.poisoned;
}

uint32_t KvCache::chainLength(uint64_t blockId) const {
  return block(blockId).depth;
}

uint32_t KvCache::page(uint64_t blockId) const { return block(blockId).page; }

std::shared_ptr<KvDiskSlot> KvCache::slot(uint64_t blockId) const {
  return block(blockId).slot;
}

bool KvCache::hasDiskChildren(uint64_t blockId) const {
  const Block &entry = block(blockId);
  return entry.children > entry.residentChildren;
}

template <typename Count>
void KvCache::countAbove(uint64_t blockId, const Count &count) noexcept {
  const auto found = blocks_.find(blockId);
  if (found == blocks_.end())
    std::terminate();
  for (uint64_t above = found->second.parent; above;) {
    const auto parent = blocks_.find(above);
    if (parent == blocks_.end())
      std::terminate();
    count(parent->second);
    above = parent->second.parent;
  }
}

void KvCache::countState(uint64_t blockId, bool added, bool inUse) noexcept {
  const auto found = blocks_.find(blockId);
  if (found == blocks_.end())
    std::terminate();
  added ? ++found->second.statesHere : --found->second.statesHere;
  reindex(found->second);
  countAbove(blockId, [&](Block &entry) {
    added ? ++entry.statesBelow : --entry.statesBelow;
    if (inUse)
      added ? ++entry.statesInUseBelow : --entry.statesInUseBelow;
    // Its copy is needed again, or no longer.
    if (entry.statesBelow == (added ? 1u : 0u))
      reindex(entry);
  });
}

void KvCache::countStateInUse(uint64_t blockId, bool added) noexcept {
  countAbove(blockId, [&](Block &entry) {
    added ? ++entry.statesInUseBelow : --entry.statesInUseBelow;
  });
}

bool KvCache::stateBelow(uint64_t blockId) const { return block(blockId).statesBelow > 0; }

bool KvCache::stateInUseBelow(uint64_t blockId) const {
  return block(blockId).statesInUseBelow > 0;
}

void KvCache::noteState(uint64_t blockId) { block(blockId).hadState = true; }

bool KvCache::hadState(uint64_t blockId) const { return block(blockId).hadState; }

uint32_t KvCache::idlePagesOnChains(std::span<const uint64_t> blocks) const {
  std::unordered_set<uint64_t> visited;
  uint32_t pages = 0;
  for (uint64_t blockId : blocks) {
    while (blockId && visited.insert(blockId).second) {
      const Block &entry = block(blockId);
      if (entry.page != noPage) {
        // The request holding this page holds every page above it too.
        if (pool_.pageActive(entry.page))
          break;
        if (!entry.transferring)
          ++pages;
      }
      // A disk-only block holds no page; the walk goes on above it.
      blockId = entry.parent;
    }
  }
  return pages;
}

bool KvCache::residentLeaf(uint64_t blockId) const {
  const Block &entry = block(blockId);
  return entry.page != noPage && !entry.residentChildren && !entry.activeUsers &&
         !entry.transferring && !entry.poisoned;
}

void KvCache::setTransferring(uint64_t blockId, bool transferring) {
  Block &entry = block(blockId);
  if (entry.transferring == transferring)
    throw std::logic_error("KV cache block transfer state did not change");
  entry.transferring = transferring;
  reindex(entry);
}

void KvCache::setSlot(uint64_t blockId, std::shared_ptr<KvDiskSlot> slot) {
  Block &entry = block(blockId);
  if (!slot && entry.page == noPage)
    throw std::logic_error("a disk-only KV cache block is erased, not stripped");
  giveDiskCopy(entry, std::move(slot));
  reindex(entry);
}

void KvCache::giveDiskCopy(Block &entry, std::shared_ptr<KvDiskSlot> slot) noexcept {
  if (static_cast<bool>(entry.slot) != static_cast<bool>(slot))
    slot ? ++diskBlocks_ : --diskBlocks_;
  entry.slot = std::move(slot);
}

void KvCache::followPages(const KvPageMoves &moves) noexcept {
  // Destinations lie in other extents and were free, so no block is on one.
  for (uint32_t offset = 0; offset < moves.destinations.size(); ++offset) {
    const uint32_t from = moves.firstPage + offset;
    const uint32_t to = moves.destinations[offset];
    if (to == from)
      continue;
    const uint64_t id = std::exchange(blockOnPage_[from], 0);
    if (!id)
      continue;
    const auto found = blocks_.find(id);
    if (found == blocks_.end())
      std::terminate();
    found->second.page = to;
    blockOnPage_[to] = id;
  }
}

bool KvCache::abandonRestore(uint64_t blockId) {
  Block &entry = block(blockId);
  if (!entry.transferring || entry.residentChildren || entry.activeUsers)
    return false;
  setTransferring(blockId, false);
  dropPage(blockId);
  return true;
}

void KvCache::dropPage(uint64_t blockId) {
  Block &entry = block(blockId);
  if (entry.page == noPage || !entry.slot)
    throw std::logic_error("KV cache block has no page to drop or no disk copy");
  if (entry.residentChildren || entry.activeUsers)
    throw std::logic_error("KV cache block is still in use");
  const uint32_t page = entry.page;
  entry.page = noPage;
  blockOnPage_[page] = 0;
  reindex(entry);
  if (entry.parent) {
    Block &parent = block(entry.parent);
    --parent.residentChildren;
    inherit(parent, entry.lastUsed);
  }
  pool_.releasePage(page, true);
}

// A parent that becomes a leaf when a child leaves its tier inherits the
// child's recency: it was used no later than the child and must not jump
// ahead of colder chains.
void KvCache::inherit(Block &parent, uint64_t lastUsed) noexcept {
  const bool leaf = parent.page != noPage ? !parent.residentChildren : !parent.children;
  if (leaf && !parent.activeUsers)
    parent.lastUsed = std::max(parent.lastUsed, lastUsed);
  reindex(parent);
}

void KvCache::adoptPage(uint64_t blockId, uint32_t page) {
  Block &entry = block(blockId);
  if (entry.page != noPage)
    throw std::logic_error("KV cache block already has a page");
  if (page >= pool_.pageCount())
    throw std::out_of_range("KV cache physical page is out of range");
  if (entry.parent && block(entry.parent).page == noPage)
    throw std::logic_error("KV cache parent block has no page");
  if (blockOnPage_[page])
    throw std::logic_error("KV cache page already holds a block");
  pool_.retainPage(page, true);
  entry.page = page;
  blockOnPage_[page] = blockId;
  reindex(entry);
  if (entry.parent) {
    Block &parent = block(entry.parent);
    ++parent.residentChildren;
    reindex(parent);
  }
}

void KvCache::poison(uint64_t blockId) {
  Block &entry = block(blockId);
  entry.poisoned = true;
  // It matches no lookup from now on.
  ++generation_;
  giveDiskCopy(entry, nullptr);
  reindex(entry);
  erasePoisonedLeaf(blockId);
}

std::optional<CacheEvictionCandidate>
KvCache::evictionCandidate(uint64_t after) const {
  if (!after)
    return ramLeaves_.oldest();
  return ramLeaves_.next({after, block(after).lastUsed});
}

std::optional<CacheEvictionCandidate>
KvCache::diskCandidate(bool duplicate, uint64_t after) const {
  const RecencyOrder &order = duplicate ? duplicates_ : diskLeaves_;
  if (!after)
    return order.oldest();
  return order.next({after, block(after).lastUsed});
}

std::vector<uint64_t> KvCache::subtree(uint64_t blockId) const {
  std::vector<uint64_t> order;
  std::vector<std::pair<uint64_t, bool>> pending{{blockId, false}};
  while (!pending.empty()) {
    const auto [id, expanded] = pending.back();
    pending.pop_back();
    if (expanded) {
      if (id != blockId)
        order.push_back(id);
      continue;
    }
    const Block &entry = block(id);
    if (id != blockId && (entry.transferring || entry.activeUsers))
      return {};
    pending.push_back({id, true});
    for (uint64_t child = entry.firstChild; child; child = block(child).nextSibling)
      pending.push_back({child, false});
  }
  return order;
}

void KvCache::erase(uint64_t blockId) {
  Block &candidate = block(blockId);
  if (candidate.children || candidate.activeUsers || candidate.transferring) {
    throw std::logic_error("cannot evict a referenced KV cache block");
  }
  const uint64_t parentId = candidate.parent;
  const uint64_t previous = candidate.previousSibling;
  const uint64_t next = candidate.nextSibling;
  const uint64_t hash = candidate.indexHash;
  const uint32_t page = candidate.page;
  const uint64_t lastUsed = candidate.lastUsed;
  const bool disk = candidate.slot != nullptr;
  const auto [first, last] = index_.equal_range(hash);
  auto indexed = std::find_if(
      first, last, [&](const auto &value) { return value.second == blockId; });
  if (indexed == last)
    throw std::logic_error("KV cache index is incomplete");
  RecencyOrder::unlink(candidate.ramNode);
  RecencyOrder::unlink(candidate.diskNode);
  RecencyOrder::unlink(candidate.unneededNode);
  index_.erase(indexed);
  blocks_.erase(blockId);
  ++generation_;
  if (page != noPage)
    blockOnPage_[page] = 0;
  if (disk)
    --diskBlocks_;
  if (parentId) {
    Block &parent = block(parentId);
    if (!parent.children)
      throw std::logic_error("KV child count underflowed");
    --parent.children;
    (previous ? block(previous).nextSibling : parent.firstChild) = next;
    if (next)
      block(next).previousSibling = previous;
    if (page != noPage)
      --parent.residentChildren;
    inherit(parent, lastUsed);
    erasePoisonedLeaf(parentId);
  }
  if (page != noPage)
    pool_.releasePage(page, true);
}

KvCache::Block &KvCache::block(uint64_t blockId) {
  auto found = blocks_.find(blockId);
  if (found == blocks_.end())
    throw std::out_of_range("unknown KV cache block");
  return found->second;
}

const KvCache::Block &KvCache::block(uint64_t blockId) const {
  auto found = blocks_.find(blockId);
  if (found == blocks_.end())
    throw std::out_of_range("unknown KV cache block");
  return found->second;
}

// Resident leaves wait in one order, disk copies in another: redundant
// copies of resident blocks, or disk-only blocks without children. The disk
// copies no state needs wait in a third as well. A block a request uses, one
// in transfer, or a poisoned one is in no order.
void KvCache::reindex(Block &entry) noexcept {
  RecencyOrder::unlink(entry.ramNode);
  RecencyOrder::unlink(entry.diskNode);
  RecencyOrder::unlink(entry.unneededNode);
  if (entry.activeUsers || entry.transferring || entry.poisoned)
    return;
  const bool resident = entry.page != noPage;
  if (resident && !entry.residentChildren)
    ramLeaves_.link(entry.ramNode, entry.lastUsed, entry.id);
  if (entry.slot && resident)
    duplicates_.link(entry.diskNode, entry.lastUsed, entry.id);
  else if (entry.slot && !entry.children)
    diskLeaves_.link(entry.diskNode, entry.lastUsed, entry.id);
  if (entry.slot && !entry.statesHere && !entry.statesBelow && (resident || !entry.children))
    unneeded_.link(entry.unneededNode, entry.lastUsed, entry.id);
}

void KvCache::erasePoisonedLeaf(uint64_t blockId) noexcept {
  const auto found = blocks_.find(blockId);
  if (found == blocks_.end() || !found->second.poisoned ||
      found->second.children || found->second.activeUsers ||
      found->second.transferring)
    return;
  try {
    erase(blockId);
  } catch (...) {
    std::terminate();
  }
}

} // namespace splash::engine
