from pathlib import Path
import datetime,hashlib,json,shutil,statistics as st,subprocess,tarfile
from dev.benchmarks import qwen4b_matrix_adapter as adapter
root=Path.cwd();out=root/'build/tiel-miniplus-q4h-output16k-paired-v4';data=root/'docs/data/tiel-miniplus-q4h-output16k-paired-2026-10-11'
def load(name):return json.loads((out/name).read_text())
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
summary=load('summary.json');plan=load('plan.json');identity=load('prepared-identity.json');records=summary['records'];exit_result=load('controller-exit.json')
assert summary['status']=='complete' and summary['completed']==summary['planned']==12 and exit_result['exit_code']==0
assert all(r['native_exit_code']==0 and r['facts_pass'] and r['token_match_same_profile'] and (not r['frozen_match_required'] or r['token_match_frozen_q4h']) for r in records)
assert adapter.code_sha256(root)==plan['runtime_code_sha256']
verification={'status':'passed','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_exit_code':exit_result['exit_code'],'artifacts':{},'weights':{},'owned_test_processes_remaining':[]}
for path,wanted in identity['artifacts'].items():
 actual=adapter.sha_file(Path(path));assert actual==wanted,path;verification['artifacts'][path]=actual
for role,item in plan['weights'].items():
 actual=adapter.sha_file(Path(item['path']));assert actual==item['sha256'],role;verification['weights'][role]={**item,'actual_sha256':actual}
for line in subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()[1:]:
 fields=line.strip().split(None,1)
 if len(fields)==2 and (str(out/'runner.py') in fields[1] or str(out/'qwen4b-matrix-native') in fields[1]):verification['owned_test_processes_remaining'].append(int(fields[0]))
assert not verification['owned_test_processes_remaining']
candidate=plan['profiles'][1]['name'];pairs=[]
for pair in range(6):
 a=next(r for r in records if r['pair']==pair and r['profile']=='baseline');b=next(r for r in records if r['pair']==pair and r['profile']==candidate)
 pairs.append({'pair':pair,'order':'AB' if a['schedule_index']<b['schedule_index'] else 'BA','prefill_gain_percent':100*(b['prefill_tok_s']/a['prefill_tok_s']-1),'decode_gain_percent':100*(b['decode_tok_s']/a['decode_tok_s']-1),'total_reduction_percent':100*(1-b['total_seconds']/a['total_seconds'])})
median={k:st.median(p[k] for p in pairs) for k in ['prefill_gain_percent','decode_gain_percent','total_reduction_percent']}
wins=sum(p['total_reduction_percent']>0 for p in pairs);confirmed=median['total_reduction_percent']>=2 and wins>=5
metrics=['prefill_tok_s','decode_tok_s','ttft_seconds','total_seconds','batch_decode_tok_s']
rows=[]
for p in plan['profiles']:
 rr=[r for r in records if r['profile']==p['name']];assert len(rr)==6
 rows.append({'profile':p['name'],'parameters':rr[0]['parameters'],'features':rr[0]['features'],'samples':6,'median':{k:st.median(r[k] for r in rr) for k in metrics},'range':{k:[min(r[k] for r in rr),max(r[k] for r in rr)] for k in metrics},'device_peak_gib':st.median(r['memory_report']['device_peak_bytes']/2**30 for r in rr),'acceptance':st.median(r['draft_acceptance'] for r in rr)})
report={'status':'complete','candidate':candidate,'rows':rows,'pairs':pairs,'paired_median':median,'total_faster_pairs':wins,'candidate_confirmed_by_screen':confirmed,'baseline_automatically_changed':False,'confirmation_rule':'total reduction median>=2% and at least5/6 faster pairs; diagnostic background load retained; this rule selects a recommendation, not a causal hardware speedup','observed_busy_samples':sum(bool(r['observed_busy_pids']) for r in records)}
save(out/'comparison-report.json',report);save(out/'final-verification.json',verification)
lines=['# Tiel MiniPlus：Q4H、16K 输出候选配对复核','','固定 32,768 输入、16,384 实际输出、131,072 容量，Q4H KV、DFlash2 block=8 和并发 1。原生入口、引擎、权重、输入及采样沿用逐项扫描。','','候选为 `'+candidate+'`；A 为原基准，B 为候选，ABBA 重复 3 次，共 12 批、6 个相邻配对。所有慢样本保留。','','| 配置 | Prefill tokens/s | Decode tokens/s | 首 token s | 总耗时 s | Device 峰值 GiB | 草稿接受率 |','| --- | --- | --- | --- | --- | --- | --- |']
for r in rows:
 m=r['median'];lines.append(f"| {r['profile']} | {m['prefill_tok_s']:.1f} | {m['decode_tok_s']:.1f} | {m['ttft_seconds']:.2f} | {m['total_seconds']:.2f} | {r['device_peak_gib']:.3f} | {r['acceptance']:.2%} |")
lines+=['','| 配对 | 顺序 | Prefill 收益 | Decode 收益 | 总耗时降低 |','| --- | --- | --- | --- | --- |']
for p in pairs:lines.append(f"| {p['pair']+1} | {p['order']} | {p['prefill_gain_percent']:+.2f}% | {p['decode_gain_percent']:+.2f}% | {p['total_reduction_percent']:+.2f}% |")
lines+=['',f"相邻配对收益中位数：prefill {median['prefill_gain_percent']:+.2f}%，decode {median['decode_gain_percent']:+.2f}%，总耗时降低 {median['total_reduction_percent']:+.2f}%。候选总耗时更快 {wins}／6 对。",'',('候选通过本轮性能筛选，可供下一轮基准选择。' if confirmed else '候选没有通过本轮性能筛选，继续保留原标准参数。')+'筛选要求为总耗时降低中位数至少 2%、至少 5／6 对更快。没有自动修改根目录标准参数或生产服务，Q4H 始终保持用户选定格式。','','全部 12 批原生退出码为 0，完整输出与扫描时同配置轨迹一致，事实、长度、冷缓存、内存及功能开关通过。结束时源码、库、metallib 与原始权重哈希一致。后台服务忙的样本为 '+str(report['observed_busy_samples'])+'／12，运行中有外部负载的尝试均保留并排除，等待空闲后重试；没有删除或重跑无干扰的慢样本。','','[统计](data/tiel-miniplus-q4h-output16k-paired-2026-10-11/comparison-report.json)、[原始样本](data/tiel-miniplus-q4h-output16k-paired-2026-10-11/summary.json)、[结束校验](data/tiel-miniplus-q4h-output16k-paired-2026-10-11/final-verification.json)、[归档](data/tiel-miniplus-q4h-output16k-paired-2026-10-11/raw-results.tar.gz)与[归档清单](data/tiel-miniplus-q4h-output16k-paired-2026-10-11/archive-manifest.json)。']
(root/'docs/tiel-miniplus-q4h-output16k-paired-2026-10-11.md').write_text('\n'.join(lines)+'\n')
data.mkdir(parents=True,exist_ok=True)
for name in ['plan.json','summary.json','comparison-report.json','final-verification.json','controller.log']:shutil.copy2(out/name,data/name)
shutil.copy2(Path(__file__),out/'report.py')
files=sorted(f for f in out.rglob('*') if f.is_file() and f.name!='report.log');manifest=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':adapter.sha_file(f)} for f in files];archive=data/'raw-results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for member,wanted in zip(tar.getmembers(),manifest,strict=True):
  assert member.name==wanted['path'];stream=tar.extractfile(member);h=hashlib.sha256()
  while chunk:=stream.read(1024*1024):h.update(chunk)
  assert h.hexdigest()==wanted['sha256']
save(data/'archive-manifest.json',{'archive':archive.name,'sha256':adapter.sha_file(archive),'bytes':archive.stat().st_size,'files':manifest,'roundtrip_verified':True})
sweep_doc=root/'docs/tiel-miniplus-q4h-output16k-2026-10-11.md'
with sweep_doc.open('a') as stream:stream.write('\n## 候选配对复核\n\n候选 `'+candidate+'` 完成 12 批相邻配对。总耗时降低中位数 '+f"{median['total_reduction_percent']:+.2f}%"+'，'+str(wins)+'／6 对更快。完整结果见[配对报告](tiel-miniplus-q4h-output16k-paired-2026-10-11.md)。\n')
print(json.dumps(report,ensure_ascii=False))
