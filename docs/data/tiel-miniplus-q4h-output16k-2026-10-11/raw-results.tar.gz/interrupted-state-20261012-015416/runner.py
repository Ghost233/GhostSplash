"""Frozen-runtime Tiel MiniPlus gates and one-variable-at-a-time measurements."""
import copy
import fcntl
import hashlib
import json
import os
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

from transformers import AutoTokenizer
from install import assembly
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.tools.compact_draft_ranking import write_ranking

ROOT=Path.cwd()
DATA=ROOT/'build/tiel-miniplus-matrix-v1'
OUT=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v4'
PREVIOUS=ROOT/'build/tiel-miniplus-output16k-v2'
PLAN=json.loads((DATA/'plan.json').read_text())
BUILD=ROOT/'build/ghost-merge-validation/block-8'
NATIVE=OUT/'qwen4b-matrix-native'
MODEL=Path(PLAN['model_root'])
PROMPTS=json.loads((DATA/'inputs.json').read_text())['prompts']
CODEC=AutoTokenizer.from_pretrained(PLAN['tokenizer'],local_files_only=True,trust_remote_code=False)
GATE=json.loads((ROOT/'build/ghost-merge-validation/final-verification.json').read_text())
assert GATE['status']=='passed' and GATE['code_sha256']==adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256']
for artifact in GATE['artifacts'].values():
    assert adapter.sha_file(Path(artifact['path']))==artifact['sha256']
STAMP=json.loads((BUILD/'engine/build-identity.json').read_text())
IDENTITY={'code_sha256':matrix.digest({'runtime_code_sha256':PLAN['runtime_code_sha256'],'native_harness_sha256':adapter.sha_file(OUT/'TielMatrix.mm'),'attention_harness_sha256':PLAN['attention_harness_sha256']}),'weight_sha256':{k:v['sha256'] for k,v in PLAN['weights'].items()}}
ARTIFACTS={str(p):adapter.sha_file(p) for p in (NATIVE,BUILD/'splash.metallib',BUILD/'engine/libsplash.a',OUT/'TielMatrix.mm',DATA/'TielPagedAttention.cpp',DATA/'TielPagedAttention.o',DATA/'runner.py',DATA/'plan.json')}
(OUT/'prepared-identity.json').write_text(json.dumps({'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']},indent=2)+'\n')
# Hold the verified installed assembly while this controller uses it.
record_lock=(MODEL/'model.json').open('rb')
fcntl.flock(record_lock,fcntl.LOCK_SH)
assembly.verify(MODEL)
FLAGS={'lookup':'SPLASH_PROMPT_LOOKUP','compact':'SPLASH_COMPACT_DRAFT_HEAD','fast':'SPLASH_FAST_TOPK'}
RANK=DATA/'input-frequency-ranking.splash'
class ExternalLoad(RuntimeError): pass
ORIGINAL_ENV=isolation.environment
ORIGINAL_IDLE=isolation.require_idle


def save(path,value):
    isolation.write(path,value)


def run(name,parameters,features,performance,prompts=None):
    assert adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256'],'runtime source changed'
    for path,digest in ARTIFACTS.items():
        assert adapter.sha_file(Path(path))==digest,'artifact changed: '+path
    assembly.verify(MODEL)
    attempt=OUT/name
    attempt.mkdir()
    selected=copy.deepcopy(PROMPTS[:parameters['concurrency']] if prompts is None else prompts)
    job={'group_id':matrix.digest(parameters | {'features':features}),'repeat':int(name.split('-')[1]) if name.startswith('perf-') else 0,'parameters':parameters}
    payload={'protocol':'tiel-miniplus-matrix-v1','operation':'run_batch','mode':'performance' if performance else 'correctness','optional_features_correctness':not performance,'model_root':str(MODEL),'metallib':str(BUILD/'splash.metallib'),'identity':IDENTITY,'job':job,'prompts':selected}
    for key,env in FLAGS.items(): os.environ[env]=str(int(features[key]))
    os.environ['SPLASH_COMPACT_DRAFT_RANKING']=str(RANK)
    os.environ['MTL_SHADER_VALIDATION']='0'
    os.environ['MTL_DEBUG_LAYER']='0'
    background=[]
    def environment(*args,**kwargs):
        actual=ORIGINAL_ENV(*args,**kwargs)
        background.append(copy.deepcopy(actual))
        if args and args[0] and actual['busy_pids']:
            raise RuntimeError('background-interference: '+str(actual['busy_pids']))
        return actual
    isolation.environment=environment
    isolation.require_idle=ORIGINAL_IDLE
    save(attempt/'payload.json',payload)
    save(OUT/'progress.json',{'status':'running','phase':'performance' if performance else 'correctness','active':name,'completed':len(records),'planned':planned,'controller_pid':os.getpid(),'time':time.time()})
    started=time.time()
    print('START',name,flush=True)
    try:
        evidence=isolation.checked_process([str(NATIVE)],json.dumps(payload),attempt/'stdout.json',attempt/'stderr.log',correctness=not performance)
    finally:
        isolation.environment=ORIGINAL_ENV
        isolation.require_idle=ORIGINAL_IDLE
    evidence.update(background_samples=background,authorized_all_background_load=False,isolated_performance_usable=evidence['status']=='complete',performance_usable=evidence['status']=='complete')
    save(attempt/'evidence.json',evidence)
    if evidence['status']!='complete' or evidence['exit_code']!=0:
        save(OUT/'progress.json',{'status':'failed','phase':'performance' if performance else 'correctness','active':name,'native_status':evidence['status'],'native_exit_code':evidence['exit_code']})
        error=evidence.get('error') or ''
        if error.startswith(('background-interference:','external inference active:','GPU not idle enough','experiment device lock is held')):
            raise ExternalLoad(name+': '+error)
        raise RuntimeError('native failed: '+name)
    raw=json.loads((attempt/'stdout.json').read_text())
    assert raw['compiled_source_sha256']==STAMP['source_sha256']
    raw['commands']=[evidence['command']]
    for response in raw['requests']:
        response['output_text']=CODEC.decode(response['output_token_ids'],skip_special_tokens=False)
    checked=matrix.validate_batch(raw,job,selected,IDENTITY,adapter.eos_ids(MODEL),performance=performance)
    save(attempt/'validated.json',checked)
    memory=raw['memory_report']
    assert sum(memory[k] for k in isolation.CATEGORIES)==memory['backend_current_bytes']
    assert memory['ffn_fp16_cache_bytes']==0 and memory['ffn_cached_matrices']==0
    assert memory['backend_peak_bytes']<=parameters['memory_budget_bytes']
    result={'name':name,'attempt':str(attempt),'parameters':parameters,'features':features,'native_exit_code':0,'validation_status':checked['status'],'facts_pass':checked['facts_pass'],'ane_actual':raw['ane_actual'],'optional_features':raw['optional_features'],'memory_report':memory,'memory_peak_gib':raw['memory_peak_bytes']/2**30,'actual_batch_widths':checked['decode_batch_width_summary'],'drafted_tokens':raw['drafted_tokens'],'accepted_draft_tokens':raw['accepted_draft_tokens'],'requests':checked['requests'],'started_at_unix':started,'completed_at_unix':time.time(),'pre_start_gpu_percent':[s['gpu_utilization_percent'] for s in background[:2]],'observed_busy_pids':sorted({p for s in background for p in s['busy_pids']}),'source_sha256':IDENTITY['code_sha256'],'target_manifest_sha256':raw['target_manifest_sha256']}
    if performance:
        result.update(prefill_tok_s=statistics.median(r['prefill_tok_s'] for r in checked['requests']),decode_tok_s=statistics.median(r['decode_tok_s'] for r in checked['requests']),ttft_seconds=statistics.median(r['timings']['ttft_seconds'] for r in checked['requests']),total_seconds=statistics.median(r['timings']['total_wall_seconds'] for r in checked['requests']),batch_seconds=raw['timings']['total_wall_seconds'],batch_prefill_tok_s=parameters['concurrency']*32768/raw['timings']['prefill_wall_seconds'],batch_decode_tok_s=parameters['concurrency']*parameters['output_tokens']/raw['timings']['decode_wall_seconds'])
    save(attempt/'result.json',result)
    print('END',name,'status='+checked['status'],'facts='+str(checked['facts_pass']),('prefill=%.1f decode=%.1f peak=%.3fGiB'%(result['prefill_tok_s'],result['decode_tok_s'],result['memory_peak_gib'])) if performance else 'correctness only',flush=True)
    time.sleep(2)
    return raw,result


sys.path.insert(0,str(OUT))
from tiel_graph_validation import load_certificate,validate_outputs
certificate=load_certificate(OUT/'numeric-certificate.json',PLAN['runtime_code_sha256'],IDENTITY['weight_sha256'])
ARTIFACTS.update(certificate['artifacts'])
for file in ['runner.py','tiel_graph_validation.py','numeric-certificate.json','resume-records.json','peer-benchmark-finished.json']:
    ARTIFACTS[str(OUT/file)]=adapter.sha_file(OUT/file)
ARTIFACTS[str(RANK)]=adapter.sha_file(RANK)
for role,item in PLAN['weights'].items():assert adapter.sha_file(Path(item['path']))==item['sha256']
OLD=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v3'
old_plan=json.loads((OLD/'plan.json').read_text());base=old_plan['base_parameters'];profiles=old_plan['profiles'];schedule=old_plan['schedule']
prior=json.loads((ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v1/summary.json').read_text())
references={}
for profile in profiles:
    earlier=next(r for r in prior['records'] if r['profile']==profile['name'])
    raw=json.loads((Path(earlier['attempt'])/'stdout.json').read_text());references[profile['name']]=[r['output_token_ids'] for r in raw['requests']]
previous=json.loads((PREVIOUS/'summary.json').read_text());earlier=next(r for r in previous['records'] if r['parameters']['kv_format']=='q4h');golden=json.loads((Path(earlier['attempt'])/'stdout.json').read_text())['requests'][0]['output_token_ids']
records=json.loads((OUT/'resume-records.json').read_text())['records'];planned=63
retained_keys={(r['profile'],r['repeat']) for r in records}
plan=old_plan|{'previous_measurement':str(OLD),'retained_samples':17,'fresh_measurements_planned':46,'numeric_certificate':str(OUT/'numeric-certificate.json'),'validation_policy':'C1 full-token exact; C2/C4 dynamic transcript differences recorded and bound to unchanged matching-command-row numeric oracle; no tolerance changes','background_policy':'peer benchmark finished;30s idle before every attempt; stop/retry on detected external activity'}
save(OUT/'plan.json',plan);save(OUT/'prepared-identity.json',{'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']})
save(OUT/'summary.json',{'status':'running','phase':'resumed_after_validator_fix','completed':len(records),'planned':planned,'records':records})
with (OUT/'results.jsonl').open('w') as stream:
    for r in records:stream.write(json.dumps(r,ensure_ascii=False)+'\n')

def await_idle(logical_index):
    peer_completion=json.loads((ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v4/peer-benchmark-finished.json').read_text())
    assert peer_completion['status']=='finished','peer benchmark completion is required before measuring'
    streak=0;last=None
    while streak<3:
        snapshot=ORIGINAL_ENV()
        gpu=snapshot['gpu_utilization_percent']
        idle=not snapshot['busy_pids'] and gpu is not None and gpu<=50
        save(OUT/'progress.json',{'status':'checking_idle' if idle else 'waiting_for_idle','completed':len(records),'planned':planned,'pending_schedule_index':logical_index,'environment':snapshot,'controller_pid':os.getpid(),'time':time.time()})
        with (OUT/'idle-gate.jsonl').open('a') as stream:stream.write(json.dumps({'time':time.time(),'idle':idle,'environment':snapshot})+'\n')
        key=(idle,tuple(snapshot['busy_pids']))
        if key!=last:print('IDLE GATE', 'ready' if idle else 'waiting', 'gpu='+str(gpu),'busy='+str(snapshot['busy_pids']),flush=True);last=key
        streak=streak+1 if idle else 0
        if streak<3:time.sleep(15)

def execute(profile,repeat,index,phase):
    parameters=base | profile['change']
    name=f"perf-{repeat}-{index:03d}-{phase}-{profile['name']}"
    raw,result=run(name,parameters,profile['features'],True)
    assert result['validation_status']=='complete' and result['facts_pass'],('quality gate',name)
    configured=raw['optional_features']['configured']
    assert configured=={'prompt_lookup':profile['features']['lookup'],'compact_draft_head':profile['features']['compact'],'fast_topk':False},configured
    assert not raw['ane_actual']['enabled']
    actual=[r['output_token_ids'] for r in raw['requests']]
    if profile['name'] not in references:
        references[profile['name']]=actual
    differences=[isolation.first_divergence(a,b) for a,b in zip(references[profile['name']],actual,strict=True)]
    frozen_difference=isolation.first_divergence(golden,actual[0])
    must_match_frozen=parameters['tail_prefill_splits']==8 and parameters['concurrency']==1
    result.update(profile=profile['name'],repeat=repeat,schedule_index=index,phase=phase,token_match_same_profile=all(d is None for d in differences),first_differences_same_profile=differences,token_match_frozen_q4h=frozen_difference is None,first_difference_frozen_q4h=frozen_difference,frozen_match_required=must_match_frozen,draft_acceptance=result['accepted_draft_tokens']/result['drafted_tokens'] if result['drafted_tokens'] else 0,startup_timings=raw['startup_timings'],reference_source='prior Q4H full16384 golden for S8/C1; first same-profile batch for split/concurrency repeatability')
    result.update(validate_outputs(parameters,profile['features'],actual,references[profile['name']],certificate))
    save(Path(result['attempt'])/'result.json',result)
    assert not result['full_token_comparison_required'] or all(d is None for d in differences),('same-profile token divergence',name,differences)
    assert not must_match_frozen or frozen_difference is None,('lossless feature token divergence',name,frozen_difference)
    result.update(retained_from_previous=False,measurement_background_policy='require_idle_and_abort_on_external_workload')
    records.append(result)
    with (OUT/'results.jsonl').open('a') as stream: stream.write(json.dumps(result,ensure_ascii=False)+'\n')
    save(OUT/'summary.json',{'status':'running','phase':phase,'completed':len(records),'planned':planned,'records':records})
    save(OUT/'progress.json',{'status':'running','phase':phase,'completed':len(records),'planned':planned,'last_completed':name,'controller_pid':os.getpid()})
    return result


print('RESUME AFTER GRAPH COMPARISON FIX:17 validated samples retained;46 remaining; production binary unchanged',flush=True)
try:
    for index,item in enumerate(schedule,1):
        profile=item['profile'];repeat=item['repeat']
        if (profile['name'],repeat) in retained_keys:continue
        attempt=0
        while True:
            await_idle(index);attempt+=1
            try:
                result=execute(profile,repeat,index,'graph-validated'+(f'-attempt{attempt}' if attempt>1 else ''))
            except ExternalLoad as error:
                with (OUT/'interference-events.jsonl').open('a') as stream:stream.write(json.dumps({'schedule_index':index,'profile':profile['name'],'repeat':repeat,'attempt':attempt,'reason':str(error),'time':time.time()})+'\n')
                continue
            break
    save(OUT/'summary.json',{'status':'complete','completed':len(records),'planned':planned,'records':records})
    save(OUT/'progress.json',{'status':'sweep_complete','completed':len(records),'planned':planned})
    print('GRAPH-VALIDATED SWEEP COMPLETE63',flush=True)
except BaseException as error:
    save(OUT/'failure.json',{'type':type(error).__name__,'error':str(error),'completed':len(records),'planned':planned,'time':time.time()});raise
finally:record_lock.close()
