import ast
from pathlib import Path
import hashlib
import json
import shutil

root=Path.cwd();sweep=root/'build/tiel-miniplus-q4h-output16k-sweep-v4'
selection=json.loads((sweep/'selection.json').read_text());assert selection['candidate']
out=root/'build/tiel-miniplus-q4h-output16k-paired-v4';out.mkdir()
for name in ('TielMatrix.mm','qwen4b-matrix-native'):shutil.copy2(sweep/name,out/name)
source=(sweep/'runner.py').read_text()
header=source.split("\nARTIFACTS[str(OUT/'runner.py')]")[0].replace("OUT=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v4'","OUT=ROOT/'build/tiel-miniplus-q4h-output16k-paired-v4'")
tree=ast.parse(source)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='execute')
execute=''.join(source.splitlines(keepends=True)[node.lineno-1:node.end_lineno]).split('def execute(',1)[1]
execute=execute.replace('result.update(profile=','result.update(pair=repeat,profile=')
idle=source.split('\ndef await_idle(',1)[1].split('\ndef execute(',1)[0]
body_idle='\ndef await_idle('+idle
body=r'''
VALIDATION=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v4'
sys.path.insert(0,str(VALIDATION))
from tiel_graph_validation import load_certificate,validate_outputs
certificate=load_certificate(VALIDATION/'numeric-certificate.json',PLAN['runtime_code_sha256'],IDENTITY['weight_sha256'])
ARTIFACTS.update(certificate['artifacts'])
ARTIFACTS[str(VALIDATION/'numeric-certificate.json')]=adapter.sha_file(VALIDATION/'numeric-certificate.json')
ARTIFACTS[str(VALIDATION/'tiel_graph_validation.py')]=adapter.sha_file(VALIDATION/'tiel_graph_validation.py')
ARTIFACTS[str(OUT/'runner.py')]=adapter.sha_file(OUT/'runner.py')
ARTIFACTS[str(RANK)]=adapter.sha_file(RANK)
PEER=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v4/peer-benchmark-finished.json'
ARTIFACTS[str(PEER)]=adapter.sha_file(PEER)
for role,item in PLAN['weights'].items():
    assert adapter.sha_file(Path(item['path']))==item['sha256'],role+' original weight changed'
SWEEP=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v4'
selection=json.loads((SWEEP/'selection.json').read_text())
base=selection['baseline'];assert base['kv_format']=='q4h' and base['output_tokens']==16384
candidate=selection['candidate'];assert candidate
baseline={'name':'baseline','change':{},'features':selection['baseline_features']}
profiles=[baseline,candidate]
previous=json.loads((PREVIOUS/'summary.json').read_text())
earlier=next(r for r in previous['records'] if r['parameters']['kv_format']=='q4h')
golden=json.loads((Path(earlier['attempt'])/'stdout.json').read_text())['requests'][0]['output_token_ids']
old=json.loads((SWEEP/'summary.json').read_text());assert old['status']=='complete'
references={}
for profile in profiles:
    accepted=next(r for r in old['records'] if r['profile']==profile['name'])
    assert accepted['parameters']==base | profile['change'] and accepted['features']==profile['features']
    raw=json.loads((Path(accepted['attempt'])/'stdout.json').read_text())
    references[profile['name']]=[r['output_token_ids'] for r in raw['requests']]
'''
body+=body_idle+'\ndef execute('+execute
body+=r'''
records=[];planned=12
orders=[baseline,candidate,candidate,baseline]*3
schedule=[{'pair':index//2,'profile':profile} for index,profile in enumerate(orders)]
save(OUT/'plan.json',{'base_parameters':base,'profiles':profiles,'schedule':schedule,'planned':planned,'pairs':6,'source_sweep':str(SWEEP),'runtime_code_sha256':PLAN['runtime_code_sha256'],'weights':PLAN['weights'],'identity':IDENTITY,'ordering':'ABBA repeated3; six adjacent pairs alternate AB/BA; same Q4H/native/weights/input/output/control settings'})
save(OUT/'prepared-identity.json',{'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']})
print('PAIRED Q4H16K START12 baseline versus',candidate['name'],flush=True)
try:
    for index,item in enumerate(schedule,1):
        attempt=0
        while True:
            await_idle(index);attempt+=1
            try:
                phase='paired'+(f'-attempt{attempt}' if attempt>1 else '')
                result=execute(item['profile'],item['pair'],index,phase)
                break
            except ExternalLoad as error:
                with (OUT/'interference-events.jsonl').open('a') as stream:stream.write(json.dumps({'index':index,'pair':item['pair'],'profile':item['profile']['name'],'attempt':attempt,'reason':str(error),'time':time.time()})+'\n')
                print('INTERFERED PAIR ATTEMPT PRESERVED; WAITING',flush=True)
        result['pair']=item['pair'];save(Path(result['attempt'])/'result.json',result)
    save(OUT/'summary.json',{'status':'complete','completed':12,'planned':12,'records':records})
    save(OUT/'progress.json',{'status':'paired_complete','completed':12,'planned':12})
    print('PAIRED Q4H16K COMPLETE12',flush=True)
except BaseException as error:
    save(OUT/'failure.json',{'type':type(error).__name__,'error':str(error),'completed':len(records),'time':time.time()})
    raise
finally:
    record_lock.close()
'''
script=header+body;compile(script,str(out/'runner.py'),'exec');(out/'runner.py').write_text(script)
assert (out/'qwen4b-matrix-native').read_bytes()==(sweep/'qwen4b-matrix-native').read_bytes()
print(json.dumps({'prepared':str(out),'candidate':selection['candidate']['name'],'planned':12,'native_sha256':hashlib.sha256((out/'qwen4b-matrix-native').read_bytes()).hexdigest()}))
