"""Frozen-runtime Tiel MiniPlus gates and one-variable-at-a-time measurements."""
import copy
import fcntl
import hashlib
import json
import os
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

from transformers import AutoTokenizer
from install import assembly
from dev.benchmarks import qwen4b_matrix as matrix
from dev.benchmarks import qwen4b_matrix_adapter as adapter
from dev.benchmarks import qwen4b_ffn_cache as isolation
from dev.tools.compact_draft_ranking import write_ranking

ROOT=Path.cwd()
DATA=ROOT/'build/tiel-miniplus-matrix-v1'
OUT=ROOT/'build/tiel-miniplus-q4h-output16k-sweep-v1'
PREVIOUS=ROOT/'build/tiel-miniplus-output16k-v2'
PLAN=json.loads((DATA/'plan.json').read_text())
BUILD=ROOT/'build/ghost-merge-validation/block-8'
NATIVE=OUT/'qwen4b-matrix-native'
MODEL=Path(PLAN['model_root'])
PROMPTS=json.loads((DATA/'inputs.json').read_text())['prompts']
CODEC=AutoTokenizer.from_pretrained(PLAN['tokenizer'],local_files_only=True,trust_remote_code=False)
GATE=json.loads((ROOT/'build/ghost-merge-validation/final-verification.json').read_text())
assert GATE['status']=='passed' and GATE['code_sha256']==adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256']
for artifact in GATE['artifacts'].values():
    assert adapter.sha_file(Path(artifact['path']))==artifact['sha256']
STAMP=json.loads((BUILD/'engine/build-identity.json').read_text())
IDENTITY={'code_sha256':matrix.digest({'runtime_code_sha256':PLAN['runtime_code_sha256'],'native_harness_sha256':adapter.sha_file(OUT/'TielMatrix.mm'),'attention_harness_sha256':PLAN['attention_harness_sha256']}),'weight_sha256':{k:v['sha256'] for k,v in PLAN['weights'].items()}}
ARTIFACTS={str(p):adapter.sha_file(p) for p in (NATIVE,BUILD/'splash.metallib',BUILD/'engine/libsplash.a',OUT/'TielMatrix.mm',DATA/'TielPagedAttention.cpp',DATA/'TielPagedAttention.o',DATA/'runner.py',DATA/'plan.json')}
(OUT/'prepared-identity.json').write_text(json.dumps({'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']},indent=2)+'\n')
# Hold the verified installed assembly while this controller uses it.
record_lock=(MODEL/'model.json').open('rb')
fcntl.flock(record_lock,fcntl.LOCK_SH)
assembly.verify(MODEL)
FLAGS={'lookup':'SPLASH_PROMPT_LOOKUP','compact':'SPLASH_COMPACT_DRAFT_HEAD','fast':'SPLASH_FAST_TOPK'}
RANK=DATA/'input-frequency-ranking.splash'
ORIGINAL_ENV=isolation.environment
ORIGINAL_IDLE=isolation.require_idle


def save(path,value):
    isolation.write(path,value)


def run(name,parameters,features,performance,prompts=None):
    assert adapter.code_sha256(ROOT)==PLAN['runtime_code_sha256'],'runtime source changed'
    for path,digest in ARTIFACTS.items():
        assert adapter.sha_file(Path(path))==digest,'artifact changed: '+path
    assembly.verify(MODEL)
    attempt=OUT/name
    attempt.mkdir()
    selected=copy.deepcopy(PROMPTS[:parameters['concurrency']] if prompts is None else prompts)
    job={'group_id':matrix.digest(parameters | {'features':features}),'repeat':int(name.split('-')[1]) if name.startswith('perf-') else 0,'parameters':parameters}
    payload={'protocol':'tiel-miniplus-matrix-v1','operation':'run_batch','mode':'performance' if performance else 'correctness','optional_features_correctness':not performance,'model_root':str(MODEL),'metallib':str(BUILD/'splash.metallib'),'identity':IDENTITY,'job':job,'prompts':selected}
    for key,env in FLAGS.items(): os.environ[env]=str(int(features[key]))
    os.environ['SPLASH_COMPACT_DRAFT_RANKING']=str(RANK)
    os.environ['MTL_SHADER_VALIDATION']='0'
    os.environ['MTL_DEBUG_LAYER']='0'
    background=[]
    def environment(*args,**kwargs):
        actual=ORIGINAL_ENV(*args,**kwargs)
        background.append(copy.deepcopy(actual))
        accepted=copy.deepcopy(actual)
        accepted['authorized_diagnostic_busy_pids']=accepted['busy_pids']
        accepted['busy_pids']=[]
        return accepted
    def idle(**kwargs):
        kwargs['ignore_gpu_utilization']=True
        return ORIGINAL_IDLE(**kwargs)
    isolation.environment=environment
    isolation.require_idle=idle
    save(attempt/'payload.json',payload)
    save(OUT/'progress.json',{'status':'running','phase':'performance' if performance else 'correctness','active':name,'completed':len(records),'planned':planned,'controller_pid':os.getpid(),'time':time.time()})
    started=time.time()
    print('START',name,flush=True)
    try:
        evidence=isolation.checked_process([str(NATIVE)],json.dumps(payload),attempt/'stdout.json',attempt/'stderr.log',correctness=not performance)
    finally:
        isolation.environment=ORIGINAL_ENV
        isolation.require_idle=ORIGINAL_IDLE
    evidence.update(background_samples=background,authorized_all_background_load=True,isolated_performance_usable=False,performance_usable=False)
    save(attempt/'evidence.json',evidence)
    if evidence['status']!='complete' or evidence['exit_code']!=0:
        save(OUT/'progress.json',{'status':'failed','phase':'performance' if performance else 'correctness','active':name,'native_status':evidence['status'],'native_exit_code':evidence['exit_code']})
        raise RuntimeError('native failed: '+name)
    raw=json.loads((attempt/'stdout.json').read_text())
    assert raw['compiled_source_sha256']==STAMP['source_sha256']
    raw['commands']=[evidence['command']]
    for response in raw['requests']:
        response['output_text']=CODEC.decode(response['output_token_ids'],skip_special_tokens=False)
    checked=matrix.validate_batch(raw,job,selected,IDENTITY,adapter.eos_ids(MODEL),performance=performance)
    save(attempt/'validated.json',checked)
    memory=raw['memory_report']
    assert sum(memory[k] for k in isolation.CATEGORIES)==memory['backend_current_bytes']
    assert memory['ffn_fp16_cache_bytes']==0 and memory['ffn_cached_matrices']==0
    assert memory['backend_peak_bytes']<=parameters['memory_budget_bytes']
    result={'name':name,'attempt':str(attempt),'parameters':parameters,'features':features,'native_exit_code':0,'validation_status':checked['status'],'facts_pass':checked['facts_pass'],'ane_actual':raw['ane_actual'],'optional_features':raw['optional_features'],'memory_report':memory,'memory_peak_gib':raw['memory_peak_bytes']/2**30,'actual_batch_widths':checked['decode_batch_width_summary'],'drafted_tokens':raw['drafted_tokens'],'accepted_draft_tokens':raw['accepted_draft_tokens'],'requests':checked['requests'],'started_at_unix':started,'completed_at_unix':time.time(),'pre_start_gpu_percent':[s['gpu_utilization_percent'] for s in background[:2]],'observed_busy_pids':sorted({p for s in background for p in s['busy_pids']}),'source_sha256':IDENTITY['code_sha256'],'target_manifest_sha256':raw['target_manifest_sha256']}
    if performance:
        result.update(prefill_tok_s=statistics.median(r['prefill_tok_s'] for r in checked['requests']),decode_tok_s=statistics.median(r['decode_tok_s'] for r in checked['requests']),ttft_seconds=statistics.median(r['timings']['ttft_seconds'] for r in checked['requests']),total_seconds=statistics.median(r['timings']['total_wall_seconds'] for r in checked['requests']),batch_seconds=raw['timings']['total_wall_seconds'],batch_prefill_tok_s=parameters['concurrency']*32768/raw['timings']['prefill_wall_seconds'],batch_decode_tok_s=parameters['concurrency']*parameters['output_tokens']/raw['timings']['decode_wall_seconds'])
    save(attempt/'result.json',result)
    print('END',name,'status='+checked['status'],'facts='+str(checked['facts_pass']),('prefill=%.1f decode=%.1f peak=%.3fGiB'%(result['prefill_tok_s'],result['decode_tok_s'],result['memory_peak_gib'])) if performance else 'correctness only',flush=True)
    time.sleep(2)
    return raw,result


ARTIFACTS[str(OUT/'runner.py')]=adapter.sha_file(OUT/'runner.py')
ARTIFACTS[str(RANK)]=adapter.sha_file(RANK)
for role,item in PLAN['weights'].items():
    assert adapter.sha_file(Path(item['path']))==item['sha256'],role+' original weight changed'
features={'lookup':False,'compact':False,'fast':False}
base=PLAN['base_parameters'] | {'kv_format':'q4h','output_tokens':16384,'context_tokens':131072}
profiles=[p for p in PLAN['profiles'] if p['name']=='baseline' or p['name'].startswith('splits-') or p['name'] in ('concurrency-2','concurrency-4','lookup','compact','lookup-compact')]
assert len(profiles)==21
previous=json.loads((PREVIOUS/'summary.json').read_text())
assert previous['status']=='complete' and previous['completed']==9
earlier=next(r for r in previous['records'] if r['parameters']['kv_format']=='q4h')
assert earlier['parameters']==base and not any(earlier['features'].values())
golden=json.loads((Path(earlier['attempt'])/'stdout.json').read_text())['requests'][0]['output_token_ids']
assert len(golden)==16384
references={}

def execute(profile,repeat,index,phase):
    parameters=base | profile['change']
    name=f"perf-{repeat}-{index:03d}-{phase}-{profile['name']}"
    raw,result=run(name,parameters,profile['features'],True)
    assert result['validation_status']=='complete' and result['facts_pass'],('quality gate',name)
    configured=raw['optional_features']['configured']
    assert configured=={'prompt_lookup':profile['features']['lookup'],'compact_draft_head':profile['features']['compact'],'fast_topk':False},configured
    assert not raw['ane_actual']['enabled']
    actual=[r['output_token_ids'] for r in raw['requests']]
    if profile['name'] not in references:
        references[profile['name']]=actual
    differences=[isolation.first_divergence(a,b) for a,b in zip(references[profile['name']],actual,strict=True)]
    frozen_difference=isolation.first_divergence(golden,actual[0])
    must_match_frozen=parameters['tail_prefill_splits']==8 and parameters['concurrency']==1
    result.update(profile=profile['name'],repeat=repeat,schedule_index=index,phase=phase,token_match_same_profile=all(d is None for d in differences),first_differences_same_profile=differences,token_match_frozen_q4h=frozen_difference is None,first_difference_frozen_q4h=frozen_difference,frozen_match_required=must_match_frozen,draft_acceptance=result['accepted_draft_tokens']/result['drafted_tokens'] if result['drafted_tokens'] else 0,startup_timings=raw['startup_timings'],reference_source='prior Q4H full16384 golden for S8/C1; first same-profile batch for split/concurrency repeatability')
    save(Path(result['attempt'])/'result.json',result)
    assert all(d is None for d in differences),('same-profile token divergence',name,differences)
    assert not must_match_frozen or frozen_difference is None,('lossless feature token divergence',name,frozen_difference)
    records.append(result)
    with (OUT/'results.jsonl').open('a') as stream: stream.write(json.dumps(result,ensure_ascii=False)+'\n')
    save(OUT/'summary.json',{'status':'running','phase':phase,'completed':len(records),'planned':planned,'records':records})
    save(OUT/'progress.json',{'status':'running','phase':phase,'completed':len(records),'planned':planned,'last_completed':name,'controller_pid':os.getpid()})
    return result

records=[]
planned=63
orders=[profiles,list(reversed(profiles)),profiles[10:]+profiles[:10]]
schedule=[{'repeat':repeat,'profile':p} for repeat,order in enumerate(orders) for p in order]
save(OUT/'plan.json',{'model_id':PLAN['model_id'],'model_root':PLAN['model_root'],'base_parameters':base,'profiles':profiles,'repeats':3,'planned':planned,'schedule':schedule,'weights':PLAN['weights'],'runtime_code_sha256':PLAN['runtime_code_sha256'],'identity':IDENTITY,'background_policy':PLAN['background_policy'],'source_results':str(DATA),'previous_measurement':str(PREVIOUS),'ordering':'forward, reverse, rotated by10; each profile appears once per round; no slow sample discarded','scope':'Q4H fixed32768 input/16384 output/131072 capacity. Splits1..16, concurrency1/2/4, lookup, compact, combination. Same-profile full-token repeatability and lossless features frozen-reference checks; cross-split/concurrency first divergence retained. No new operator changes. Promising C1 profiles receive final paired verification.'})
save(OUT/'prepared-identity.json',{'identity':IDENTITY,'artifacts':ARTIFACTS,'compiled_source_sha256':STAMP['source_sha256'],'runtime_source_sha256':PLAN['runtime_code_sha256']})
save(OUT/'summary.json',{'status':'running','phase':'sweep','completed':0,'planned':planned,'records':[]})
print('Q4H16K SWEEP START63; input32768 output16384 context131072; existing frozen native/runtime',flush=True)
try:
    for index,item in enumerate(schedule,1):
        execute(item['profile'],item['repeat'],index,'sweep')
        if index%21==0:print('ROUND COMPLETE',index//21,'/3',flush=True)
    save(OUT/'summary.json',{'status':'complete','phase':'sweep','completed':len(records),'planned':planned,'records':records})
    save(OUT/'progress.json',{'status':'sweep_complete','completed':len(records),'planned':planned})
    print('Q4H16K SWEEP COMPLETE63',flush=True)
except BaseException as error:
    save(OUT/'failure.json',{'type':type(error).__name__,'error':str(error),'completed':len(records),'planned':planned,'time':time.time()})
    raise
finally:
    record_lock.close()
