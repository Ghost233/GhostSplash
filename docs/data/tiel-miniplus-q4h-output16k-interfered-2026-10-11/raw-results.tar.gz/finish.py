"""Observe the existing controller's real exit, then preserve its completed evidence."""
from pathlib import Path
import json
import os
import select
import subprocess
import sys
import time

root=Path.cwd();out=root/'build/tiel-miniplus-q4h-output16k-sweep-v1'
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def watch_exit(pid):
    queue=select.kqueue()
    try:
        event=select.kevent(pid,filter=select.KQ_FILTER_PROC,flags=select.KQ_EV_ADD|select.KQ_EV_ONESHOT,fflags=select.KQ_NOTE_EXIT|0x04000000)
        initial=queue.control([event],1,0)
        assert not initial,initial
        while True:
            events=queue.control(None,1,30)
            if events:
                event=events[0]
                assert not event.flags & select.KQ_EV_ERROR,event
                assert event.fflags & 0x04000000,event
                return os.waitstatus_to_exitcode(event.data)
    finally:
        queue.close()

if sys.argv[1:] == ['self-check']:
    for wanted in (0,3):
        process=subprocess.Popen([sys.executable,'-c',f'import time;time.sleep(.2);raise SystemExit({wanted})'])
        observed=watch_exit(process.pid);actual=process.wait();assert observed==actual==wanted
    print('native exit observer checks passed:0/3',flush=True)
    raise SystemExit(0)

progress=json.loads((out/'progress.json').read_text());pid=progress['controller_pid']
save(out/'finish-status.json',{'status':'waiting_for_sweep','controller_pid':pid,'observer_pid':os.getpid()})
print('WAITING FOR SWEEP',pid,flush=True)
try:
    exit_code=watch_exit(pid)
    save(out/'controller-exit.json',{'exit_code':exit_code,'pid':pid,'source':'macOS EVFILT_PROC NOTE_EXITSTATUS','observed_at_unix':time.time()})
    assert exit_code==0,('sweep controller failed',exit_code)
    with (out/'report.log').open('w') as stream:
        result=subprocess.run([sys.executable,str(out/'report.py')],env=os.environ,stdout=stream,stderr=subprocess.STDOUT)
    save(out/'report-exit.json',{'exit_code':result.returncode});assert result.returncode==0
    print('SWEEP REPORT SAVED',flush=True)
    selection=json.loads((out/'selection.json').read_text())
    if selection['candidate']:
        save(out/'finish-status.json',{'status':'preparing_paired','candidate':selection['candidate']['name'],'observer_pid':os.getpid()})
        result=subprocess.run([sys.executable,str(out/'prepare-paired.py')]);assert result.returncode==0
        paired=root/'build/tiel-miniplus-q4h-output16k-paired-v1'
        save(out/'finish-status.json',{'status':'paired_running','candidate':selection['candidate']['name'],'directory':str(paired),'observer_pid':os.getpid()})
        with (paired/'controller.log').open('w') as stream:
            result=subprocess.run([sys.executable,'-u',str(paired/'runner.py')],env=os.environ,stdout=stream,stderr=subprocess.STDOUT)
        save(paired/'controller-exit.json',{'exit_code':result.returncode,'source':'subprocess.run wait result'});assert result.returncode==0
        with (paired/'report.log').open('w') as stream:
            result=subprocess.run([sys.executable,str(out/'report-paired.py')],env=os.environ,stdout=stream,stderr=subprocess.STDOUT)
        save(paired/'report-exit.json',{'exit_code':result.returncode});assert result.returncode==0
    save(out/'finish-status.json',{'status':'complete','sweep_batches':63,'paired_batches':12 if selection['candidate'] else 0,'reports_saved':True,'baseline_automatically_changed':False})
    print('ALL REPORTS SAVED; BASELINE PRESERVED',flush=True)
except BaseException as error:
    save(out/'finish-status.json',{'status':'failed','error_type':type(error).__name__,'error':str(error),'time':time.time()})
    raise
