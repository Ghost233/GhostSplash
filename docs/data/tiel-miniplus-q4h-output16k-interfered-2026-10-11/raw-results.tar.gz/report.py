"""Preserve the Q4H-only parameter sweep without changing its frozen baseline."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import statistics as st
import subprocess
import tarfile

from dev.benchmarks import qwen4b_matrix_adapter as adapter

root=Path.cwd()
out=root/'build/tiel-miniplus-q4h-output16k-sweep-v1'
data=root/'docs/data/tiel-miniplus-q4h-output16k-2026-10-11'
def load(name):return json.loads((out/name).read_text())
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
summary=load('summary.json');plan=load('plan.json');identity=load('prepared-identity.json');records=summary['records']
assert summary['status']=='complete' and summary['completed']==summary['planned']==63
assert all(r['native_exit_code']==0 and r['facts_pass'] and r['token_match_same_profile'] and (not r['frozen_match_required'] or r['token_match_frozen_q4h']) for r in records)
assert adapter.code_sha256(root)==plan['runtime_code_sha256']
controller=load('controller-exit.json');assert controller['exit_code']==0
verification={'status':'checking','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'controller_exit_code':controller['exit_code'],'runtime_code_sha256':plan['runtime_code_sha256'],'compiled_source_sha256':identity['compiled_source_sha256'],'artifacts':{},'weights':{}}
for path,wanted in identity['artifacts'].items():
 actual=adapter.sha_file(Path(path));assert actual==wanted,path;verification['artifacts'][path]=actual
for role,item in plan['weights'].items():
 actual=adapter.sha_file(Path(item['path']));assert actual==item['sha256'],role;verification['weights'][role]={**item,'actual_sha256':actual,'match':True}
remaining=[]
for line in subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()[1:]:
 fields=line.strip().split(None,1)
 if len(fields)==2 and (str(out/'runner.py') in fields[1] or str(out/'qwen4b-matrix-native') in fields[1]):remaining.append(int(fields[0]))
assert not remaining,remaining
for r in records:
 evidence=json.loads((Path(r['attempt'])/'evidence.json').read_text());assert evidence['status']=='complete' and evidence['exit_code']==0 and not evidence['error'];assert r['memory_report']['unclassified_bytes']==0
verification.update(status='passed',owned_test_processes_remaining=remaining,native_batches=63,requests=sum(r['parameters']['concurrency'] for r in records),all_native_exit_codes_zero=True,all_facts_pass=True,all_same_profile_token_checks_pass=True,all_required_frozen_q4h_token_checks_pass=True,observed_busy_samples=sum(bool(r['observed_busy_pids']) for r in records))
metrics=['prefill_tok_s','decode_tok_s','ttft_seconds','total_seconds','batch_prefill_tok_s','batch_decode_tok_s','batch_seconds','memory_peak_gib']
rows=[]
for p in plan['profiles']:
 rr=[r for r in records if r['profile']==p['name']];assert len(rr)==3 and {r['repeat'] for r in rr}=={0,1,2}
 relative=[]
 for r in rr:
  b=next(x for x in records if x['profile']=='baseline' and x['repeat']==r['repeat'])
  relative.append({'repeat':r['repeat'],'prefill_gain_percent':100*(r['prefill_tok_s']/b['prefill_tok_s']-1),'decode_gain_percent':100*(r['decode_tok_s']/b['decode_tok_s']-1),'total_reduction_percent':100*(1-r['total_seconds']/b['total_seconds']),'aggregate_decode_gain_percent':100*(r['batch_decode_tok_s']/b['batch_decode_tok_s']-1)})
 rows.append({'profile':p['name'],'parameters':rr[0]['parameters'],'features':rr[0]['features'],'samples':3,'median':{k:st.median(r[k] for r in rr) for k in metrics},'range':{k:[min(r[k] for r in rr),max(r[k] for r in rr)] for k in metrics},'device_peak_gib':st.median(r['memory_report']['device_peak_bytes']/2**30 for r in rr),'draft_acceptance':st.median(r['draft_acceptance'] for r in rr),'relative_to_same_round_baseline':relative,'relative_median':{k:st.median(r[k] for r in relative) for k in relative[0] if k!='repeat'},'total_faster_rounds':sum(r['total_reduction_percent']>0 for r in relative),'frozen_q4h_match':all(r['token_match_frozen_q4h'] for r in rr),'first_difference_frozen_q4h':rr[0]['first_difference_frozen_q4h'],'actual_batch_widths':[r['actual_batch_widths'] for r in rr],'optional_features':rr[0]['optional_features']})
single=[r for r in rows if r['parameters']['concurrency']==1]
best=min(single,key=lambda r:r['median']['total_seconds'])
promising=sorted((r for r in single if r['profile']!='baseline' and r['relative_median']['total_reduction_percent']>=2 and r['total_faster_rounds']>=2),key=lambda r:r['median']['total_seconds'])
selection={'baseline_kept':True,'baseline':plan['base_parameters'],'baseline_features':{'lookup':False,'compact':False,'fast':False},'best_observed_c1_profile':best['profile'],'promising_profiles':[r['profile'] for r in promising],'promotion_rule':'observed sweep differences are candidates; require paired verification before changing any baseline parameter; Q4H remains fixed by user preference','candidate':next(p for p in plan['profiles'] if p['name']==promising[0]['profile']) if promising else None}
report={'status':'complete','rows':rows,'selection':selection,'elapsed_seconds':max(r['completed_at_unix'] for r in records)-min(r['started_at_unix'] for r in records),'planned':63,'completed':63,'requests':verification['requests'],'metric_definition':{'median':'median of all three native batches; no slow sample removed','relative_median':'median of each round ratio against same-round baseline; these are not adjacent paired samples','request_prefill_tok_s':'32768 / submit-to-prefill-completion including queue','request_decode_tok_s':'16384 / per-request decode wall time including interleaving','batch_decode_tok_s':'C * 16384 / sum of Engine decode cycle wall seconds','memory_peak_gib':'backend peak; device ledger separate'}}
save(out/'comparison-report.json',report);save(out/'selection.json',selection);save(out/'final-verification.json',verification)
lines=['# Tiel MiniPlus：Q4H、16K 输出参数扫描','','## 固定条件','','所有组保留 Q4H KV、32,768 实际输入、16,384 实际输出及 131,072 上下文容量。DFlash2 block=8，ANE 和 fast top-k 关闭。greedy、ignore_eos=true、冷请求；内存预算 32 GiB。每个并发请求都生成完整 16K 输出。','','共 21 个配置，每组重复三轮，共 63 批、'+str(verification['requests'])+' 个完整请求。历时 %.1f 分钟。顺序为正序、逆序、旋转 10 项，全部波动样本保留。'%(report['elapsed_seconds']/60),'','基准为 splits=8、并发 1、lookup／compact 关闭。逐项测试 splits 1～16、并发 2／4、lookup、compact，以及 lookup + compact。只测试当前实现支持的参数；未加入没有实际路径的 ANE、非 block=8 的 DFlash2 或 greedy 不使用的 fast top-k。','','原生入口与上一轮字节一致，生产代码、库和 metallib 未变。模型加载与固定预热单列，不计入请求耗时。','','## 三轮中位数','','| 配置 | Splits | 并发 | Prefill tokens/s／请求 | Decode tokens/s／请求 | 整批 Decode tokens/s | 首 token s／请求 | 总耗时 s／请求 | 整批耗时 s | Device 峰值 GiB | 草稿接受率 |','| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |']
for r in rows:
 m=r['median'];p=r['parameters'];lines.append(f"| {r['profile']} | {p['tail_prefill_splits']} | {p['concurrency']} | {m['prefill_tok_s']:.1f} | {m['decode_tok_s']:.1f} | {m['batch_decode_tok_s']:.1f} | {m['ttft_seconds']:.2f} | {m['total_seconds']:.2f} | {m['batch_seconds']:.2f} | {r['device_peak_gib']:.3f} | {r['draft_acceptance']:.2%} |")
lines+=['','请求指标取同批各请求中位数，再对三轮取中位数。请求 prefill 包含排队；整批吞吐使用引擎对应阶段耗时。并发结果需要同时看每请求延迟与整批吞吐，不能把整批 tokens/s 当作单请求速度。提交并发数与实际 decode batch width 分开记录。','','Device 与 backend 使用独立分配口径，均不是 RSS 或整机内存。Backend 峰值、各内存分类与完整范围在机器可读报告内。','','## 相对同轮 Q4H 基准','','各配置与同轮 baseline 的比值取三轮中位数。样本并非相邻配对，不能把所有差异直接归因于参数。','','| 配置 | Prefill 收益 | Decode 收益／请求 | 整批 Decode 收益 | 总耗时降低／请求 | 总耗时更快轮数 |','| --- | --- | --- | --- | --- | --- |']
for r in rows:
 m=r['relative_median'];lines.append(f"| {r['profile']} | {m['prefill_gain_percent']:+.2f}% | {m['decode_gain_percent']:+.2f}% | {m['aggregate_decode_gain_percent']:+.2f}% | {m['total_reduction_percent']:+.2f}% | {r['total_faster_rounds']}／3 |")
lines+=['','## 候选与标准','','当前标准继续保留 Q4H／splits=8／并发 1／lookup 和 compact 关闭。逐项扫描中单请求总耗时最小的配置为 `'+best['profile']+'`。','','满足同轮总耗时降低中位数至少 2%、至少两轮更快的候选：'+('、'.join(selection['promising_profiles']) or '无')+'。这些结果用于后续配对复核，没有自动修改生产服务或根目录标准参数。','','## 输出与功能校验','','所有 63 批原生退出码为 0，事实、精确输入／输出长度、冷缓存和内存账本通过。相同配置三轮完整输出逐 token 一致。splits=8／并发 1 的基准和功能开关组均与此前冻结的 Q4H 完整 16K 输出一致。不同 splits 或并发的首次分歧保留，数值舍入和执行批次变化可能影响后续生成轨迹；事实检查不替代算子数值检查。生产算子未改，沿用已完成的源码门禁。','','| 配置 | 与冻结 Q4H 第一请求完整一致 | 首次分歧索引（从 0 开始） |','| --- | --- | --- |']
for r in rows:
 d=r['first_difference_frozen_q4h'];lines.append('| '+r['profile']+' | '+str(r['frozen_q4h_match'])+' | '+str(d['index'] if d else None)+' |')
lines+=['','功能的实际调用次数、命中与接受量、compact 行数、回退原因与额外分配全部保留。仅打开开关不等于实际执行路径有收益。','','## 全部逐次记录','','| 轮次 | 配置 | Prefill tokens/s／请求 | Decode tokens/s／请求 | 整批 Decode tokens/s | 总耗时 s／请求 | Device 峰值 GiB |','| --- | --- | --- | --- | --- | --- | --- |']
for r in records:lines.append(f"| {r['repeat']+1} | {r['profile']} | {r['prefill_tok_s']:.1f} | {r['decode_tok_s']:.1f} | {r['batch_decode_tok_s']:.1f} | {r['total_seconds']:.2f} | {r['memory_report']['device_peak_bytes']/2**30:.3f} |")
lines+=['','## 证据与范围','','按已有用户授权接受后台负载，检测到后台服务忙的样本为 '+str(verification['observed_busy_samples'])+'／63。结果属于诊断性测量，不能当作隔离环境下的稳定上限。所有慢样本保留。结束时源码、构建产物和原始权重 SHA-256 核对一致；测试进程已退出，未停止其他服务。','','[统计](data/tiel-miniplus-q4h-output16k-2026-10-11/comparison-report.json)、[全部样本](data/tiel-miniplus-q4h-output16k-2026-10-11/summary.json)、[结束校验](data/tiel-miniplus-q4h-output16k-2026-10-11/final-verification.json)、[归档](data/tiel-miniplus-q4h-output16k-2026-10-11/raw-results.tar.gz)与[清单](data/tiel-miniplus-q4h-output16k-2026-10-11/archive-manifest.json)。','','原始目录：`'+str(out)+'`。归档包含运行驱动、原生入口、所有载荷、输出、日志、环境和内存证据；权重不复制。原输入、排名、attention 入口与生产库沿用已有冻结文件和先前归档。']
(root/'docs/tiel-miniplus-q4h-output16k-2026-10-11.md').write_text('\n'.join(lines)+'\n')
data.mkdir(parents=True,exist_ok=True)
for name in ['plan.json','summary.json','comparison-report.json','selection.json','final-verification.json','controller.log']:shutil.copy2(out/name,data/name)
files=sorted(f for f in out.rglob('*') if f.is_file() and f.name not in {'report.log','finish.log','finish-status.json'});manifest=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':adapter.sha_file(f)} for f in files];archive=data/'raw-results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for entry,wanted in zip(tar.getmembers(),manifest,strict=True):
  assert entry.name==wanted['path'];h=hashlib.sha256();stream=tar.extractfile(entry)
  while chunk:=stream.read(1024*1024):h.update(chunk)
  assert h.hexdigest()==wanted['sha256'],entry.name
save(data/'archive-manifest.json',{'archive':archive.name,'sha256':adapter.sha_file(archive),'bytes':archive.stat().st_size,'files':manifest,'roundtrip_verified':True})
print(json.dumps({'status':'saved','elapsed_minutes':report['elapsed_seconds']/60,'selection':selection,'rows':rows,'verification':verification['status'],'owned_processes':remaining,'archive_bytes':archive.stat().st_size},ensure_ascii=False))
